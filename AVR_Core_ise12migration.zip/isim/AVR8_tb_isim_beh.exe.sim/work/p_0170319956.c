/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7dea747 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *STD_STANDARD;
extern char *IEEE_P_2592010699;
extern char *IEEE_P_1242562249;
static const char *ng3 = "Function fn_to_integer ended without a return statement";
static const char *ng4 = "Function fn_to_std_logic ended without a return statement";
static const char *ng5 = "";
static const char *ng6 = "Function \"+\" ended without a return statement";
static const char *ng7 = "Function \"-\" ended without a return statement";

char *ieee_p_1242562249_sub_1547198987_1242562249(char *, char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_1547270861_1242562249(char *, char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_1654287348_1242562249(char *, char *, int , char *, char *);
int ieee_p_1242562249_sub_1657552908_1242562249(char *, char *, char *);
char *ieee_p_1242562249_sub_180853171_1242562249(char *, char *, int , int );
char *ieee_p_1242562249_sub_1919365254_1242562249(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_1919437128_1242562249(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_2563015576_1242562249(char *, char *, int , int );
unsigned char ieee_p_2592010699_sub_1600845279_2592010699(char *, char *, char *);
unsigned char ieee_p_2592010699_sub_1605435078_2592010699(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_1665218837_2592010699(char *, unsigned char );
unsigned char ieee_p_2592010699_sub_2507238156_2592010699(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_2545490612_2592010699(char *, unsigned char , unsigned char );


unsigned char work_p_0170319956_sub_392603539_170319956(char *t1, char *t2, char *t3)
{
    char t4[128];
    char t5[24];
    char t9[8];
    unsigned char t0;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t12;
    unsigned char t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    t6 = (t4 + 4U);
    t7 = ((STD_STANDARD) + 0);
    t8 = (t6 + 88U);
    *((char **)t8) = t7;
    t10 = (t6 + 56U);
    *((char **)t10) = t9;
    xsi_type_set_default_value(t7, t9, 0);
    t11 = (t6 + 80U);
    *((unsigned int *)t11) = 1U;
    t12 = (t5 + 4U);
    t13 = (t2 != 0);
    if (t13 == 1)
        goto LAB3;

LAB2:    t14 = (t5 + 12U);
    *((char **)t14) = t3;
    t15 = (t6 + 56U);
    t16 = *((char **)t15);
    t15 = (t16 + 0);
    *((unsigned char *)t15) = (unsigned char)0;
    t13 = ieee_p_2592010699_sub_1600845279_2592010699(IEEE_P_2592010699, t2, t3);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t7 = (t8 + 0);
    *((unsigned char *)t7) = t13;
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t13 = *((unsigned char *)t8);
    t0 = t13;

LAB1:    return t0;
LAB3:    *((char **)t12) = *((char **)t2);
    goto LAB2;

LAB4:;
}

unsigned char work_p_0170319956_sub_165010554_170319956(char *t1, unsigned char t2)
{
    char t3[128];
    char t4[8];
    char t8[8];
    unsigned char t0;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    unsigned char t14;

LAB0:    t5 = (t3 + 4U);
    t6 = ((STD_STANDARD) + 0);
    t7 = (t5 + 88U);
    *((char **)t7) = t6;
    t9 = (t5 + 56U);
    *((char **)t9) = t8;
    xsi_type_set_default_value(t6, t8, 0);
    t10 = (t5 + 80U);
    *((unsigned int *)t10) = 1U;
    t11 = (t4 + 4U);
    *((unsigned char *)t11) = t2;
    t12 = (t5 + 56U);
    t13 = *((char **)t12);
    t12 = (t13 + 0);
    *((unsigned char *)t12) = (unsigned char)0;
    t14 = ieee_p_2592010699_sub_1665218837_2592010699(IEEE_P_2592010699, t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    *((unsigned char *)t6) = t14;
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t14 = *((unsigned char *)t7);
    t0 = t14;

LAB1:    return t0;
LAB2:;
}

unsigned char work_p_0170319956_sub_2382061885_170319956(char *t1, char *t2, char *t3)
{
    char t4[128];
    char t5[24];
    char t9[8];
    unsigned char t0;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t12;
    unsigned char t13;
    char *t14;
    char *t15;
    char *t16;
    int t17;
    int t18;
    int t19;
    int t20;
    int t21;
    int t22;
    int t23;
    int t24;
    int t25;
    int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    unsigned char t31;
    unsigned char t32;
    char *t33;
    char *t34;

LAB0:    t6 = (t4 + 4U);
    t7 = ((IEEE_P_2592010699) + 3320);
    t8 = (t6 + 88U);
    *((char **)t8) = t7;
    t10 = (t6 + 56U);
    *((char **)t10) = t9;
    xsi_type_set_default_value(t7, t9, 0);
    t11 = (t6 + 80U);
    *((unsigned int *)t11) = 1U;
    t12 = (t5 + 4U);
    t13 = (t2 != 0);
    if (t13 == 1)
        goto LAB3;

LAB2:    t14 = (t5 + 12U);
    *((char **)t14) = t3;
    t15 = (t6 + 56U);
    t16 = *((char **)t15);
    t15 = (t16 + 0);
    *((unsigned char *)t15) = (unsigned char)2;
    t7 = (t3 + 8U);
    t17 = *((int *)t7);
    t8 = (t3 + 4U);
    t18 = *((int *)t8);
    t10 = (t3 + 0U);
    t19 = *((int *)t10);
    t20 = t19;
    t21 = t18;

LAB4:    t22 = (t21 * t17);
    t23 = (t20 * t17);
    if (t23 <= t22)
        goto LAB5;

LAB7:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t13 = *((unsigned char *)t8);
    t0 = t13;

LAB1:    return t0;
LAB3:    *((char **)t12) = *((char **)t2);
    goto LAB2;

LAB5:    t11 = (t6 + 56U);
    t15 = *((char **)t11);
    t13 = *((unsigned char *)t15);
    t11 = (t3 + 0U);
    t24 = *((int *)t11);
    t16 = (t3 + 8U);
    t25 = *((int *)t16);
    t26 = (t20 - t24);
    t27 = (t26 * t25);
    t28 = (1U * t27);
    t29 = (0 + t28);
    t30 = (t2 + t29);
    t31 = *((unsigned char *)t30);
    t32 = ieee_p_2592010699_sub_2507238156_2592010699(IEEE_P_2592010699, t13, t31);
    t33 = (t6 + 56U);
    t34 = *((char **)t33);
    t33 = (t34 + 0);
    *((unsigned char *)t33) = t32;

LAB6:    if (t20 == t21)
        goto LAB7;

LAB8:    t18 = (t20 + t17);
    t20 = t18;
    goto LAB4;

LAB9:;
}

unsigned char work_p_0170319956_sub_3180367557_170319956(char *t1, char *t2, char *t3)
{
    char t4[128];
    char t5[24];
    char t9[8];
    unsigned char t0;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t12;
    unsigned char t13;
    char *t14;
    char *t15;
    char *t16;
    int t17;
    int t18;
    int t19;
    int t20;
    int t21;
    int t22;
    int t23;
    int t24;
    int t25;
    int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    unsigned char t31;
    unsigned char t32;
    char *t33;
    char *t34;

LAB0:    t6 = (t4 + 4U);
    t7 = ((IEEE_P_2592010699) + 3320);
    t8 = (t6 + 88U);
    *((char **)t8) = t7;
    t10 = (t6 + 56U);
    *((char **)t10) = t9;
    xsi_type_set_default_value(t7, t9, 0);
    t11 = (t6 + 80U);
    *((unsigned int *)t11) = 1U;
    t12 = (t5 + 4U);
    t13 = (t2 != 0);
    if (t13 == 1)
        goto LAB3;

LAB2:    t14 = (t5 + 12U);
    *((char **)t14) = t3;
    t15 = (t6 + 56U);
    t16 = *((char **)t15);
    t15 = (t16 + 0);
    *((unsigned char *)t15) = (unsigned char)2;
    t7 = (t3 + 8U);
    t17 = *((int *)t7);
    t8 = (t3 + 4U);
    t18 = *((int *)t8);
    t10 = (t3 + 0U);
    t19 = *((int *)t10);
    t20 = t19;
    t21 = t18;

LAB4:    t22 = (t21 * t17);
    t23 = (t20 * t17);
    if (t23 <= t22)
        goto LAB5;

LAB7:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t13 = *((unsigned char *)t8);
    t0 = t13;

LAB1:    return t0;
LAB3:    *((char **)t12) = *((char **)t2);
    goto LAB2;

LAB5:    t11 = (t6 + 56U);
    t15 = *((char **)t11);
    t13 = *((unsigned char *)t15);
    t11 = (t3 + 0U);
    t24 = *((int *)t11);
    t16 = (t3 + 8U);
    t25 = *((int *)t16);
    t26 = (t20 - t24);
    t27 = (t26 * t25);
    t28 = (1U * t27);
    t29 = (0 + t28);
    t30 = (t2 + t29);
    t31 = *((unsigned char *)t30);
    t32 = ieee_p_2592010699_sub_2545490612_2592010699(IEEE_P_2592010699, t13, t31);
    t33 = (t6 + 56U);
    t34 = *((char **)t33);
    t33 = (t34 + 0);
    *((unsigned char *)t33) = t32;

LAB6:    if (t20 == t21)
        goto LAB7;

LAB8:    t18 = (t20 + t17);
    t20 = t18;
    goto LAB4;

LAB9:;
}

unsigned char work_p_0170319956_sub_3505537527_170319956(char *t1, char *t2, char *t3)
{
    char t4[128];
    char t5[24];
    char t9[8];
    unsigned char t0;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t12;
    unsigned char t13;
    char *t14;
    char *t15;
    char *t16;
    int t17;
    int t18;
    int t19;
    int t20;
    int t21;
    int t22;
    int t23;
    int t24;
    int t25;
    int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    unsigned char t31;
    unsigned char t32;
    char *t33;
    char *t34;

LAB0:    t6 = (t4 + 4U);
    t7 = ((IEEE_P_2592010699) + 3320);
    t8 = (t6 + 88U);
    *((char **)t8) = t7;
    t10 = (t6 + 56U);
    *((char **)t10) = t9;
    xsi_type_set_default_value(t7, t9, 0);
    t11 = (t6 + 80U);
    *((unsigned int *)t11) = 1U;
    t12 = (t5 + 4U);
    t13 = (t2 != 0);
    if (t13 == 1)
        goto LAB3;

LAB2:    t14 = (t5 + 12U);
    *((char **)t14) = t3;
    t15 = (t6 + 56U);
    t16 = *((char **)t15);
    t15 = (t16 + 0);
    *((unsigned char *)t15) = (unsigned char)3;
    t7 = (t3 + 8U);
    t17 = *((int *)t7);
    t8 = (t3 + 4U);
    t18 = *((int *)t8);
    t10 = (t3 + 0U);
    t19 = *((int *)t10);
    t20 = t19;
    t21 = t18;

LAB4:    t22 = (t21 * t17);
    t23 = (t20 * t17);
    if (t23 <= t22)
        goto LAB5;

LAB7:    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t13 = *((unsigned char *)t8);
    t0 = t13;

LAB1:    return t0;
LAB3:    *((char **)t12) = *((char **)t2);
    goto LAB2;

LAB5:    t11 = (t6 + 56U);
    t15 = *((char **)t11);
    t13 = *((unsigned char *)t15);
    t11 = (t3 + 0U);
    t24 = *((int *)t11);
    t16 = (t3 + 8U);
    t25 = *((int *)t16);
    t26 = (t20 - t24);
    t27 = (t26 * t25);
    t28 = (1U * t27);
    t29 = (0 + t28);
    t30 = (t2 + t29);
    t31 = *((unsigned char *)t30);
    t32 = ieee_p_2592010699_sub_1605435078_2592010699(IEEE_P_2592010699, t13, t31);
    t33 = (t6 + 56U);
    t34 = *((char **)t33);
    t33 = (t34 + 0);
    *((unsigned char *)t33) = t32;

LAB6:    if (t20 == t21)
        goto LAB7;

LAB8:    t18 = (t20 + t17);
    t20 = t18;
    goto LAB4;

LAB9:;
}

int work_p_0170319956_sub_3397525853_170319956(char *t1, char *t2, char *t3)
{
    char t5[24];
    int t0;
    char *t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    int t11;

LAB0:    t6 = (t5 + 4U);
    t7 = (t2 != 0);
    if (t7 == 1)
        goto LAB3;

LAB2:    t8 = (t5 + 12U);
    *((char **)t8) = t3;
    t9 = work_p_0170319956_sub_392603539_170319956(t1, t2, t3);
    t10 = (!(t9));
    if (t10 != 0)
        goto LAB4;

LAB6:    t0 = 0;

LAB1:    return t0;
LAB3:    *((char **)t6) = *((char **)t2);
    goto LAB2;

LAB4:    t11 = ieee_p_1242562249_sub_1657552908_1242562249(IEEE_P_1242562249, t2, t3);
    t0 = t11;
    goto LAB1;

LAB5:    xsi_error(ng3);
    t0 = 0;
    goto LAB1;

LAB7:    goto LAB5;

LAB8:    goto LAB5;

}

int work_p_0170319956_sub_3407386099_170319956(char *t1, unsigned char t2)
{
    char t4[8];
    int t0;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    unsigned char t8;

LAB0:    t5 = (t4 + 4U);
    *((unsigned char *)t5) = t2;
    t6 = work_p_0170319956_sub_165010554_170319956(t1, t2);
    t7 = (!(t6));
    if (t7 != 0)
        goto LAB2;

LAB4:    t0 = 0;

LAB1:    return t0;
LAB2:    t8 = (t2 == (unsigned char)3);
    if (t8 != 0)
        goto LAB5;

LAB7:    t0 = 0;
    goto LAB1;

LAB3:    xsi_error(ng3);
    t0 = 0;
    goto LAB1;

LAB5:    t0 = 1;
    goto LAB1;

LAB6:    goto LAB3;

LAB8:    goto LAB6;

LAB9:    goto LAB6;

LAB10:    goto LAB3;

}

char *work_p_0170319956_sub_3642789088_170319956(char *t1, char *t2, int t3, int t4)
{
    char t5[128];
    char t6[16];
    char t10[16];
    char t24[16];
    char *t0;
    int t7;
    int t8;
    unsigned int t9;
    int t11;
    char *t12;
    char *t13;
    int t14;
    unsigned int t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t25;
    char *t26;
    char *t27;
    char *t28;

LAB0:    t7 = (t4 - 1);
    t8 = (0 - t7);
    t9 = (t8 * -1);
    t9 = (t9 + 1);
    t9 = (t9 * 1U);
    t11 = (t4 - 1);
    t12 = (t10 + 0U);
    t13 = (t12 + 0U);
    *((int *)t13) = t11;
    t13 = (t12 + 4U);
    *((int *)t13) = 0;
    t13 = (t12 + 8U);
    *((int *)t13) = -1;
    t14 = (0 - t11);
    t15 = (t14 * -1);
    t15 = (t15 + 1);
    t13 = (t12 + 12U);
    *((unsigned int *)t13) = t15;
    t13 = (t5 + 4U);
    t16 = ((IEEE_P_2592010699) + 4024);
    t17 = (t13 + 88U);
    *((char **)t17) = t16;
    t18 = (char *)alloca(t9);
    t19 = (t13 + 56U);
    *((char **)t19) = t18;
    xsi_type_set_default_value(t16, t18, t10);
    t20 = (t13 + 64U);
    *((char **)t20) = t10;
    t21 = (t13 + 80U);
    *((unsigned int *)t21) = t9;
    t22 = (t6 + 4U);
    *((int *)t22) = t3;
    t23 = (t6 + 8U);
    *((int *)t23) = t4;
    t25 = ieee_p_1242562249_sub_180853171_1242562249(IEEE_P_1242562249, t24, t3, t4);
    t26 = (t13 + 56U);
    t27 = *((char **)t26);
    t26 = (t27 + 0);
    t28 = (t24 + 12U);
    t15 = *((unsigned int *)t28);
    t15 = (t15 * 1U);
    memcpy(t26, t25, t15);
    t12 = (t13 + 56U);
    t16 = *((char **)t12);
    t12 = (t10 + 12U);
    t9 = *((unsigned int *)t12);
    t9 = (t9 * 1U);
    t0 = xsi_get_transient_memory(t9);
    memcpy(t0, t16, t9);
    t17 = (t10 + 0U);
    t7 = *((int *)t17);
    t19 = (t10 + 4U);
    t8 = *((int *)t19);
    t20 = (t10 + 8U);
    t11 = *((int *)t20);
    t21 = (t2 + 0U);
    t25 = (t21 + 0U);
    *((int *)t25) = t7;
    t25 = (t21 + 4U);
    *((int *)t25) = t8;
    t25 = (t21 + 8U);
    *((int *)t25) = t11;
    t14 = (t8 - t7);
    t15 = (t14 * t11);
    t15 = (t15 + 1);
    t25 = (t21 + 12U);
    *((unsigned int *)t25) = t15;

LAB1:    return t0;
LAB2:;
}

char *work_p_0170319956_sub_2396784601_170319956(char *t1, char *t2, int t3, int t4)
{
    char t5[128];
    char t6[16];
    char t10[16];
    char t24[16];
    char *t0;
    int t7;
    int t8;
    unsigned int t9;
    int t11;
    char *t12;
    char *t13;
    int t14;
    unsigned int t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t25;
    char *t26;
    char *t27;
    char *t28;

LAB0:    t7 = (t4 - 1);
    t8 = (0 - t7);
    t9 = (t8 * -1);
    t9 = (t9 + 1);
    t9 = (t9 * 1U);
    t11 = (t4 - 1);
    t12 = (t10 + 0U);
    t13 = (t12 + 0U);
    *((int *)t13) = t11;
    t13 = (t12 + 4U);
    *((int *)t13) = 0;
    t13 = (t12 + 8U);
    *((int *)t13) = -1;
    t14 = (0 - t11);
    t15 = (t14 * -1);
    t15 = (t15 + 1);
    t13 = (t12 + 12U);
    *((unsigned int *)t13) = t15;
    t13 = (t5 + 4U);
    t16 = ((IEEE_P_2592010699) + 4024);
    t17 = (t13 + 88U);
    *((char **)t17) = t16;
    t18 = (char *)alloca(t9);
    t19 = (t13 + 56U);
    *((char **)t19) = t18;
    xsi_type_set_default_value(t16, t18, t10);
    t20 = (t13 + 64U);
    *((char **)t20) = t10;
    t21 = (t13 + 80U);
    *((unsigned int *)t21) = t9;
    t22 = (t6 + 4U);
    *((int *)t22) = t3;
    t23 = (t6 + 8U);
    *((int *)t23) = t4;
    t25 = ieee_p_1242562249_sub_2563015576_1242562249(IEEE_P_1242562249, t24, t3, t4);
    t26 = (t13 + 56U);
    t27 = *((char **)t26);
    t26 = (t27 + 0);
    t28 = (t24 + 12U);
    t15 = *((unsigned int *)t28);
    t15 = (t15 * 1U);
    memcpy(t26, t25, t15);
    t12 = (t13 + 56U);
    t16 = *((char **)t12);
    t12 = (t10 + 12U);
    t9 = *((unsigned int *)t12);
    t9 = (t9 * 1U);
    t0 = xsi_get_transient_memory(t9);
    memcpy(t0, t16, t9);
    t17 = (t10 + 0U);
    t7 = *((int *)t17);
    t19 = (t10 + 4U);
    t8 = *((int *)t19);
    t20 = (t10 + 8U);
    t11 = *((int *)t20);
    t21 = (t2 + 0U);
    t25 = (t21 + 0U);
    *((int *)t25) = t7;
    t25 = (t21 + 4U);
    *((int *)t25) = t8;
    t25 = (t21 + 8U);
    *((int *)t25) = t11;
    t14 = (t8 - t7);
    t15 = (t14 * t11);
    t15 = (t15 + 1);
    t25 = (t21 + 12U);
    *((unsigned int *)t25) = t15;

LAB1:    return t0;
LAB2:;
}

unsigned char work_p_0170319956_sub_1525193009_170319956(char *t1, unsigned char t2)
{
    char t4[8];
    unsigned char t0;
    char *t5;

LAB0:    t5 = (t4 + 4U);
    *((unsigned char *)t5) = t2;
    if (t2 != 0)
        goto LAB2;

LAB4:    t0 = (unsigned char)2;

LAB1:    return t0;
LAB2:    t0 = (unsigned char)3;
    goto LAB1;

LAB3:    xsi_error(ng4);
    t0 = 0;
    goto LAB1;

LAB5:    goto LAB3;

LAB6:    goto LAB3;

}

char *work_p_0170319956_sub_2511478883_170319956(char *t1, char *t2, char *t3, char *t4)
{
    char t5[336];
    char t6[24];
    char t13[16];
    char t30[16];
    char t42[8];
    char *t0;
    char *t7;
    unsigned int t8;
    int t9;
    int t10;
    int t11;
    unsigned int t12;
    char *t14;
    unsigned int t15;
    int t16;
    int t17;
    char *t18;
    char *t19;
    int t20;
    unsigned int t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t31;
    int t32;
    char *t33;
    int t34;
    char *t35;
    int t36;
    char *t37;
    char *t38;
    int t39;
    char *t40;
    char *t41;
    char *t43;
    char *t44;
    char *t45;
    unsigned char t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    unsigned int t54;
    unsigned char t55;

LAB0:    t7 = (t4 + 12U);
    t8 = *((unsigned int *)t7);
    t9 = xsi_vhdl_pow(2, t8);
    t10 = (t9 - 1);
    t11 = (0 - t10);
    t12 = (t11 * -1);
    t12 = (t12 + 1);
    t12 = (t12 * 1U);
    t14 = (t4 + 12U);
    t15 = *((unsigned int *)t14);
    t16 = xsi_vhdl_pow(2, t15);
    t17 = (t16 - 1);
    t18 = (t13 + 0U);
    t19 = (t18 + 0U);
    *((int *)t19) = t17;
    t19 = (t18 + 4U);
    *((int *)t19) = 0;
    t19 = (t18 + 8U);
    *((int *)t19) = -1;
    t20 = (0 - t17);
    t21 = (t20 * -1);
    t21 = (t21 + 1);
    t19 = (t18 + 12U);
    *((unsigned int *)t19) = t21;
    t19 = (t5 + 4U);
    t22 = ((IEEE_P_2592010699) + 4024);
    t23 = (t19 + 88U);
    *((char **)t23) = t22;
    t24 = (char *)alloca(t12);
    t25 = (t19 + 56U);
    *((char **)t25) = t24;
    xsi_type_set_default_value(t22, t24, t13);
    t26 = (t19 + 64U);
    *((char **)t26) = t13;
    t27 = (t19 + 80U);
    *((unsigned int *)t27) = t12;
    t28 = (t5 + 124U);
    t29 = ((STD_STANDARD) + 384);
    t31 = (t13 + 0U);
    t32 = *((int *)t31);
    t33 = (t13 + 4U);
    t34 = *((int *)t33);
    t35 = (t13 + 8U);
    t36 = *((int *)t35);
    t37 = (t30 + 0U);
    t38 = (t37 + 0U);
    *((int *)t38) = t32;
    t38 = (t37 + 4U);
    *((int *)t38) = t34;
    t38 = (t37 + 8U);
    *((int *)t38) = t36;
    t39 = (t34 - t32);
    t21 = (t39 * t36);
    t21 = (t21 + 1);
    t38 = (t37 + 12U);
    *((unsigned int *)t38) = t21;
    t38 = (t5 + 244U);
    xsi_create_subtype(t38, ng5, t29, t30, 16);
    t40 = (t5 + 244U);
    t41 = (t28 + 88U);
    *((char **)t41) = t40;
    t43 = (t28 + 56U);
    *((char **)t43) = t42;
    xsi_type_set_default_value(t40, t42, 0);
    t44 = (t28 + 80U);
    *((unsigned int *)t44) = 4U;
    t45 = (t6 + 4U);
    t46 = (t3 != 0);
    if (t46 == 1)
        goto LAB3;

LAB2:    t47 = (t6 + 12U);
    *((char **)t47) = t4;
    t48 = (t13 + 12U);
    t21 = *((unsigned int *)t48);
    t21 = (t21 * 1U);
    t49 = xsi_get_transient_memory(t21);
    memset(t49, 0, t21);
    t50 = t49;
    memset(t50, (unsigned char)2, t21);
    t51 = (t19 + 56U);
    t52 = *((char **)t51);
    t51 = (t52 + 0);
    t53 = (t13 + 12U);
    t54 = *((unsigned int *)t53);
    t54 = (t54 * 1U);
    memcpy(t51, t49, t54);
    t7 = (t28 + 56U);
    t14 = *((char **)t7);
    t7 = (t14 + 0);
    *((int *)t7) = 0;
    t46 = work_p_0170319956_sub_392603539_170319956(t1, t3, t4);
    t55 = (!(t46));
    if (t55 != 0)
        goto LAB4;

LAB6:
LAB5:    t7 = (t19 + 56U);
    t14 = *((char **)t7);
    t7 = (t28 + 56U);
    t18 = *((char **)t7);
    t9 = *((int *)t18);
    t7 = (t13 + 0U);
    t10 = *((int *)t7);
    t22 = (t13 + 8U);
    t11 = *((int *)t22);
    t16 = (t9 - t10);
    t8 = (t16 * t11);
    t23 = (t13 + 4U);
    t17 = *((int *)t23);
    xsi_vhdl_check_range_of_index(t10, t17, t11, t9);
    t12 = (1U * t8);
    t15 = (0 + t12);
    t25 = (t14 + t15);
    *((unsigned char *)t25) = (unsigned char)3;
    t7 = (t19 + 56U);
    t14 = *((char **)t7);
    t7 = (t13 + 12U);
    t8 = *((unsigned int *)t7);
    t8 = (t8 * 1U);
    t0 = xsi_get_transient_memory(t8);
    memcpy(t0, t14, t8);
    t18 = (t13 + 0U);
    t9 = *((int *)t18);
    t22 = (t13 + 4U);
    t10 = *((int *)t22);
    t23 = (t13 + 8U);
    t11 = *((int *)t23);
    t25 = (t2 + 0U);
    t26 = (t25 + 0U);
    *((int *)t26) = t9;
    t26 = (t25 + 4U);
    *((int *)t26) = t10;
    t26 = (t25 + 8U);
    *((int *)t26) = t11;
    t16 = (t10 - t9);
    t12 = (t16 * t11);
    t12 = (t12 + 1);
    t26 = (t25 + 12U);
    *((unsigned int *)t26) = t12;

LAB1:    return t0;
LAB3:    *((char **)t45) = *((char **)t3);
    goto LAB2;

LAB4:    t9 = ieee_p_1242562249_sub_1657552908_1242562249(IEEE_P_1242562249, t3, t4);
    t7 = (t28 + 56U);
    t14 = *((char **)t7);
    t7 = (t14 + 0);
    *((int *)t7) = t9;
    goto LAB5;

LAB7:;
}

unsigned char work_p_0170319956_sub_1376644890_170319956(char *t1, char *t2, char *t3, char *t4, char *t5)
{
    char t6[336];
    char t7[40];
    char t13[16];
    char t29[16];
    char t41[8];
    unsigned char t0;
    char *t8;
    unsigned int t9;
    int t10;
    int t11;
    unsigned int t12;
    char *t14;
    unsigned int t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t30;
    int t31;
    char *t32;
    int t33;
    char *t34;
    int t35;
    char *t36;
    char *t37;
    int t38;
    char *t39;
    char *t40;
    char *t42;
    char *t43;
    char *t44;
    unsigned char t45;
    char *t46;
    char *t47;
    unsigned char t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;

LAB0:    t8 = (t5 + 12U);
    t9 = *((unsigned int *)t8);
    t10 = (t9 - 1);
    t11 = (0 - t10);
    t12 = (t11 * -1);
    t12 = (t12 + 1);
    t12 = (t12 * 1U);
    t14 = (t5 + 12U);
    t15 = *((unsigned int *)t14);
    t16 = (t15 - 1);
    t17 = (t13 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = t16;
    t18 = (t17 + 4U);
    *((int *)t18) = 0;
    t18 = (t17 + 8U);
    *((int *)t18) = -1;
    t19 = (0 - t16);
    t20 = (t19 * -1);
    t20 = (t20 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t20;
    t18 = (t6 + 4U);
    t21 = ((IEEE_P_2592010699) + 4024);
    t22 = (t18 + 88U);
    *((char **)t22) = t21;
    t23 = (char *)alloca(t12);
    t24 = (t18 + 56U);
    *((char **)t24) = t23;
    xsi_type_set_default_value(t21, t23, t13);
    t25 = (t18 + 64U);
    *((char **)t25) = t13;
    t26 = (t18 + 80U);
    *((unsigned int *)t26) = t12;
    t27 = (t6 + 124U);
    t28 = ((STD_STANDARD) + 384);
    t30 = (t13 + 0U);
    t31 = *((int *)t30);
    t32 = (t13 + 4U);
    t33 = *((int *)t32);
    t34 = (t13 + 8U);
    t35 = *((int *)t34);
    t36 = (t29 + 0U);
    t37 = (t36 + 0U);
    *((int *)t37) = t31;
    t37 = (t36 + 4U);
    *((int *)t37) = t33;
    t37 = (t36 + 8U);
    *((int *)t37) = t35;
    t38 = (t33 - t31);
    t20 = (t38 * t35);
    t20 = (t20 + 1);
    t37 = (t36 + 12U);
    *((unsigned int *)t37) = t20;
    t37 = (t6 + 244U);
    xsi_create_subtype(t37, ng5, t28, t29, 16);
    t39 = (t6 + 244U);
    t40 = (t27 + 88U);
    *((char **)t40) = t39;
    t42 = (t27 + 56U);
    *((char **)t42) = t41;
    xsi_type_set_default_value(t39, t41, 0);
    t43 = (t27 + 80U);
    *((unsigned int *)t43) = 4U;
    t44 = (t7 + 4U);
    t45 = (t2 != 0);
    if (t45 == 1)
        goto LAB3;

LAB2:    t46 = (t7 + 12U);
    *((char **)t46) = t3;
    t47 = (t7 + 20U);
    t48 = (t4 != 0);
    if (t48 == 1)
        goto LAB5;

LAB4:    t49 = (t7 + 28U);
    *((char **)t49) = t5;
    t50 = (t18 + 56U);
    t51 = *((char **)t50);
    t50 = (t51 + 0);
    t52 = (t5 + 12U);
    t20 = *((unsigned int *)t52);
    t20 = (t20 * 1U);
    memcpy(t50, t4, t20);
    t8 = (t27 + 56U);
    t14 = *((char **)t8);
    t8 = (t14 + 0);
    *((int *)t8) = 0;
    t45 = work_p_0170319956_sub_392603539_170319956(t1, t2, t3);
    t48 = (!(t45));
    if (t48 != 0)
        goto LAB6;

LAB8:
LAB7:    t8 = (t18 + 56U);
    t14 = *((char **)t8);
    t8 = (t27 + 56U);
    t17 = *((char **)t8);
    t10 = *((int *)t17);
    t8 = (t13 + 0U);
    t11 = *((int *)t8);
    t21 = (t13 + 8U);
    t16 = *((int *)t21);
    t19 = (t10 - t11);
    t9 = (t19 * t16);
    t22 = (t13 + 4U);
    t31 = *((int *)t22);
    xsi_vhdl_check_range_of_index(t11, t31, t16, t10);
    t12 = (1U * t9);
    t15 = (0 + t12);
    t24 = (t14 + t15);
    t45 = *((unsigned char *)t24);
    t0 = t45;

LAB1:    return t0;
LAB3:    *((char **)t44) = *((char **)t2);
    goto LAB2;

LAB5:    *((char **)t47) = *((char **)t4);
    goto LAB4;

LAB6:    t10 = ieee_p_1242562249_sub_1657552908_1242562249(IEEE_P_1242562249, t2, t3);
    t8 = (t27 + 56U);
    t14 = *((char **)t8);
    t8 = (t14 + 0);
    *((int *)t8) = t10;
    goto LAB7;

LAB9:;
}

char *work_p_0170319956_sub_4092769478_170319956(char *t1, char *t2, char *t3, char *t4, char *t5, char *t6)
{
    char t7[248];
    char t8[40];
    char t14[16];
    char t32[16];
    char t56[16];
    char *t0;
    char *t9;
    unsigned int t10;
    int t11;
    int t12;
    unsigned int t13;
    char *t15;
    unsigned int t16;
    int t17;
    char *t18;
    char *t19;
    int t20;
    unsigned int t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    int t29;
    int t30;
    unsigned int t31;
    char *t33;
    unsigned int t34;
    int t35;
    char *t36;
    char *t37;
    int t38;
    unsigned int t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    unsigned char t47;
    char *t48;
    char *t49;
    unsigned char t50;
    char *t51;
    unsigned char t52;
    unsigned char t53;
    unsigned char t54;
    unsigned char t55;
    char *t57;
    char *t58;
    unsigned int t59;
    char *t60;
    int t61;
    char *t62;
    int t63;
    char *t64;
    int t65;
    char *t66;
    char *t67;
    int t68;
    unsigned int t69;

LAB0:    t9 = (t4 + 12U);
    t10 = *((unsigned int *)t9);
    t11 = (t10 - 1);
    t12 = (0 - t11);
    t13 = (t12 * -1);
    t13 = (t13 + 1);
    t13 = (t13 * 1U);
    t15 = (t4 + 12U);
    t16 = *((unsigned int *)t15);
    t17 = (t16 - 1);
    t18 = (t14 + 0U);
    t19 = (t18 + 0U);
    *((int *)t19) = t17;
    t19 = (t18 + 4U);
    *((int *)t19) = 0;
    t19 = (t18 + 8U);
    *((int *)t19) = -1;
    t20 = (0 - t17);
    t21 = (t20 * -1);
    t21 = (t21 + 1);
    t19 = (t18 + 12U);
    *((unsigned int *)t19) = t21;
    t19 = (t7 + 4U);
    t22 = ((IEEE_P_2592010699) + 4024);
    t23 = (t19 + 88U);
    *((char **)t23) = t22;
    t24 = (char *)alloca(t13);
    t25 = (t19 + 56U);
    *((char **)t25) = t24;
    xsi_type_set_default_value(t22, t24, t14);
    t26 = (t19 + 64U);
    *((char **)t26) = t14;
    t27 = (t19 + 80U);
    *((unsigned int *)t27) = t13;
    t28 = (t6 + 12U);
    t21 = *((unsigned int *)t28);
    t29 = (t21 - 1);
    t30 = (0 - t29);
    t31 = (t30 * -1);
    t31 = (t31 + 1);
    t31 = (t31 * 1U);
    t33 = (t6 + 12U);
    t34 = *((unsigned int *)t33);
    t35 = (t34 - 1);
    t36 = (t32 + 0U);
    t37 = (t36 + 0U);
    *((int *)t37) = t35;
    t37 = (t36 + 4U);
    *((int *)t37) = 0;
    t37 = (t36 + 8U);
    *((int *)t37) = -1;
    t38 = (0 - t35);
    t39 = (t38 * -1);
    t39 = (t39 + 1);
    t37 = (t36 + 12U);
    *((unsigned int *)t37) = t39;
    t37 = (t7 + 124U);
    t40 = ((IEEE_P_2592010699) + 4024);
    t41 = (t37 + 88U);
    *((char **)t41) = t40;
    t42 = (char *)alloca(t31);
    t43 = (t37 + 56U);
    *((char **)t43) = t42;
    xsi_type_set_default_value(t40, t42, t32);
    t44 = (t37 + 64U);
    *((char **)t44) = t32;
    t45 = (t37 + 80U);
    *((unsigned int *)t45) = t31;
    t46 = (t8 + 4U);
    t47 = (t3 != 0);
    if (t47 == 1)
        goto LAB3;

LAB2:    t48 = (t8 + 12U);
    *((char **)t48) = t4;
    t49 = (t8 + 20U);
    t50 = (t5 != 0);
    if (t50 == 1)
        goto LAB5;

LAB4:    t51 = (t8 + 28U);
    *((char **)t51) = t6;
    t53 = work_p_0170319956_sub_392603539_170319956(t1, t3, t4);
    if (t53 == 1)
        goto LAB9;

LAB10:    t54 = work_p_0170319956_sub_392603539_170319956(t1, t5, t6);
    t52 = t54;

LAB11:    t55 = (!(t52));
    if (t55 != 0)
        goto LAB6;

LAB8:    t9 = (t14 + 12U);
    t10 = *((unsigned int *)t9);
    t10 = (t10 * 1U);
    t15 = xsi_get_transient_memory(t10);
    memset(t15, 0, t10);
    t18 = t15;
    memset(t18, (unsigned char)1, t10);
    t22 = (t19 + 56U);
    t23 = *((char **)t22);
    t22 = (t23 + 0);
    t25 = (t14 + 12U);
    t13 = *((unsigned int *)t25);
    t13 = (t13 * 1U);
    memcpy(t22, t15, t13);
    t9 = (t32 + 12U);
    t10 = *((unsigned int *)t9);
    t10 = (t10 * 1U);
    t15 = xsi_get_transient_memory(t10);
    memset(t15, 0, t10);
    t18 = t15;
    memset(t18, (unsigned char)1, t10);
    t22 = (t37 + 56U);
    t23 = *((char **)t22);
    t22 = (t23 + 0);
    t25 = (t32 + 12U);
    t13 = *((unsigned int *)t25);
    t13 = (t13 * 1U);
    memcpy(t22, t15, t13);
    t9 = (t14 + 12U);
    t10 = *((unsigned int *)t9);
    t15 = (t32 + 12U);
    t13 = *((unsigned int *)t15);
    t47 = (t10 > t13);
    if (t47 != 0)
        goto LAB13;

LAB15:    t9 = (t37 + 56U);
    t15 = *((char **)t9);
    t9 = (t32 + 12U);
    t10 = *((unsigned int *)t9);
    t10 = (t10 * 1U);
    t0 = xsi_get_transient_memory(t10);
    memcpy(t0, t15, t10);
    t18 = (t32 + 0U);
    t11 = *((int *)t18);
    t22 = (t32 + 4U);
    t12 = *((int *)t22);
    t23 = (t32 + 8U);
    t17 = *((int *)t23);
    t25 = (t2 + 0U);
    t26 = (t25 + 0U);
    *((int *)t26) = t11;
    t26 = (t25 + 4U);
    *((int *)t26) = t12;
    t26 = (t25 + 8U);
    *((int *)t26) = t17;
    t20 = (t12 - t11);
    t13 = (t20 * t17);
    t13 = (t13 + 1);
    t26 = (t25 + 12U);
    *((unsigned int *)t26) = t13;

LAB1:    return t0;
LAB3:    *((char **)t46) = *((char **)t3);
    goto LAB2;

LAB5:    *((char **)t49) = *((char **)t5);
    goto LAB4;

LAB6:    t57 = ieee_p_1242562249_sub_1547198987_1242562249(IEEE_P_1242562249, t56, t3, t4, t5, t6);
    t58 = (t56 + 12U);
    t39 = *((unsigned int *)t58);
    t59 = (1U * t39);
    t0 = xsi_get_transient_memory(t59);
    memcpy(t0, t57, t59);
    t60 = (t56 + 0U);
    t61 = *((int *)t60);
    t62 = (t56 + 4U);
    t63 = *((int *)t62);
    t64 = (t56 + 8U);
    t65 = *((int *)t64);
    t66 = (t2 + 0U);
    t67 = (t66 + 0U);
    *((int *)t67) = t61;
    t67 = (t66 + 4U);
    *((int *)t67) = t63;
    t67 = (t66 + 8U);
    *((int *)t67) = t65;
    t68 = (t63 - t61);
    t69 = (t68 * t65);
    t69 = (t69 + 1);
    t67 = (t66 + 12U);
    *((unsigned int *)t67) = t69;
    goto LAB1;

LAB7:    xsi_error(ng6);
    t0 = 0;
    goto LAB1;

LAB9:    t52 = (unsigned char)1;
    goto LAB11;

LAB12:    goto LAB7;

LAB13:    t18 = (t19 + 56U);
    t22 = *((char **)t18);
    t18 = (t14 + 12U);
    t16 = *((unsigned int *)t18);
    t16 = (t16 * 1U);
    t0 = xsi_get_transient_memory(t16);
    memcpy(t0, t22, t16);
    t23 = (t14 + 0U);
    t11 = *((int *)t23);
    t25 = (t14 + 4U);
    t12 = *((int *)t25);
    t26 = (t14 + 8U);
    t17 = *((int *)t26);
    t27 = (t2 + 0U);
    t28 = (t27 + 0U);
    *((int *)t28) = t11;
    t28 = (t27 + 4U);
    *((int *)t28) = t12;
    t28 = (t27 + 8U);
    *((int *)t28) = t17;
    t20 = (t12 - t11);
    t21 = (t20 * t17);
    t21 = (t21 + 1);
    t28 = (t27 + 12U);
    *((unsigned int *)t28) = t21;
    goto LAB1;

LAB14:    goto LAB7;

LAB16:    goto LAB14;

LAB17:    goto LAB14;

}

char *work_p_0170319956_sub_433329865_170319956(char *t1, char *t2, char *t3, char *t4, int t5)
{
    char t6[128];
    char t7[24];
    char t13[16];
    char t33[16];
    char *t0;
    char *t8;
    unsigned int t9;
    int t10;
    int t11;
    unsigned int t12;
    char *t14;
    unsigned int t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    unsigned char t28;
    char *t29;
    char *t30;
    unsigned char t31;
    unsigned char t32;
    char *t34;
    char *t35;
    unsigned int t36;
    char *t37;
    int t38;
    char *t39;
    int t40;
    char *t41;
    int t42;
    char *t43;
    char *t44;
    int t45;
    unsigned int t46;

LAB0:    t8 = (t4 + 12U);
    t9 = *((unsigned int *)t8);
    t10 = (t9 - 1);
    t11 = (0 - t10);
    t12 = (t11 * -1);
    t12 = (t12 + 1);
    t12 = (t12 * 1U);
    t14 = (t4 + 12U);
    t15 = *((unsigned int *)t14);
    t16 = (t15 - 1);
    t17 = (t13 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = t16;
    t18 = (t17 + 4U);
    *((int *)t18) = 0;
    t18 = (t17 + 8U);
    *((int *)t18) = -1;
    t19 = (0 - t16);
    t20 = (t19 * -1);
    t20 = (t20 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t20;
    t18 = (t6 + 4U);
    t21 = ((IEEE_P_2592010699) + 4024);
    t22 = (t18 + 88U);
    *((char **)t22) = t21;
    t23 = (char *)alloca(t12);
    t24 = (t18 + 56U);
    *((char **)t24) = t23;
    xsi_type_set_default_value(t21, t23, t13);
    t25 = (t18 + 64U);
    *((char **)t25) = t13;
    t26 = (t18 + 80U);
    *((unsigned int *)t26) = t12;
    t27 = (t7 + 4U);
    t28 = (t3 != 0);
    if (t28 == 1)
        goto LAB3;

LAB2:    t29 = (t7 + 12U);
    *((char **)t29) = t4;
    t30 = (t7 + 20U);
    *((int *)t30) = t5;
    t31 = work_p_0170319956_sub_392603539_170319956(t1, t3, t4);
    t32 = (!(t31));
    if (t32 != 0)
        goto LAB4;

LAB6:    t8 = (t13 + 12U);
    t9 = *((unsigned int *)t8);
    t9 = (t9 * 1U);
    t14 = xsi_get_transient_memory(t9);
    memset(t14, 0, t9);
    t17 = t14;
    memset(t17, (unsigned char)1, t9);
    t21 = (t18 + 56U);
    t22 = *((char **)t21);
    t21 = (t22 + 0);
    t24 = (t13 + 12U);
    t12 = *((unsigned int *)t24);
    t12 = (t12 * 1U);
    memcpy(t21, t14, t12);
    t8 = (t18 + 56U);
    t14 = *((char **)t8);
    t8 = (t13 + 12U);
    t9 = *((unsigned int *)t8);
    t9 = (t9 * 1U);
    t0 = xsi_get_transient_memory(t9);
    memcpy(t0, t14, t9);
    t17 = (t13 + 0U);
    t10 = *((int *)t17);
    t21 = (t13 + 4U);
    t11 = *((int *)t21);
    t22 = (t13 + 8U);
    t16 = *((int *)t22);
    t24 = (t2 + 0U);
    t25 = (t24 + 0U);
    *((int *)t25) = t10;
    t25 = (t24 + 4U);
    *((int *)t25) = t11;
    t25 = (t24 + 8U);
    *((int *)t25) = t16;
    t19 = (t11 - t10);
    t12 = (t19 * t16);
    t12 = (t12 + 1);
    t25 = (t24 + 12U);
    *((unsigned int *)t25) = t12;

LAB1:    return t0;
LAB3:    *((char **)t27) = *((char **)t3);
    goto LAB2;

LAB4:    t34 = ieee_p_1242562249_sub_1919365254_1242562249(IEEE_P_1242562249, t33, t3, t4, t5);
    t35 = (t33 + 12U);
    t20 = *((unsigned int *)t35);
    t36 = (1U * t20);
    t0 = xsi_get_transient_memory(t36);
    memcpy(t0, t34, t36);
    t37 = (t33 + 0U);
    t38 = *((int *)t37);
    t39 = (t33 + 4U);
    t40 = *((int *)t39);
    t41 = (t33 + 8U);
    t42 = *((int *)t41);
    t43 = (t2 + 0U);
    t44 = (t43 + 0U);
    *((int *)t44) = t38;
    t44 = (t43 + 4U);
    *((int *)t44) = t40;
    t44 = (t43 + 8U);
    *((int *)t44) = t42;
    t45 = (t40 - t38);
    t46 = (t45 * t42);
    t46 = (t46 + 1);
    t44 = (t43 + 12U);
    *((unsigned int *)t44) = t46;
    goto LAB1;

LAB5:    xsi_error(ng6);
    t0 = 0;
    goto LAB1;

LAB7:    goto LAB5;

LAB8:    goto LAB5;

}

char *work_p_0170319956_sub_146364992_170319956(char *t1, char *t2, char *t3, char *t4, unsigned char t5)
{
    char t6[248];
    char t7[24];
    char t13[16];
    char t27[16];
    char t33[8];
    char t53[16];
    char *t0;
    char *t8;
    unsigned int t9;
    int t10;
    int t11;
    unsigned int t12;
    char *t14;
    unsigned int t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t28;
    char *t29;
    int t30;
    char *t31;
    char *t32;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    unsigned char t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    int t43;
    char *t44;
    int t45;
    int t46;
    unsigned int t47;
    unsigned int t48;
    char *t49;
    unsigned char t50;
    unsigned char t51;
    unsigned char t52;

LAB0:    t8 = (t4 + 12U);
    t9 = *((unsigned int *)t8);
    t10 = (t9 - 1);
    t11 = (0 - t10);
    t12 = (t11 * -1);
    t12 = (t12 + 1);
    t12 = (t12 * 1U);
    t14 = (t4 + 12U);
    t15 = *((unsigned int *)t14);
    t16 = (t15 - 1);
    t17 = (t13 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = t16;
    t18 = (t17 + 4U);
    *((int *)t18) = 0;
    t18 = (t17 + 8U);
    *((int *)t18) = -1;
    t19 = (0 - t16);
    t20 = (t19 * -1);
    t20 = (t20 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t20;
    t18 = (t6 + 4U);
    t21 = ((IEEE_P_2592010699) + 4024);
    t22 = (t18 + 88U);
    *((char **)t22) = t21;
    t23 = (char *)alloca(t12);
    t24 = (t18 + 56U);
    *((char **)t24) = t23;
    xsi_type_set_default_value(t21, t23, t13);
    t25 = (t18 + 64U);
    *((char **)t25) = t13;
    t26 = (t18 + 80U);
    *((unsigned int *)t26) = t12;
    t28 = (t27 + 0U);
    t29 = (t28 + 0U);
    *((int *)t29) = 0;
    t29 = (t28 + 4U);
    *((int *)t29) = 0;
    t29 = (t28 + 8U);
    *((int *)t29) = -1;
    t30 = (0 - 0);
    t20 = (t30 * -1);
    t20 = (t20 + 1);
    t29 = (t28 + 12U);
    *((unsigned int *)t29) = t20;
    t29 = (t6 + 124U);
    t31 = ((IEEE_P_2592010699) + 4024);
    t32 = (t29 + 88U);
    *((char **)t32) = t31;
    t34 = (t29 + 56U);
    *((char **)t34) = t33;
    xsi_type_set_default_value(t31, t33, t27);
    t35 = (t29 + 64U);
    *((char **)t35) = t27;
    t36 = (t29 + 80U);
    *((unsigned int *)t36) = 1U;
    t37 = (t7 + 4U);
    t38 = (t3 != 0);
    if (t38 == 1)
        goto LAB3;

LAB2:    t39 = (t7 + 12U);
    *((char **)t39) = t4;
    t40 = (t7 + 20U);
    *((unsigned char *)t40) = t5;
    t41 = (t29 + 56U);
    t42 = *((char **)t41);
    t41 = (t27 + 0U);
    t43 = *((int *)t41);
    t44 = (t27 + 8U);
    t45 = *((int *)t44);
    t46 = (0 - t43);
    t20 = (t46 * t45);
    t47 = (1U * t20);
    t48 = (0 + t47);
    t49 = (t42 + t48);
    *((unsigned char *)t49) = t5;
    t50 = work_p_0170319956_sub_392603539_170319956(t1, t3, t4);
    if (t50 == 1)
        goto LAB7;

LAB8:    t51 = work_p_0170319956_sub_165010554_170319956(t1, t5);
    t38 = t51;

LAB9:    t52 = (!(t38));
    if (t52 != 0)
        goto LAB4;

LAB6:    t8 = (t27 + 12U);
    t9 = *((unsigned int *)t8);
    t9 = (t9 * 1U);
    t14 = xsi_get_transient_memory(t9);
    memset(t14, 0, t9);
    t17 = t14;
    memset(t17, (unsigned char)1, t9);
    t21 = (t29 + 56U);
    t22 = *((char **)t21);
    t21 = (t22 + 0);
    t24 = (t27 + 12U);
    t12 = *((unsigned int *)t24);
    t12 = (t12 * 1U);
    memcpy(t21, t14, t12);
    t8 = (t29 + 56U);
    t14 = *((char **)t8);
    t8 = (t27 + 12U);
    t9 = *((unsigned int *)t8);
    t9 = (t9 * 1U);
    t0 = xsi_get_transient_memory(t9);
    memcpy(t0, t14, t9);
    t17 = (t27 + 0U);
    t10 = *((int *)t17);
    t21 = (t27 + 4U);
    t11 = *((int *)t21);
    t22 = (t27 + 8U);
    t16 = *((int *)t22);
    t24 = (t2 + 0U);
    t25 = (t24 + 0U);
    *((int *)t25) = t10;
    t25 = (t24 + 4U);
    *((int *)t25) = t11;
    t25 = (t24 + 8U);
    *((int *)t25) = t16;
    t19 = (t11 - t10);
    t12 = (t19 * t16);
    t12 = (t12 + 1);
    t25 = (t24 + 12U);
    *((unsigned int *)t25) = t12;

LAB1:    return t0;
LAB3:    *((char **)t37) = *((char **)t3);
    goto LAB2;

LAB4:    t8 = (t29 + 56U);
    t14 = *((char **)t8);
    t8 = ieee_p_1242562249_sub_1547198987_1242562249(IEEE_P_1242562249, t53, t3, t4, t14, t27);
    t17 = (t53 + 12U);
    t9 = *((unsigned int *)t17);
    t12 = (1U * t9);
    t0 = xsi_get_transient_memory(t12);
    memcpy(t0, t8, t12);
    t21 = (t53 + 0U);
    t10 = *((int *)t21);
    t22 = (t53 + 4U);
    t11 = *((int *)t22);
    t24 = (t53 + 8U);
    t16 = *((int *)t24);
    t25 = (t2 + 0U);
    t26 = (t25 + 0U);
    *((int *)t26) = t10;
    t26 = (t25 + 4U);
    *((int *)t26) = t11;
    t26 = (t25 + 8U);
    *((int *)t26) = t16;
    t19 = (t11 - t10);
    t15 = (t19 * t16);
    t15 = (t15 + 1);
    t26 = (t25 + 12U);
    *((unsigned int *)t26) = t15;
    goto LAB1;

LAB5:    xsi_error(ng6);
    t0 = 0;
    goto LAB1;

LAB7:    t38 = (unsigned char)1;
    goto LAB9;

LAB10:    goto LAB5;

LAB11:    goto LAB5;

}

char *work_p_0170319956_sub_4092841352_170319956(char *t1, char *t2, char *t3, char *t4, char *t5, char *t6)
{
    char t7[248];
    char t8[40];
    char t14[16];
    char t32[16];
    char t56[16];
    char *t0;
    char *t9;
    unsigned int t10;
    int t11;
    int t12;
    unsigned int t13;
    char *t15;
    unsigned int t16;
    int t17;
    char *t18;
    char *t19;
    int t20;
    unsigned int t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    int t29;
    int t30;
    unsigned int t31;
    char *t33;
    unsigned int t34;
    int t35;
    char *t36;
    char *t37;
    int t38;
    unsigned int t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    unsigned char t47;
    char *t48;
    char *t49;
    unsigned char t50;
    char *t51;
    unsigned char t52;
    unsigned char t53;
    unsigned char t54;
    unsigned char t55;
    char *t57;
    char *t58;
    unsigned int t59;
    char *t60;
    int t61;
    char *t62;
    int t63;
    char *t64;
    int t65;
    char *t66;
    char *t67;
    int t68;
    unsigned int t69;

LAB0:    t9 = (t4 + 12U);
    t10 = *((unsigned int *)t9);
    t11 = (t10 - 1);
    t12 = (0 - t11);
    t13 = (t12 * -1);
    t13 = (t13 + 1);
    t13 = (t13 * 1U);
    t15 = (t4 + 12U);
    t16 = *((unsigned int *)t15);
    t17 = (t16 - 1);
    t18 = (t14 + 0U);
    t19 = (t18 + 0U);
    *((int *)t19) = t17;
    t19 = (t18 + 4U);
    *((int *)t19) = 0;
    t19 = (t18 + 8U);
    *((int *)t19) = -1;
    t20 = (0 - t17);
    t21 = (t20 * -1);
    t21 = (t21 + 1);
    t19 = (t18 + 12U);
    *((unsigned int *)t19) = t21;
    t19 = (t7 + 4U);
    t22 = ((IEEE_P_2592010699) + 4024);
    t23 = (t19 + 88U);
    *((char **)t23) = t22;
    t24 = (char *)alloca(t13);
    t25 = (t19 + 56U);
    *((char **)t25) = t24;
    xsi_type_set_default_value(t22, t24, t14);
    t26 = (t19 + 64U);
    *((char **)t26) = t14;
    t27 = (t19 + 80U);
    *((unsigned int *)t27) = t13;
    t28 = (t6 + 12U);
    t21 = *((unsigned int *)t28);
    t29 = (t21 - 1);
    t30 = (0 - t29);
    t31 = (t30 * -1);
    t31 = (t31 + 1);
    t31 = (t31 * 1U);
    t33 = (t6 + 12U);
    t34 = *((unsigned int *)t33);
    t35 = (t34 - 1);
    t36 = (t32 + 0U);
    t37 = (t36 + 0U);
    *((int *)t37) = t35;
    t37 = (t36 + 4U);
    *((int *)t37) = 0;
    t37 = (t36 + 8U);
    *((int *)t37) = -1;
    t38 = (0 - t35);
    t39 = (t38 * -1);
    t39 = (t39 + 1);
    t37 = (t36 + 12U);
    *((unsigned int *)t37) = t39;
    t37 = (t7 + 124U);
    t40 = ((IEEE_P_2592010699) + 4024);
    t41 = (t37 + 88U);
    *((char **)t41) = t40;
    t42 = (char *)alloca(t31);
    t43 = (t37 + 56U);
    *((char **)t43) = t42;
    xsi_type_set_default_value(t40, t42, t32);
    t44 = (t37 + 64U);
    *((char **)t44) = t32;
    t45 = (t37 + 80U);
    *((unsigned int *)t45) = t31;
    t46 = (t8 + 4U);
    t47 = (t3 != 0);
    if (t47 == 1)
        goto LAB3;

LAB2:    t48 = (t8 + 12U);
    *((char **)t48) = t4;
    t49 = (t8 + 20U);
    t50 = (t5 != 0);
    if (t50 == 1)
        goto LAB5;

LAB4:    t51 = (t8 + 28U);
    *((char **)t51) = t6;
    t53 = work_p_0170319956_sub_392603539_170319956(t1, t3, t4);
    if (t53 == 1)
        goto LAB9;

LAB10:    t54 = work_p_0170319956_sub_392603539_170319956(t1, t5, t6);
    t52 = t54;

LAB11:    t55 = (!(t52));
    if (t55 != 0)
        goto LAB6;

LAB8:    t9 = (t14 + 12U);
    t10 = *((unsigned int *)t9);
    t10 = (t10 * 1U);
    t15 = xsi_get_transient_memory(t10);
    memset(t15, 0, t10);
    t18 = t15;
    memset(t18, (unsigned char)1, t10);
    t22 = (t19 + 56U);
    t23 = *((char **)t22);
    t22 = (t23 + 0);
    t25 = (t14 + 12U);
    t13 = *((unsigned int *)t25);
    t13 = (t13 * 1U);
    memcpy(t22, t15, t13);
    t9 = (t32 + 12U);
    t10 = *((unsigned int *)t9);
    t10 = (t10 * 1U);
    t15 = xsi_get_transient_memory(t10);
    memset(t15, 0, t10);
    t18 = t15;
    memset(t18, (unsigned char)1, t10);
    t22 = (t37 + 56U);
    t23 = *((char **)t22);
    t22 = (t23 + 0);
    t25 = (t32 + 12U);
    t13 = *((unsigned int *)t25);
    t13 = (t13 * 1U);
    memcpy(t22, t15, t13);
    t9 = (t14 + 12U);
    t10 = *((unsigned int *)t9);
    t15 = (t32 + 12U);
    t13 = *((unsigned int *)t15);
    t47 = (t10 > t13);
    if (t47 != 0)
        goto LAB13;

LAB15:    t9 = (t37 + 56U);
    t15 = *((char **)t9);
    t9 = (t32 + 12U);
    t10 = *((unsigned int *)t9);
    t10 = (t10 * 1U);
    t0 = xsi_get_transient_memory(t10);
    memcpy(t0, t15, t10);
    t18 = (t32 + 0U);
    t11 = *((int *)t18);
    t22 = (t32 + 4U);
    t12 = *((int *)t22);
    t23 = (t32 + 8U);
    t17 = *((int *)t23);
    t25 = (t2 + 0U);
    t26 = (t25 + 0U);
    *((int *)t26) = t11;
    t26 = (t25 + 4U);
    *((int *)t26) = t12;
    t26 = (t25 + 8U);
    *((int *)t26) = t17;
    t20 = (t12 - t11);
    t13 = (t20 * t17);
    t13 = (t13 + 1);
    t26 = (t25 + 12U);
    *((unsigned int *)t26) = t13;

LAB1:    return t0;
LAB3:    *((char **)t46) = *((char **)t3);
    goto LAB2;

LAB5:    *((char **)t49) = *((char **)t5);
    goto LAB4;

LAB6:    t57 = ieee_p_1242562249_sub_1547270861_1242562249(IEEE_P_1242562249, t56, t3, t4, t5, t6);
    t58 = (t56 + 12U);
    t39 = *((unsigned int *)t58);
    t59 = (1U * t39);
    t0 = xsi_get_transient_memory(t59);
    memcpy(t0, t57, t59);
    t60 = (t56 + 0U);
    t61 = *((int *)t60);
    t62 = (t56 + 4U);
    t63 = *((int *)t62);
    t64 = (t56 + 8U);
    t65 = *((int *)t64);
    t66 = (t2 + 0U);
    t67 = (t66 + 0U);
    *((int *)t67) = t61;
    t67 = (t66 + 4U);
    *((int *)t67) = t63;
    t67 = (t66 + 8U);
    *((int *)t67) = t65;
    t68 = (t63 - t61);
    t69 = (t68 * t65);
    t69 = (t69 + 1);
    t67 = (t66 + 12U);
    *((unsigned int *)t67) = t69;
    goto LAB1;

LAB7:    xsi_error(ng7);
    t0 = 0;
    goto LAB1;

LAB9:    t52 = (unsigned char)1;
    goto LAB11;

LAB12:    goto LAB7;

LAB13:    t18 = (t19 + 56U);
    t22 = *((char **)t18);
    t18 = (t14 + 12U);
    t16 = *((unsigned int *)t18);
    t16 = (t16 * 1U);
    t0 = xsi_get_transient_memory(t16);
    memcpy(t0, t22, t16);
    t23 = (t14 + 0U);
    t11 = *((int *)t23);
    t25 = (t14 + 4U);
    t12 = *((int *)t25);
    t26 = (t14 + 8U);
    t17 = *((int *)t26);
    t27 = (t2 + 0U);
    t28 = (t27 + 0U);
    *((int *)t28) = t11;
    t28 = (t27 + 4U);
    *((int *)t28) = t12;
    t28 = (t27 + 8U);
    *((int *)t28) = t17;
    t20 = (t12 - t11);
    t21 = (t20 * t17);
    t21 = (t21 + 1);
    t28 = (t27 + 12U);
    *((unsigned int *)t28) = t21;
    goto LAB1;

LAB14:    goto LAB7;

LAB16:    goto LAB14;

LAB17:    goto LAB14;

}

char *work_p_0170319956_sub_433401739_170319956(char *t1, char *t2, char *t3, char *t4, int t5)
{
    char t6[128];
    char t7[24];
    char t13[16];
    char t33[16];
    char *t0;
    char *t8;
    unsigned int t9;
    int t10;
    int t11;
    unsigned int t12;
    char *t14;
    unsigned int t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    unsigned char t28;
    char *t29;
    char *t30;
    unsigned char t31;
    unsigned char t32;
    char *t34;
    char *t35;
    unsigned int t36;
    char *t37;
    int t38;
    char *t39;
    int t40;
    char *t41;
    int t42;
    char *t43;
    char *t44;
    int t45;
    unsigned int t46;

LAB0:    t8 = (t4 + 12U);
    t9 = *((unsigned int *)t8);
    t10 = (t9 - 1);
    t11 = (0 - t10);
    t12 = (t11 * -1);
    t12 = (t12 + 1);
    t12 = (t12 * 1U);
    t14 = (t4 + 12U);
    t15 = *((unsigned int *)t14);
    t16 = (t15 - 1);
    t17 = (t13 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = t16;
    t18 = (t17 + 4U);
    *((int *)t18) = 0;
    t18 = (t17 + 8U);
    *((int *)t18) = -1;
    t19 = (0 - t16);
    t20 = (t19 * -1);
    t20 = (t20 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t20;
    t18 = (t6 + 4U);
    t21 = ((IEEE_P_2592010699) + 4024);
    t22 = (t18 + 88U);
    *((char **)t22) = t21;
    t23 = (char *)alloca(t12);
    t24 = (t18 + 56U);
    *((char **)t24) = t23;
    xsi_type_set_default_value(t21, t23, t13);
    t25 = (t18 + 64U);
    *((char **)t25) = t13;
    t26 = (t18 + 80U);
    *((unsigned int *)t26) = t12;
    t27 = (t7 + 4U);
    t28 = (t3 != 0);
    if (t28 == 1)
        goto LAB3;

LAB2:    t29 = (t7 + 12U);
    *((char **)t29) = t4;
    t30 = (t7 + 20U);
    *((int *)t30) = t5;
    t31 = work_p_0170319956_sub_392603539_170319956(t1, t3, t4);
    t32 = (!(t31));
    if (t32 != 0)
        goto LAB4;

LAB6:    t8 = (t13 + 12U);
    t9 = *((unsigned int *)t8);
    t9 = (t9 * 1U);
    t14 = xsi_get_transient_memory(t9);
    memset(t14, 0, t9);
    t17 = t14;
    memset(t17, (unsigned char)1, t9);
    t21 = (t18 + 56U);
    t22 = *((char **)t21);
    t21 = (t22 + 0);
    t24 = (t13 + 12U);
    t12 = *((unsigned int *)t24);
    t12 = (t12 * 1U);
    memcpy(t21, t14, t12);
    t8 = (t18 + 56U);
    t14 = *((char **)t8);
    t8 = (t13 + 12U);
    t9 = *((unsigned int *)t8);
    t9 = (t9 * 1U);
    t0 = xsi_get_transient_memory(t9);
    memcpy(t0, t14, t9);
    t17 = (t13 + 0U);
    t10 = *((int *)t17);
    t21 = (t13 + 4U);
    t11 = *((int *)t21);
    t22 = (t13 + 8U);
    t16 = *((int *)t22);
    t24 = (t2 + 0U);
    t25 = (t24 + 0U);
    *((int *)t25) = t10;
    t25 = (t24 + 4U);
    *((int *)t25) = t11;
    t25 = (t24 + 8U);
    *((int *)t25) = t16;
    t19 = (t11 - t10);
    t12 = (t19 * t16);
    t12 = (t12 + 1);
    t25 = (t24 + 12U);
    *((unsigned int *)t25) = t12;

LAB1:    return t0;
LAB3:    *((char **)t27) = *((char **)t3);
    goto LAB2;

LAB4:    t34 = ieee_p_1242562249_sub_1919437128_1242562249(IEEE_P_1242562249, t33, t3, t4, t5);
    t35 = (t33 + 12U);
    t20 = *((unsigned int *)t35);
    t36 = (1U * t20);
    t0 = xsi_get_transient_memory(t36);
    memcpy(t0, t34, t36);
    t37 = (t33 + 0U);
    t38 = *((int *)t37);
    t39 = (t33 + 4U);
    t40 = *((int *)t39);
    t41 = (t33 + 8U);
    t42 = *((int *)t41);
    t43 = (t2 + 0U);
    t44 = (t43 + 0U);
    *((int *)t44) = t38;
    t44 = (t43 + 4U);
    *((int *)t44) = t40;
    t44 = (t43 + 8U);
    *((int *)t44) = t42;
    t45 = (t40 - t38);
    t46 = (t45 * t42);
    t46 = (t46 + 1);
    t44 = (t43 + 12U);
    *((unsigned int *)t44) = t46;
    goto LAB1;

LAB5:    xsi_error(ng7);
    t0 = 0;
    goto LAB1;

LAB7:    goto LAB5;

LAB8:    goto LAB5;

}

char *work_p_0170319956_sub_344959155_170319956(char *t1, char *t2, int t3, char *t4, char *t5)
{
    char t6[128];
    char t7[24];
    char t13[16];
    char t33[16];
    char *t0;
    char *t8;
    unsigned int t9;
    int t10;
    int t11;
    unsigned int t12;
    char *t14;
    unsigned int t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned char t29;
    char *t30;
    unsigned char t31;
    unsigned char t32;
    char *t34;
    char *t35;
    unsigned int t36;
    char *t37;
    int t38;
    char *t39;
    int t40;
    char *t41;
    int t42;
    char *t43;
    char *t44;
    int t45;
    unsigned int t46;

LAB0:    t8 = (t5 + 12U);
    t9 = *((unsigned int *)t8);
    t10 = (t9 - 1);
    t11 = (0 - t10);
    t12 = (t11 * -1);
    t12 = (t12 + 1);
    t12 = (t12 * 1U);
    t14 = (t5 + 12U);
    t15 = *((unsigned int *)t14);
    t16 = (t15 - 1);
    t17 = (t13 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = t16;
    t18 = (t17 + 4U);
    *((int *)t18) = 0;
    t18 = (t17 + 8U);
    *((int *)t18) = -1;
    t19 = (0 - t16);
    t20 = (t19 * -1);
    t20 = (t20 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t20;
    t18 = (t6 + 4U);
    t21 = ((IEEE_P_2592010699) + 4024);
    t22 = (t18 + 88U);
    *((char **)t22) = t21;
    t23 = (char *)alloca(t12);
    t24 = (t18 + 56U);
    *((char **)t24) = t23;
    xsi_type_set_default_value(t21, t23, t13);
    t25 = (t18 + 64U);
    *((char **)t25) = t13;
    t26 = (t18 + 80U);
    *((unsigned int *)t26) = t12;
    t27 = (t7 + 4U);
    *((int *)t27) = t3;
    t28 = (t7 + 8U);
    t29 = (t4 != 0);
    if (t29 == 1)
        goto LAB3;

LAB2:    t30 = (t7 + 16U);
    *((char **)t30) = t5;
    t31 = work_p_0170319956_sub_392603539_170319956(t1, t4, t5);
    t32 = (!(t31));
    if (t32 != 0)
        goto LAB4;

LAB6:    t8 = (t13 + 12U);
    t9 = *((unsigned int *)t8);
    t9 = (t9 * 1U);
    t14 = xsi_get_transient_memory(t9);
    memset(t14, 0, t9);
    t17 = t14;
    memset(t17, (unsigned char)1, t9);
    t21 = (t18 + 56U);
    t22 = *((char **)t21);
    t21 = (t22 + 0);
    t24 = (t13 + 12U);
    t12 = *((unsigned int *)t24);
    t12 = (t12 * 1U);
    memcpy(t21, t14, t12);
    t8 = (t18 + 56U);
    t14 = *((char **)t8);
    t8 = (t13 + 12U);
    t9 = *((unsigned int *)t8);
    t9 = (t9 * 1U);
    t0 = xsi_get_transient_memory(t9);
    memcpy(t0, t14, t9);
    t17 = (t13 + 0U);
    t10 = *((int *)t17);
    t21 = (t13 + 4U);
    t11 = *((int *)t21);
    t22 = (t13 + 8U);
    t16 = *((int *)t22);
    t24 = (t2 + 0U);
    t25 = (t24 + 0U);
    *((int *)t25) = t10;
    t25 = (t24 + 4U);
    *((int *)t25) = t11;
    t25 = (t24 + 8U);
    *((int *)t25) = t16;
    t19 = (t11 - t10);
    t12 = (t19 * t16);
    t12 = (t12 + 1);
    t25 = (t24 + 12U);
    *((unsigned int *)t25) = t12;

LAB1:    return t0;
LAB3:    *((char **)t28) = *((char **)t4);
    goto LAB2;

LAB4:    t34 = ieee_p_1242562249_sub_1654287348_1242562249(IEEE_P_1242562249, t33, t3, t4, t5);
    t35 = (t33 + 12U);
    t20 = *((unsigned int *)t35);
    t36 = (1U * t20);
    t0 = xsi_get_transient_memory(t36);
    memcpy(t0, t34, t36);
    t37 = (t33 + 0U);
    t38 = *((int *)t37);
    t39 = (t33 + 4U);
    t40 = *((int *)t39);
    t41 = (t33 + 8U);
    t42 = *((int *)t41);
    t43 = (t2 + 0U);
    t44 = (t43 + 0U);
    *((int *)t44) = t38;
    t44 = (t43 + 4U);
    *((int *)t44) = t40;
    t44 = (t43 + 8U);
    *((int *)t44) = t42;
    t45 = (t40 - t38);
    t46 = (t45 * t42);
    t46 = (t46 + 1);
    t44 = (t43 + 12U);
    *((unsigned int *)t44) = t46;
    goto LAB1;

LAB5:    xsi_error(ng7);
    t0 = 0;
    goto LAB1;

LAB7:    goto LAB5;

LAB8:    goto LAB5;

}

char *work_p_0170319956_sub_146436866_170319956(char *t1, char *t2, char *t3, char *t4, unsigned char t5)
{
    char t6[248];
    char t7[24];
    char t13[16];
    char t27[16];
    char t33[8];
    char t53[16];
    char *t0;
    char *t8;
    unsigned int t9;
    int t10;
    int t11;
    unsigned int t12;
    char *t14;
    unsigned int t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t28;
    char *t29;
    int t30;
    char *t31;
    char *t32;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    unsigned char t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    int t43;
    char *t44;
    int t45;
    int t46;
    unsigned int t47;
    unsigned int t48;
    char *t49;
    unsigned char t50;
    unsigned char t51;
    unsigned char t52;

LAB0:    t8 = (t4 + 12U);
    t9 = *((unsigned int *)t8);
    t10 = (t9 - 1);
    t11 = (0 - t10);
    t12 = (t11 * -1);
    t12 = (t12 + 1);
    t12 = (t12 * 1U);
    t14 = (t4 + 12U);
    t15 = *((unsigned int *)t14);
    t16 = (t15 - 1);
    t17 = (t13 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = t16;
    t18 = (t17 + 4U);
    *((int *)t18) = 0;
    t18 = (t17 + 8U);
    *((int *)t18) = -1;
    t19 = (0 - t16);
    t20 = (t19 * -1);
    t20 = (t20 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t20;
    t18 = (t6 + 4U);
    t21 = ((IEEE_P_2592010699) + 4024);
    t22 = (t18 + 88U);
    *((char **)t22) = t21;
    t23 = (char *)alloca(t12);
    t24 = (t18 + 56U);
    *((char **)t24) = t23;
    xsi_type_set_default_value(t21, t23, t13);
    t25 = (t18 + 64U);
    *((char **)t25) = t13;
    t26 = (t18 + 80U);
    *((unsigned int *)t26) = t12;
    t28 = (t27 + 0U);
    t29 = (t28 + 0U);
    *((int *)t29) = 0;
    t29 = (t28 + 4U);
    *((int *)t29) = 0;
    t29 = (t28 + 8U);
    *((int *)t29) = -1;
    t30 = (0 - 0);
    t20 = (t30 * -1);
    t20 = (t20 + 1);
    t29 = (t28 + 12U);
    *((unsigned int *)t29) = t20;
    t29 = (t6 + 124U);
    t31 = ((IEEE_P_2592010699) + 4024);
    t32 = (t29 + 88U);
    *((char **)t32) = t31;
    t34 = (t29 + 56U);
    *((char **)t34) = t33;
    xsi_type_set_default_value(t31, t33, t27);
    t35 = (t29 + 64U);
    *((char **)t35) = t27;
    t36 = (t29 + 80U);
    *((unsigned int *)t36) = 1U;
    t37 = (t7 + 4U);
    t38 = (t3 != 0);
    if (t38 == 1)
        goto LAB3;

LAB2:    t39 = (t7 + 12U);
    *((char **)t39) = t4;
    t40 = (t7 + 20U);
    *((unsigned char *)t40) = t5;
    t41 = (t29 + 56U);
    t42 = *((char **)t41);
    t41 = (t27 + 0U);
    t43 = *((int *)t41);
    t44 = (t27 + 8U);
    t45 = *((int *)t44);
    t46 = (0 - t43);
    t20 = (t46 * t45);
    t47 = (1U * t20);
    t48 = (0 + t47);
    t49 = (t42 + t48);
    *((unsigned char *)t49) = t5;
    t50 = work_p_0170319956_sub_392603539_170319956(t1, t3, t4);
    if (t50 == 1)
        goto LAB7;

LAB8:    t51 = work_p_0170319956_sub_165010554_170319956(t1, t5);
    t38 = t51;

LAB9:    t52 = (!(t38));
    if (t52 != 0)
        goto LAB4;

LAB6:    t8 = (t13 + 12U);
    t9 = *((unsigned int *)t8);
    t9 = (t9 * 1U);
    t14 = xsi_get_transient_memory(t9);
    memset(t14, 0, t9);
    t17 = t14;
    memset(t17, (unsigned char)1, t9);
    t21 = (t18 + 56U);
    t22 = *((char **)t21);
    t21 = (t22 + 0);
    t24 = (t13 + 12U);
    t12 = *((unsigned int *)t24);
    t12 = (t12 * 1U);
    memcpy(t21, t14, t12);
    t8 = (t18 + 56U);
    t14 = *((char **)t8);
    t8 = (t13 + 12U);
    t9 = *((unsigned int *)t8);
    t9 = (t9 * 1U);
    t0 = xsi_get_transient_memory(t9);
    memcpy(t0, t14, t9);
    t17 = (t13 + 0U);
    t10 = *((int *)t17);
    t21 = (t13 + 4U);
    t11 = *((int *)t21);
    t22 = (t13 + 8U);
    t16 = *((int *)t22);
    t24 = (t2 + 0U);
    t25 = (t24 + 0U);
    *((int *)t25) = t10;
    t25 = (t24 + 4U);
    *((int *)t25) = t11;
    t25 = (t24 + 8U);
    *((int *)t25) = t16;
    t19 = (t11 - t10);
    t12 = (t19 * t16);
    t12 = (t12 + 1);
    t25 = (t24 + 12U);
    *((unsigned int *)t25) = t12;

LAB1:    return t0;
LAB3:    *((char **)t37) = *((char **)t3);
    goto LAB2;

LAB4:    t8 = (t29 + 56U);
    t14 = *((char **)t8);
    t8 = ieee_p_1242562249_sub_1547270861_1242562249(IEEE_P_1242562249, t53, t3, t4, t14, t27);
    t17 = (t53 + 12U);
    t9 = *((unsigned int *)t17);
    t12 = (1U * t9);
    t0 = xsi_get_transient_memory(t12);
    memcpy(t0, t8, t12);
    t21 = (t53 + 0U);
    t10 = *((int *)t21);
    t22 = (t53 + 4U);
    t11 = *((int *)t22);
    t24 = (t53 + 8U);
    t16 = *((int *)t24);
    t25 = (t2 + 0U);
    t26 = (t25 + 0U);
    *((int *)t26) = t10;
    t26 = (t25 + 4U);
    *((int *)t26) = t11;
    t26 = (t25 + 8U);
    *((int *)t26) = t16;
    t19 = (t11 - t10);
    t15 = (t19 * t16);
    t15 = (t15 + 1);
    t26 = (t25 + 12U);
    *((unsigned int *)t26) = t15;
    goto LAB1;

LAB5:    xsi_error(ng7);
    t0 = 0;
    goto LAB1;

LAB7:    t38 = (unsigned char)1;
    goto LAB9;

LAB10:    goto LAB5;

LAB11:    goto LAB5;

}


extern void work_p_0170319956_init()
{
	static char *se[] = {(void *)work_p_0170319956_sub_392603539_170319956,(void *)work_p_0170319956_sub_165010554_170319956,(void *)work_p_0170319956_sub_2382061885_170319956,(void *)work_p_0170319956_sub_3180367557_170319956,(void *)work_p_0170319956_sub_3505537527_170319956,(void *)work_p_0170319956_sub_3397525853_170319956,(void *)work_p_0170319956_sub_3407386099_170319956,(void *)work_p_0170319956_sub_3642789088_170319956,(void *)work_p_0170319956_sub_2396784601_170319956,(void *)work_p_0170319956_sub_1525193009_170319956,(void *)work_p_0170319956_sub_2511478883_170319956,(void *)work_p_0170319956_sub_1376644890_170319956,(void *)work_p_0170319956_sub_4092769478_170319956,(void *)work_p_0170319956_sub_433329865_170319956,(void *)work_p_0170319956_sub_146364992_170319956,(void *)work_p_0170319956_sub_4092841352_170319956,(void *)work_p_0170319956_sub_433401739_170319956,(void *)work_p_0170319956_sub_344959155_170319956,(void *)work_p_0170319956_sub_146436866_170319956};
	xsi_register_didat("work_p_0170319956", "isim/AVR8_tb_isim_beh.exe.sim/work/p_0170319956.didat");
	xsi_register_subprogram_executes(se);
}
