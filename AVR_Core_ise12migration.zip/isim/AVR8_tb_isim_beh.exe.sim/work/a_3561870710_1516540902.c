/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7dea747 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/dbdev/My Dropbox/GadgetFactory/AVR8/svn/trunk/resync/rsnc_bit.vhd";



static void work_a_3561870710_1516540902_p_0(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    int t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;

LAB0:    xsi_set_current_line(43, ng0);
    t2 = (t0 + 1296U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t5 = (t4 == (unsigned char)3);
    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 4400);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(44, ng0);
    t7 = (t0 + 1936U);
    t8 = *((char **)t7);
    if (1 > 0)
        goto LAB8;

LAB9:    if (-1 == -1)
        goto LAB13;

LAB14:    t9 = 1;

LAB10:    t10 = (t9 - 1);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t7 = (t8 + t13);
    t14 = *((unsigned char *)t7);
    t15 = (t0 + 4528);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = t14;
    xsi_driver_first_trans_delta(t15, 1U, 1, 0LL);
    goto LAB3;

LAB5:    t2 = (t0 + 1256U);
    t6 = xsi_signal_has_event(t2);
    t1 = t6;
    goto LAB7;

LAB8:    if (-1 == 1)
        goto LAB11;

LAB12:    t9 = 0;
    goto LAB10;

LAB11:    t9 = 1;
    goto LAB10;

LAB13:    t9 = 0;
    goto LAB10;

}

static void work_a_3561870710_1516540902_p_1(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;

LAB0:    xsi_set_current_line(51, ng0);
    t2 = (t0 + 1296U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t5 = (t4 == (unsigned char)3);
    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 4416);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(52, ng0);
    t7 = (t0 + 1936U);
    t8 = *((char **)t7);
    if (1 > 0)
        goto LAB8;

LAB9:    if (-1 == -1)
        goto LAB13;

LAB14:    t9 = 0;

LAB10:    t10 = (1 - t9);
    t11 = (t10 * 1U);
    t12 = (0 + t11);
    t7 = (t8 + t12);
    t13 = (t0 + 4592);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t7, 1U);
    xsi_driver_first_trans_delta(t13, 0U, 1U, 0LL);
    goto LAB3;

LAB5:    t2 = (t0 + 1256U);
    t6 = xsi_signal_has_event(t2);
    t1 = t6;
    goto LAB7;

LAB8:    if (-1 == 1)
        goto LAB11;

LAB12:    t9 = 1;
    goto LAB10;

LAB11:    t9 = 0;
    goto LAB10;

LAB13:    t9 = 1;
    goto LAB10;

}

static void work_a_3561870710_1516540902_p_2(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    int t8;
    int t9;
    int t10;
    int t11;
    int t12;
    int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    int t17;
    int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;

LAB0:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 1456U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 4656);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_delta(t1, 1U, 1, 0LL);
    xsi_set_current_line(59, ng0);
    if (1 > 0)
        goto LAB6;

LAB7:    if (-1 == -1)
        goto LAB11;

LAB12:    t8 = 0;

LAB8:    t1 = (t0 + 7390);
    *((int *)t1) = 1;
    t2 = (t0 + 7394);
    *((int *)t2) = t8;
    t9 = 1;
    t10 = t8;

LAB2:    if (t9 <= t10)
        goto LAB3;

LAB5:    t1 = (t0 + 4432);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(60, ng0);
    t4 = (t0 + 1776U);
    t5 = *((char **)t4);
    t4 = (t0 + 7390);
    t11 = *((int *)t4);
    t12 = (t11 - 1);
    t13 = (t12 - 1);
    t14 = (t13 * -1);
    xsi_vhdl_check_range_of_index(1, 0, -1, t12);
    t15 = (1U * t14);
    t16 = (0 + t15);
    t6 = (t5 + t16);
    t3 = *((unsigned char *)t6);
    t7 = (t0 + 7390);
    t17 = *((int *)t7);
    t18 = (t17 - 1);
    t19 = (t18 * -1);
    t20 = (1 * t19);
    t21 = (0U + t20);
    t22 = (t0 + 4656);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    *((unsigned char *)t26) = t3;
    xsi_driver_first_trans_delta(t22, t21, 1, 0LL);

LAB4:    t1 = (t0 + 7390);
    t9 = *((int *)t1);
    t2 = (t0 + 7394);
    t10 = *((int *)t2);
    if (t9 == t10)
        goto LAB5;

LAB13:    t8 = (t9 + 1);
    t9 = t8;
    t4 = (t0 + 7390);
    *((int *)t4) = t9;
    goto LAB2;

LAB6:    if (-1 == 1)
        goto LAB9;

LAB10:    t8 = 1;
    goto LAB8;

LAB9:    t8 = 0;
    goto LAB8;

LAB11:    t8 = 1;
    goto LAB8;

}

static void work_a_3561870710_1516540902_p_3(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned char t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;

LAB0:    xsi_set_current_line(64, ng0);

LAB3:    t1 = (t0 + 1776U);
    t2 = *((char **)t1);
    if (1 > 0)
        goto LAB5;

LAB6:    if (-1 == -1)
        goto LAB10;

LAB11:    t3 = 0;

LAB7:    t4 = (t3 - 1);
    t5 = (t4 * -1);
    t6 = (1U * t5);
    t7 = (0 + t6);
    t1 = (t2 + t7);
    t8 = *((unsigned char *)t1);
    t9 = (t0 + 4720);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = t8;
    xsi_driver_first_trans_fast_port(t9);

LAB2:    t14 = (t0 + 4448);
    *((int *)t14) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    if (-1 == 1)
        goto LAB8;

LAB9:    t3 = 1;
    goto LAB7;

LAB8:    t3 = 0;
    goto LAB7;

LAB10:    t3 = 1;
    goto LAB7;

}


extern void work_a_3561870710_1516540902_init()
{
	static char *pe[] = {(void *)work_a_3561870710_1516540902_p_0,(void *)work_a_3561870710_1516540902_p_1,(void *)work_a_3561870710_1516540902_p_2,(void *)work_a_3561870710_1516540902_p_3};
	xsi_register_didat("work_a_3561870710_1516540902", "isim/AVR8_tb_isim_beh.exe.sim/work/a_3561870710_1516540902.didat");
	xsi_register_executes(pe);
}
