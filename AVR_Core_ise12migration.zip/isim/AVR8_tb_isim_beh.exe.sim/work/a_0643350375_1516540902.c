/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7dea747 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *IEEE_P_2592010699;
static const char *ng1 = "C:/dbdev/My Dropbox/GadgetFactory/AVR8/svn/trunk/spi_mod/spi_mod.vhd";
extern char *WORK_P_0170319956;
extern char *WORK_P_3602289512;

unsigned char ieee_p_2592010699_sub_1605435078_2592010699(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_1690584930_2592010699(char *, unsigned char );
int work_p_0170319956_sub_3397525853_170319956(char *, char *, char *);
char *work_p_0170319956_sub_433329865_170319956(char *, char *, char *, char *, int );


char *work_a_0643350375_1516540902_sub_3065100407_1516540902(char *t1, char *t2, char *t3, char *t4)
{
    char t5[128];
    char t6[24];
    char t9[16];
    char *t0;
    char *t7;
    unsigned int t8;
    char *t10;
    int t11;
    char *t12;
    int t13;
    char *t14;
    int t15;
    char *t16;
    char *t17;
    int t18;
    unsigned int t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned char t27;
    char *t28;
    char *t29;
    int t30;
    char *t31;
    int t32;
    char *t33;
    int t34;
    int t35;
    int t36;
    int t37;
    int t38;
    int t39;
    char *t40;
    int t41;
    char *t42;
    int t43;
    char *t44;
    int t45;
    int t46;
    char *t47;
    int t48;
    char *t49;
    int t50;
    int t51;
    char *t52;
    int t53;
    unsigned int t54;
    unsigned int t55;
    char *t56;
    unsigned char t57;
    char *t58;
    char *t59;
    int t60;
    char *t61;
    int t62;
    int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    char *t67;

LAB0:    t7 = (t4 + 12U);
    t8 = *((unsigned int *)t7);
    t8 = (t8 * 1U);
    t10 = (t4 + 0U);
    t11 = *((int *)t10);
    t12 = (t4 + 4U);
    t13 = *((int *)t12);
    t14 = (t4 + 8U);
    t15 = *((int *)t14);
    t16 = (t9 + 0U);
    t17 = (t16 + 0U);
    *((int *)t17) = t11;
    t17 = (t16 + 4U);
    *((int *)t17) = t13;
    t17 = (t16 + 8U);
    *((int *)t17) = t15;
    t18 = (t13 - t11);
    t19 = (t18 * t15);
    t19 = (t19 + 1);
    t17 = (t16 + 12U);
    *((unsigned int *)t17) = t19;
    t17 = (t5 + 4U);
    t20 = ((IEEE_P_2592010699) + 4024);
    t21 = (t17 + 88U);
    *((char **)t21) = t20;
    t22 = (char *)alloca(t8);
    t23 = (t17 + 56U);
    *((char **)t23) = t22;
    xsi_type_set_default_value(t20, t22, t9);
    t24 = (t17 + 64U);
    *((char **)t24) = t9;
    t25 = (t17 + 80U);
    *((unsigned int *)t25) = t8;
    t26 = (t6 + 4U);
    t27 = (t3 != 0);
    if (t27 == 1)
        goto LAB3;

LAB2:    t28 = (t6 + 12U);
    *((char **)t28) = t4;
    t29 = (t9 + 8U);
    t30 = *((int *)t29);
    t31 = (t9 + 4U);
    t32 = *((int *)t31);
    t33 = (t9 + 0U);
    t34 = *((int *)t33);
    t35 = t34;
    t36 = t32;

LAB4:    t37 = (t36 * t30);
    t38 = (t35 * t30);
    if (t38 <= t37)
        goto LAB5;

LAB7:    t7 = (t17 + 56U);
    t10 = *((char **)t7);
    t7 = (t9 + 12U);
    t8 = *((unsigned int *)t7);
    t8 = (t8 * 1U);
    t0 = xsi_get_transient_memory(t8);
    memcpy(t0, t10, t8);
    t12 = (t9 + 0U);
    t11 = *((int *)t12);
    t14 = (t9 + 4U);
    t13 = *((int *)t14);
    t16 = (t9 + 8U);
    t15 = *((int *)t16);
    t20 = (t2 + 0U);
    t21 = (t20 + 0U);
    *((int *)t21) = t11;
    t21 = (t20 + 4U);
    *((int *)t21) = t13;
    t21 = (t20 + 8U);
    *((int *)t21) = t15;
    t18 = (t13 - t11);
    t19 = (t18 * t15);
    t19 = (t19 + 1);
    t21 = (t20 + 12U);
    *((unsigned int *)t21) = t19;

LAB1:    return t0;
LAB3:    *((char **)t26) = *((char **)t3);
    goto LAB2;

LAB5:    t40 = (t4 + 0U);
    t41 = *((int *)t40);
    t42 = (t4 + 4U);
    t43 = *((int *)t42);
    t44 = (t4 + 8U);
    t45 = *((int *)t44);
    if (t41 > t43)
        goto LAB8;

LAB9:    if (t45 == -1)
        goto LAB13;

LAB14:    t39 = t43;

LAB10:    t46 = (t39 - t35);
    t47 = (t4 + 0U);
    t48 = *((int *)t47);
    t49 = (t4 + 8U);
    t50 = *((int *)t49);
    t51 = (t46 - t48);
    t19 = (t51 * t50);
    t52 = (t4 + 4U);
    t53 = *((int *)t52);
    xsi_vhdl_check_range_of_index(t48, t53, t50, t46);
    t54 = (1U * t19);
    t55 = (0 + t54);
    t56 = (t3 + t55);
    t57 = *((unsigned char *)t56);
    t58 = (t17 + 56U);
    t59 = *((char **)t58);
    t58 = (t9 + 0U);
    t60 = *((int *)t58);
    t61 = (t9 + 8U);
    t62 = *((int *)t61);
    t63 = (t35 - t60);
    t64 = (t63 * t62);
    t65 = (1U * t64);
    t66 = (0 + t65);
    t67 = (t59 + t66);
    *((unsigned char *)t67) = t57;

LAB6:    if (t35 == t36)
        goto LAB7;

LAB15:    t11 = (t35 + t30);
    t35 = t11;
    goto LAB4;

LAB8:    if (t45 == 1)
        goto LAB11;

LAB12:    t39 = t41;
    goto LAB10;

LAB11:    t39 = t43;
    goto LAB10;

LAB13:    t39 = t41;
    goto LAB10;

LAB16:;
}

static void work_a_0643350375_1516540902_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    unsigned char t13;
    int t14;
    int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;

LAB0:    xsi_set_current_line(166, ng1);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)2);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t4 = *((unsigned char *)t2);
    t11 = (t4 == (unsigned char)3);
    if (t11 == 1)
        goto LAB7;

LAB8:    t3 = (unsigned char)0;

LAB9:    if (t3 != 0)
        goto LAB5;

LAB6:
LAB3:    t1 = (t0 + 19360);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(168, ng1);
    t1 = xsi_get_transient_memory(8U);
    memset(t1, 0, 8U);
    t5 = t1;
    memset(t5, (unsigned char)2, 8U);
    t6 = (t0 + 19808);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 8U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(170, ng1);
    t1 = (t0 + 19872);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_delta(t1, 0U, 1, 0LL);
    xsi_set_current_line(171, ng1);
    t1 = (t0 + 19872);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_delta(t1, 1U, 1, 0LL);
    xsi_set_current_line(172, ng1);
    t1 = (t0 + 19872);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_delta(t1, 7U, 1, 0LL);
    xsi_set_current_line(174, ng1);
    t1 = xsi_get_transient_memory(6U);
    memset(t1, 0, 6U);
    t2 = t1;
    memset(t2, (unsigned char)2, 6U);
    t5 = (t0 + 19936);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(175, ng1);
    t1 = (t0 + 20000);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(177, ng1);
    t1 = (t0 + 20064);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(178, ng1);
    t1 = (t0 + 20128);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(180, ng1);
    t1 = xsi_get_transient_memory(8U);
    memset(t1, 0, 8U);
    t2 = t1;
    memset(t2, (unsigned char)3, 8U);
    t5 = (t0 + 20192);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(181, ng1);
    t1 = xsi_get_transient_memory(8U);
    memset(t1, 0, 8U);
    t2 = t1;
    memset(t2, (unsigned char)2, 8U);
    t5 = (t0 + 20256);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 8U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(183, ng1);
    t1 = (t0 + 20320);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(184, ng1);
    t1 = (t0 + 20384);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(185, ng1);
    t1 = (t0 + 20448);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(187, ng1);
    t1 = (t0 + 20512);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(188, ng1);
    t1 = (t0 + 20576);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(189, ng1);
    t1 = (t0 + 20640);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(190, ng1);
    t1 = (t0 + 20704);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(192, ng1);
    t1 = (t0 + 20768);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(193, ng1);
    t1 = (t0 + 20832);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(194, ng1);
    t1 = (t0 + 20896);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB3;

LAB5:    xsi_set_current_line(198, ng1);
    t5 = (t0 + 5352U);
    t6 = *((char **)t5);
    t13 = *((unsigned char *)t6);
    t5 = (t0 + 19808);
    t7 = (t5 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = t13;
    xsi_driver_first_trans_delta(t5, 0U, 1, 0LL);
    xsi_set_current_line(199, ng1);
    t1 = (t0 + 5512U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 19808);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_delta(t1, 1U, 1, 0LL);
    xsi_set_current_line(200, ng1);
    t1 = (t0 + 5672U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 19808);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_delta(t1, 2U, 1, 0LL);
    xsi_set_current_line(201, ng1);
    t1 = (t0 + 5832U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 19808);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_delta(t1, 4U, 1, 0LL);
    xsi_set_current_line(202, ng1);
    t1 = (t0 + 5992U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 19808);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_delta(t1, 5U, 1, 0LL);
    xsi_set_current_line(203, ng1);
    t1 = (t0 + 6152U);
    t2 = *((char **)t1);
    t1 = (t0 + 19808);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 2U);
    xsi_driver_first_trans_delta(t1, 6U, 2U, 0LL);
    xsi_set_current_line(205, ng1);
    t1 = (t0 + 10792U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 19808);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_delta(t1, 3U, 1, 0LL);
    xsi_set_current_line(206, ng1);
    t1 = (t0 + 10952U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 19872);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_delta(t1, 0U, 1, 0LL);
    xsi_set_current_line(207, ng1);
    t1 = (t0 + 6312U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 19872);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_delta(t1, 7U, 1, 0LL);
    xsi_set_current_line(208, ng1);
    t1 = (t0 + 11112U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 19872);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_delta(t1, 1U, 1, 0LL);
    xsi_set_current_line(210, ng1);
    t1 = (t0 + 7112U);
    t2 = *((char **)t1);
    t1 = (t0 + 19936);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 6U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(211, ng1);
    t1 = (t0 + 7752U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 20000);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(212, ng1);
    t1 = (t0 + 8072U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 20064);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(213, ng1);
    t1 = (t0 + 9992U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 20128);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(214, ng1);
    t1 = (t0 + 6952U);
    t2 = *((char **)t1);
    t1 = (t0 + 20192);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 8U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(215, ng1);
    t1 = (t0 + 6632U);
    t2 = *((char **)t1);
    t1 = (t0 + 20256);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 8U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(216, ng1);
    t1 = (t0 + 4712U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 20320);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(217, ng1);
    t1 = (t0 + 10312U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 20384);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(218, ng1);
    t1 = (t0 + 10632U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 20448);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(220, ng1);
    t1 = (t0 + 8392U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 20576);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(221, ng1);
    t1 = (t0 + 8392U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 20512);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(222, ng1);
    t1 = (t0 + 6952U);
    t2 = *((char **)t1);
    if (7 > 0)
        goto LAB10;

LAB11:    if (-1 == -1)
        goto LAB15;

LAB16:    t14 = 0;

LAB12:    t15 = (t14 - 7);
    t16 = (t15 * -1);
    t17 = (1U * t16);
    t18 = (0 + t17);
    t1 = (t2 + t18);
    t3 = *((unsigned char *)t1);
    t5 = (t0 + 20640);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t3;
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(223, ng1);
    t1 = (t0 + 6952U);
    t2 = *((char **)t1);
    if (7 > 0)
        goto LAB17;

LAB18:    if (-1 == -1)
        goto LAB22;

LAB23:    t14 = 0;

LAB19:    t15 = (t14 - 7);
    t16 = (t15 * -1);
    t17 = (1U * t16);
    t18 = (0 + t17);
    t1 = (t2 + t18);
    t3 = *((unsigned char *)t1);
    t5 = (t0 + 20704);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t3;
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(225, ng1);
    t1 = (t0 + 9192U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 20768);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(226, ng1);
    t1 = (t0 + 8872U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 20832);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(227, ng1);
    t1 = (t0 + 11272U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 20896);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_fast(t1);
    goto LAB3;

LAB7:    t1 = (t0 + 1152U);
    t12 = xsi_signal_has_event(t1);
    t3 = t12;
    goto LAB9;

LAB10:    if (-1 == 1)
        goto LAB13;

LAB14:    t14 = 7;
    goto LAB12;

LAB13:    t14 = 0;
    goto LAB12;

LAB15:    t14 = 7;
    goto LAB12;

LAB17:    if (-1 == 1)
        goto LAB20;

LAB21:    t14 = 7;
    goto LAB19;

LAB20:    t14 = 0;
    goto LAB19;

LAB22:    t14 = 7;
    goto LAB19;

}

static void work_a_0643350375_1516540902_p_1(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    int t13;
    unsigned char t14;
    unsigned char t15;
    unsigned char t16;
    int t17;
    unsigned char t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;

LAB0:    xsi_set_current_line(236, ng1);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t3 = (7 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 20960);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(237, ng1);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t3 = (6 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 21024);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(238, ng1);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t3 = (5 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 21088);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(239, ng1);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t3 = (3 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 21152);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(240, ng1);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t3 = (2 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 21216);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(241, ng1);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t4 = (7 - 1);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t8 = (t0 + 21280);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t1, 2U);
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(242, ng1);
    t1 = (t0 + 5192U);
    t2 = *((char **)t1);
    t3 = (0 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 21344);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(244, ng1);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 33508U);
    t3 = work_p_0170319956_sub_3397525853_170319956(WORK_P_0170319956, t2, t1);
    t8 = ((WORK_P_3602289512) + 2728U);
    t9 = *((char **)t8);
    t13 = *((int *)t9);
    t14 = (t3 == t13);
    if (t14 == 1)
        goto LAB5;

LAB6:    t7 = (unsigned char)0;

LAB7:    if (t7 != 0)
        goto LAB2;

LAB4:
LAB3:    xsi_set_current_line(253, ng1);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 33508U);
    t3 = work_p_0170319956_sub_3397525853_170319956(WORK_P_0170319956, t2, t1);
    t8 = ((WORK_P_3602289512) + 2848U);
    t9 = *((char **)t8);
    t13 = *((int *)t9);
    t14 = (t3 == t13);
    if (t14 == 1)
        goto LAB11;

LAB12:    t7 = (unsigned char)0;

LAB13:    if (t7 != 0)
        goto LAB8;

LAB10:
LAB9:    t1 = (t0 + 19376);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(245, ng1);
    t8 = (t0 + 1512U);
    t11 = *((char **)t8);
    t17 = (7 - 7);
    t4 = (t17 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t8 = (t11 + t6);
    t18 = *((unsigned char *)t8);
    t12 = (t0 + 20960);
    t19 = (t12 + 56U);
    t20 = *((char **)t19);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    *((unsigned char *)t22) = t18;
    xsi_driver_first_trans_fast(t12);
    xsi_set_current_line(246, ng1);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t3 = (6 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 21024);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(247, ng1);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t3 = (5 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 21088);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(248, ng1);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t3 = (3 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 21152);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(249, ng1);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t3 = (2 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 21216);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(250, ng1);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t4 = (7 - 1);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t8 = (t0 + 21280);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t1, 2U);
    xsi_driver_first_trans_fast(t8);
    goto LAB3;

LAB5:    t8 = (t0 + 1992U);
    t10 = *((char **)t8);
    t15 = *((unsigned char *)t10);
    t16 = (t15 == (unsigned char)3);
    t7 = t16;
    goto LAB7;

LAB8:    xsi_set_current_line(254, ng1);
    t8 = (t0 + 1512U);
    t11 = *((char **)t8);
    t17 = (0 - 7);
    t4 = (t17 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t8 = (t11 + t6);
    t18 = *((unsigned char *)t8);
    t12 = (t0 + 21344);
    t19 = (t12 + 56U);
    t20 = *((char **)t19);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    *((unsigned char *)t22) = t18;
    xsi_driver_first_trans_fast(t12);
    goto LAB9;

LAB11:    t8 = (t0 + 1992U);
    t10 = *((char **)t8);
    t15 = *((unsigned char *)t10);
    t16 = (t15 == (unsigned char)3);
    t7 = t16;
    goto LAB13;

}

static void work_a_0643350375_1516540902_p_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(259, ng1);

LAB3:    t1 = xsi_get_transient_memory(5U);
    memset(t1, 0, 5U);
    t2 = t1;
    memset(t2, (unsigned char)2, 5U);
    t3 = (t0 + 21408);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 5U);
    xsi_driver_first_trans_delta(t3, 2U, 5U, 0LL);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0643350375_1516540902_p_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned char t12;
    unsigned char t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    int t19;
    char *t20;
    char *t21;
    int t22;
    char *t23;
    char *t24;
    int t25;
    char *t26;
    int t28;
    char *t29;
    char *t30;
    char *t31;
    unsigned char t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;

LAB0:    xsi_set_current_line(276, ng1);
    t1 = (t0 + 21472);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(277, ng1);
    t1 = (t0 + 7912U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t7 = (t6 != (unsigned char)0);
    if (t7 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 19392);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(278, ng1);
    t1 = (t0 + 5192U);
    t3 = *((char **)t1);
    t8 = (0 - 7);
    t9 = (t8 * -1);
    t10 = (1U * t9);
    t11 = (0 + t10);
    t1 = (t3 + t11);
    t12 = *((unsigned char *)t1);
    t13 = (t12 == (unsigned char)3);
    if (t13 != 0)
        goto LAB5;

LAB7:    xsi_set_current_line(287, ng1);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t9 = (7 - 1);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t3 = (t0 + 33877);
    t8 = xsi_mem_cmp(t3, t1, 2U);
    if (t8 == 1)
        goto LAB56;

LAB61:    t5 = (t0 + 33879);
    t19 = xsi_mem_cmp(t5, t1, 2U);
    if (t19 == 1)
        goto LAB57;

LAB62:    t18 = (t0 + 33881);
    t22 = xsi_mem_cmp(t18, t1, 2U);
    if (t22 == 1)
        goto LAB58;

LAB63:    t21 = (t0 + 33883);
    t25 = xsi_mem_cmp(t21, t1, 2U);
    if (t25 == 1)
        goto LAB59;

LAB64:
LAB60:    xsi_set_current_line(292, ng1);
    t1 = (t0 + 21472);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB55:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(279, ng1);
    t4 = (t0 + 5032U);
    t5 = *((char **)t4);
    t14 = (7 - 1);
    t15 = (t14 * 1U);
    t16 = (0 + t15);
    t4 = (t5 + t16);
    t17 = (t0 + 33845);
    t19 = xsi_mem_cmp(t17, t4, 2U);
    if (t19 == 1)
        goto LAB9;

LAB14:    t20 = (t0 + 33847);
    t22 = xsi_mem_cmp(t20, t4, 2U);
    if (t22 == 1)
        goto LAB10;

LAB15:    t23 = (t0 + 33849);
    t25 = xsi_mem_cmp(t23, t4, 2U);
    if (t25 == 1)
        goto LAB11;

LAB16:    t26 = (t0 + 33851);
    t28 = xsi_mem_cmp(t26, t4, 2U);
    if (t28 == 1)
        goto LAB12;

LAB17:
LAB13:    xsi_set_current_line(284, ng1);
    t1 = (t0 + 21472);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB8:    goto LAB6;

LAB9:    xsi_set_current_line(280, ng1);
    t29 = (t0 + 7272U);
    t30 = *((char **)t29);
    t29 = (t0 + 33853);
    t32 = 1;
    if (6U == 6U)
        goto LAB22;

LAB23:    t32 = 0;

LAB24:    if (t32 != 0)
        goto LAB19;

LAB21:
LAB20:    goto LAB8;

LAB10:    xsi_set_current_line(281, ng1);
    t1 = (t0 + 7272U);
    t2 = *((char **)t1);
    t1 = (t0 + 33859);
    t6 = 1;
    if (6U == 6U)
        goto LAB31;

LAB32:    t6 = 0;

LAB33:    if (t6 != 0)
        goto LAB28;

LAB30:
LAB29:    goto LAB8;

LAB11:    xsi_set_current_line(282, ng1);
    t1 = (t0 + 7272U);
    t2 = *((char **)t1);
    t1 = (t0 + 33865);
    t6 = 1;
    if (6U == 6U)
        goto LAB40;

LAB41:    t6 = 0;

LAB42:    if (t6 != 0)
        goto LAB37;

LAB39:
LAB38:    goto LAB8;

LAB12:    xsi_set_current_line(283, ng1);
    t1 = (t0 + 7272U);
    t2 = *((char **)t1);
    t1 = (t0 + 33871);
    t6 = 1;
    if (6U == 6U)
        goto LAB49;

LAB50:    t6 = 0;

LAB51:    if (t6 != 0)
        goto LAB46;

LAB48:
LAB47:    goto LAB8;

LAB18:;
LAB19:    xsi_set_current_line(280, ng1);
    t36 = (t0 + 21472);
    t37 = (t36 + 56U);
    t38 = *((char **)t37);
    t39 = (t38 + 56U);
    t40 = *((char **)t39);
    *((unsigned char *)t40) = (unsigned char)3;
    xsi_driver_first_trans_fast(t36);
    goto LAB20;

LAB22:    t33 = 0;

LAB25:    if (t33 < 6U)
        goto LAB26;
    else
        goto LAB24;

LAB26:    t34 = (t30 + t33);
    t35 = (t29 + t33);
    if (*((unsigned char *)t34) != *((unsigned char *)t35))
        goto LAB23;

LAB27:    t33 = (t33 + 1);
    goto LAB25;

LAB28:    xsi_set_current_line(281, ng1);
    t17 = (t0 + 21472);
    t18 = (t17 + 56U);
    t20 = *((char **)t18);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    *((unsigned char *)t23) = (unsigned char)3;
    xsi_driver_first_trans_fast(t17);
    goto LAB29;

LAB31:    t9 = 0;

LAB34:    if (t9 < 6U)
        goto LAB35;
    else
        goto LAB33;

LAB35:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB32;

LAB36:    t9 = (t9 + 1);
    goto LAB34;

LAB37:    xsi_set_current_line(282, ng1);
    t17 = (t0 + 21472);
    t18 = (t17 + 56U);
    t20 = *((char **)t18);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    *((unsigned char *)t23) = (unsigned char)3;
    xsi_driver_first_trans_fast(t17);
    goto LAB38;

LAB40:    t9 = 0;

LAB43:    if (t9 < 6U)
        goto LAB44;
    else
        goto LAB42;

LAB44:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB41;

LAB45:    t9 = (t9 + 1);
    goto LAB43;

LAB46:    xsi_set_current_line(283, ng1);
    t17 = (t0 + 21472);
    t18 = (t17 + 56U);
    t20 = *((char **)t18);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    *((unsigned char *)t23) = (unsigned char)3;
    xsi_driver_first_trans_fast(t17);
    goto LAB47;

LAB49:    t9 = 0;

LAB52:    if (t9 < 6U)
        goto LAB53;
    else
        goto LAB51;

LAB53:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB50;

LAB54:    t9 = (t9 + 1);
    goto LAB52;

LAB56:    xsi_set_current_line(288, ng1);
    t24 = (t0 + 7272U);
    t26 = *((char **)t24);
    t24 = (t0 + 33885);
    t6 = 1;
    if (6U == 6U)
        goto LAB69;

LAB70:    t6 = 0;

LAB71:    if (t6 != 0)
        goto LAB66;

LAB68:
LAB67:    goto LAB55;

LAB57:    xsi_set_current_line(289, ng1);
    t1 = (t0 + 7272U);
    t2 = *((char **)t1);
    t1 = (t0 + 33891);
    t6 = 1;
    if (6U == 6U)
        goto LAB78;

LAB79:    t6 = 0;

LAB80:    if (t6 != 0)
        goto LAB75;

LAB77:
LAB76:    goto LAB55;

LAB58:    xsi_set_current_line(290, ng1);
    t1 = (t0 + 7272U);
    t2 = *((char **)t1);
    t1 = (t0 + 33897);
    t6 = 1;
    if (6U == 6U)
        goto LAB87;

LAB88:    t6 = 0;

LAB89:    if (t6 != 0)
        goto LAB84;

LAB86:
LAB85:    goto LAB55;

LAB59:    xsi_set_current_line(291, ng1);
    t1 = (t0 + 7272U);
    t2 = *((char **)t1);
    t1 = (t0 + 33903);
    t6 = 1;
    if (6U == 6U)
        goto LAB96;

LAB97:    t6 = 0;

LAB98:    if (t6 != 0)
        goto LAB93;

LAB95:
LAB94:    goto LAB55;

LAB65:;
LAB66:    xsi_set_current_line(288, ng1);
    t31 = (t0 + 21472);
    t34 = (t31 + 56U);
    t35 = *((char **)t34);
    t36 = (t35 + 56U);
    t37 = *((char **)t36);
    *((unsigned char *)t37) = (unsigned char)3;
    xsi_driver_first_trans_fast(t31);
    goto LAB67;

LAB69:    t14 = 0;

LAB72:    if (t14 < 6U)
        goto LAB73;
    else
        goto LAB71;

LAB73:    t29 = (t26 + t14);
    t30 = (t24 + t14);
    if (*((unsigned char *)t29) != *((unsigned char *)t30))
        goto LAB70;

LAB74:    t14 = (t14 + 1);
    goto LAB72;

LAB75:    xsi_set_current_line(289, ng1);
    t17 = (t0 + 21472);
    t18 = (t17 + 56U);
    t20 = *((char **)t18);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    *((unsigned char *)t23) = (unsigned char)3;
    xsi_driver_first_trans_fast(t17);
    goto LAB76;

LAB78:    t9 = 0;

LAB81:    if (t9 < 6U)
        goto LAB82;
    else
        goto LAB80;

LAB82:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB79;

LAB83:    t9 = (t9 + 1);
    goto LAB81;

LAB84:    xsi_set_current_line(290, ng1);
    t17 = (t0 + 21472);
    t18 = (t17 + 56U);
    t20 = *((char **)t18);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    *((unsigned char *)t23) = (unsigned char)3;
    xsi_driver_first_trans_fast(t17);
    goto LAB85;

LAB87:    t9 = 0;

LAB90:    if (t9 < 6U)
        goto LAB91;
    else
        goto LAB89;

LAB91:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB88;

LAB92:    t9 = (t9 + 1);
    goto LAB90;

LAB93:    xsi_set_current_line(291, ng1);
    t17 = (t0 + 21472);
    t18 = (t17 + 56U);
    t20 = *((char **)t18);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    *((unsigned char *)t23) = (unsigned char)3;
    xsi_driver_first_trans_fast(t17);
    goto LAB94;

LAB96:    t9 = 0;

LAB99:    if (t9 < 6U)
        goto LAB100;
    else
        goto LAB98;

LAB100:    t4 = (t2 + t9);
    t5 = (t1 + t9);
    if (*((unsigned char *)t4) != *((unsigned char *)t5))
        goto LAB97;

LAB101:    t9 = (t9 + 1);
    goto LAB99;

}

static void work_a_0643350375_1516540902_p_4(char *t0)
{
    char t14[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned char t7;
    unsigned char t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(301, ng1);
    t1 = (t0 + 7272U);
    t2 = *((char **)t1);
    t1 = (t0 + 21536);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 6U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(302, ng1);
    t1 = (t0 + 7592U);
    t2 = *((char **)t1);
    t7 = *((unsigned char *)t2);
    t1 = (t0 + 21600);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = t7;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(303, ng1);
    t1 = (t0 + 7912U);
    t2 = *((char **)t1);
    t7 = *((unsigned char *)t2);
    t8 = (t7 != (unsigned char)0);
    if (t8 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 19408);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(304, ng1);
    t1 = (t0 + 7432U);
    t3 = *((char **)t1);
    t9 = *((unsigned char *)t3);
    t10 = (t9 == (unsigned char)3);
    if (t10 != 0)
        goto LAB5;

LAB7:    xsi_set_current_line(308, ng1);
    t1 = (t0 + 7272U);
    t2 = *((char **)t1);
    t1 = (t0 + 33700U);
    t3 = work_p_0170319956_sub_433329865_170319956(WORK_P_0170319956, t14, t2, t1, 1);
    t4 = (t0 + 21536);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t11 = (t6 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t3, 6U);
    xsi_driver_first_trans_fast(t4);

LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(305, ng1);
    t1 = xsi_get_transient_memory(6U);
    memset(t1, 0, 6U);
    t4 = t1;
    memset(t4, (unsigned char)2, 6U);
    t5 = (t0 + 21536);
    t6 = (t5 + 56U);
    t11 = *((char **)t6);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t1, 6U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(306, ng1);
    t1 = (t0 + 7592U);
    t2 = *((char **)t1);
    t7 = *((unsigned char *)t2);
    t8 = ieee_p_2592010699_sub_1690584930_2592010699(IEEE_P_2592010699, t7);
    t1 = (t0 + 21600);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = t8;
    xsi_driver_first_trans_fast(t1);
    goto LAB6;

}

static void work_a_0643350375_1516540902_p_5(char *t0)
{
    unsigned char t1;
    unsigned char t2;
    char *t3;
    char *t4;
    int t5;
    char *t6;
    char *t7;
    int t8;
    unsigned char t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned char t18;
    unsigned char t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;

LAB0:    xsi_set_current_line(315, ng1);
    t3 = (t0 + 1352U);
    t4 = *((char **)t3);
    t3 = (t0 + 33508U);
    t5 = work_p_0170319956_sub_3397525853_170319956(WORK_P_0170319956, t4, t3);
    t6 = ((WORK_P_3602289512) + 2968U);
    t7 = *((char **)t6);
    t8 = *((int *)t7);
    t9 = (t5 == t8);
    if (t9 == 1)
        goto LAB8;

LAB9:    t2 = (unsigned char)0;

LAB10:    if (t2 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB11:    t25 = (t0 + 21664);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    *((unsigned char *)t29) = (unsigned char)2;
    xsi_driver_first_trans_fast(t25);

LAB2:    t30 = (t0 + 19424);
    *((int *)t30) = 1;

LAB1:    return;
LAB3:    t20 = (t0 + 21664);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    *((unsigned char *)t24) = (unsigned char)3;
    xsi_driver_first_trans_fast(t20);
    goto LAB2;

LAB5:    t6 = (t0 + 5032U);
    t13 = *((char **)t6);
    t14 = (6 - 7);
    t15 = (t14 * -1);
    t16 = (1U * t15);
    t17 = (0 + t16);
    t6 = (t13 + t17);
    t18 = *((unsigned char *)t6);
    t19 = (t18 == (unsigned char)3);
    t1 = t19;
    goto LAB7;

LAB8:    t6 = (t0 + 1992U);
    t10 = *((char **)t6);
    t11 = *((unsigned char *)t10);
    t12 = (t11 == (unsigned char)3);
    t2 = t12;
    goto LAB10;

LAB12:    goto LAB2;

}

static void work_a_0643350375_1516540902_p_6(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    unsigned char t10;
    int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned char t15;
    unsigned char t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    static char *nl0[] = {&&LAB3, &&LAB4, &&LAB5, &&LAB6, &&LAB7, &&LAB8, &&LAB9, &&LAB10, &&LAB11};

LAB0:    xsi_set_current_line(320, ng1);
    t1 = (t0 + 7912U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 21728);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(321, ng1);
    t1 = (t0 + 7912U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (char *)((nl0) + t3);
    goto **((char **)t1);

LAB2:    t1 = (t0 + 19440);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(323, ng1);
    t4 = (t0 + 8232U);
    t5 = *((char **)t4);
    t9 = *((unsigned char *)t5);
    t10 = (t9 == (unsigned char)3);
    if (t10 == 1)
        goto LAB16;

LAB17:    t8 = (unsigned char)0;

LAB18:    if (t8 != 0)
        goto LAB13;

LAB15:
LAB14:    goto LAB2;

LAB4:    xsi_set_current_line(327, ng1);
    t1 = (t0 + 7592U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t9 = (t8 == (unsigned char)3);
    if (t9 == 1)
        goto LAB22;

LAB23:    t3 = (unsigned char)0;

LAB24:    if (t3 != 0)
        goto LAB19;

LAB21:
LAB20:    goto LAB2;

LAB5:    xsi_set_current_line(331, ng1);
    t1 = (t0 + 7592U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t9 = (t8 == (unsigned char)3);
    if (t9 == 1)
        goto LAB28;

LAB29:    t3 = (unsigned char)0;

LAB30:    if (t3 != 0)
        goto LAB25;

LAB27:
LAB26:    goto LAB2;

LAB6:    xsi_set_current_line(335, ng1);
    t1 = (t0 + 7592U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t9 = (t8 == (unsigned char)3);
    if (t9 == 1)
        goto LAB34;

LAB35:    t3 = (unsigned char)0;

LAB36:    if (t3 != 0)
        goto LAB31;

LAB33:
LAB32:    goto LAB2;

LAB7:    xsi_set_current_line(339, ng1);
    t1 = (t0 + 7592U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t9 = (t8 == (unsigned char)3);
    if (t9 == 1)
        goto LAB40;

LAB41:    t3 = (unsigned char)0;

LAB42:    if (t3 != 0)
        goto LAB37;

LAB39:
LAB38:    goto LAB2;

LAB8:    xsi_set_current_line(343, ng1);
    t1 = (t0 + 7592U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t9 = (t8 == (unsigned char)3);
    if (t9 == 1)
        goto LAB46;

LAB47:    t3 = (unsigned char)0;

LAB48:    if (t3 != 0)
        goto LAB43;

LAB45:
LAB44:    goto LAB2;

LAB9:    xsi_set_current_line(347, ng1);
    t1 = (t0 + 7592U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t9 = (t8 == (unsigned char)3);
    if (t9 == 1)
        goto LAB52;

LAB53:    t3 = (unsigned char)0;

LAB54:    if (t3 != 0)
        goto LAB49;

LAB51:
LAB50:    goto LAB2;

LAB10:    xsi_set_current_line(351, ng1);
    t1 = (t0 + 7592U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t9 = (t8 == (unsigned char)3);
    if (t9 == 1)
        goto LAB58;

LAB59:    t3 = (unsigned char)0;

LAB60:    if (t3 != 0)
        goto LAB55;

LAB57:
LAB56:    goto LAB2;

LAB11:    xsi_set_current_line(355, ng1);
    t1 = (t0 + 7592U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t9 = (t8 == (unsigned char)3);
    if (t9 == 1)
        goto LAB64;

LAB65:    t3 = (unsigned char)0;

LAB66:    if (t3 != 0)
        goto LAB61;

LAB63:
LAB62:    goto LAB2;

LAB12:    xsi_set_current_line(358, ng1);
    t1 = (t0 + 21728);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB13:    xsi_set_current_line(324, ng1);
    t7 = (t0 + 21728);
    t17 = (t7 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = (unsigned char)1;
    xsi_driver_first_trans_fast(t7);
    goto LAB14;

LAB16:    t4 = (t0 + 5032U);
    t6 = *((char **)t4);
    t11 = (4 - 7);
    t12 = (t11 * -1);
    t13 = (1U * t12);
    t14 = (0 + t13);
    t4 = (t6 + t14);
    t15 = *((unsigned char *)t4);
    t16 = (t15 == (unsigned char)3);
    t8 = t16;
    goto LAB18;

LAB19:    xsi_set_current_line(328, ng1);
    t1 = (t0 + 21728);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t17 = *((char **)t7);
    *((unsigned char *)t17) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB20;

LAB22:    t1 = (t0 + 7432U);
    t4 = *((char **)t1);
    t10 = *((unsigned char *)t4);
    t15 = (t10 == (unsigned char)3);
    t3 = t15;
    goto LAB24;

LAB25:    xsi_set_current_line(332, ng1);
    t1 = (t0 + 21728);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t17 = *((char **)t7);
    *((unsigned char *)t17) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB26;

LAB28:    t1 = (t0 + 7432U);
    t4 = *((char **)t1);
    t10 = *((unsigned char *)t4);
    t15 = (t10 == (unsigned char)3);
    t3 = t15;
    goto LAB30;

LAB31:    xsi_set_current_line(336, ng1);
    t1 = (t0 + 21728);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t17 = *((char **)t7);
    *((unsigned char *)t17) = (unsigned char)4;
    xsi_driver_first_trans_fast(t1);
    goto LAB32;

LAB34:    t1 = (t0 + 7432U);
    t4 = *((char **)t1);
    t10 = *((unsigned char *)t4);
    t15 = (t10 == (unsigned char)3);
    t3 = t15;
    goto LAB36;

LAB37:    xsi_set_current_line(340, ng1);
    t1 = (t0 + 21728);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t17 = *((char **)t7);
    *((unsigned char *)t17) = (unsigned char)5;
    xsi_driver_first_trans_fast(t1);
    goto LAB38;

LAB40:    t1 = (t0 + 7432U);
    t4 = *((char **)t1);
    t10 = *((unsigned char *)t4);
    t15 = (t10 == (unsigned char)3);
    t3 = t15;
    goto LAB42;

LAB43:    xsi_set_current_line(344, ng1);
    t1 = (t0 + 21728);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t17 = *((char **)t7);
    *((unsigned char *)t17) = (unsigned char)6;
    xsi_driver_first_trans_fast(t1);
    goto LAB44;

LAB46:    t1 = (t0 + 7432U);
    t4 = *((char **)t1);
    t10 = *((unsigned char *)t4);
    t15 = (t10 == (unsigned char)3);
    t3 = t15;
    goto LAB48;

LAB49:    xsi_set_current_line(348, ng1);
    t1 = (t0 + 21728);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t17 = *((char **)t7);
    *((unsigned char *)t17) = (unsigned char)7;
    xsi_driver_first_trans_fast(t1);
    goto LAB50;

LAB52:    t1 = (t0 + 7432U);
    t4 = *((char **)t1);
    t10 = *((unsigned char *)t4);
    t15 = (t10 == (unsigned char)3);
    t3 = t15;
    goto LAB54;

LAB55:    xsi_set_current_line(352, ng1);
    t1 = (t0 + 21728);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t17 = *((char **)t7);
    *((unsigned char *)t17) = (unsigned char)8;
    xsi_driver_first_trans_fast(t1);
    goto LAB56;

LAB58:    t1 = (t0 + 7432U);
    t4 = *((char **)t1);
    t10 = *((unsigned char *)t4);
    t15 = (t10 == (unsigned char)3);
    t3 = t15;
    goto LAB60;

LAB61:    xsi_set_current_line(356, ng1);
    t1 = (t0 + 21728);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t17 = *((char **)t7);
    *((unsigned char *)t17) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    goto LAB62;

LAB64:    t1 = (t0 + 7432U);
    t4 = *((char **)t1);
    t10 = *((unsigned char *)t4);
    t15 = (t10 == (unsigned char)3);
    t3 = t15;
    goto LAB66;

}

static void work_a_0643350375_1516540902_p_7(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    unsigned char t10;
    int t11;
    int t12;
    unsigned char t13;
    char *t14;
    unsigned char t15;
    unsigned char t16;
    char *t17;
    int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned char t22;
    unsigned char t23;
    char *t24;
    char *t25;
    int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned char t30;
    unsigned char t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    static char *nl0[] = {&&LAB5, &&LAB5, &&LAB3, &&LAB4, &&LAB5, &&LAB5, &&LAB5, &&LAB5, &&LAB5};

LAB0:    xsi_set_current_line(365, ng1);
    t1 = (t0 + 10152U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 21792);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(366, ng1);
    t1 = (t0 + 10152U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (char *)((nl0) + t3);
    goto **((char **)t1);

LAB2:    t1 = (t0 + 19456);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(368, ng1);
    t4 = (t0 + 1352U);
    t5 = *((char **)t4);
    t4 = (t0 + 33508U);
    t11 = work_p_0170319956_sub_3397525853_170319956(WORK_P_0170319956, t5, t4);
    t6 = ((WORK_P_3602289512) + 2848U);
    t7 = *((char **)t6);
    t12 = *((int *)t7);
    t13 = (t11 == t12);
    if (t13 == 1)
        goto LAB15;

LAB16:    t10 = (unsigned char)0;

LAB17:    if (t10 == 1)
        goto LAB12;

LAB13:    t9 = (unsigned char)0;

LAB14:    if (t9 == 1)
        goto LAB9;

LAB10:    t8 = (unsigned char)0;

LAB11:    if (t8 != 0)
        goto LAB6;

LAB8:
LAB7:    goto LAB2;

LAB4:    xsi_set_current_line(372, ng1);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 33508U);
    t11 = work_p_0170319956_sub_3397525853_170319956(WORK_P_0170319956, t2, t1);
    t4 = ((WORK_P_3602289512) + 2968U);
    t5 = *((char **)t4);
    t12 = *((int *)t5);
    t8 = (t11 == t12);
    if (t8 == 1)
        goto LAB21;

LAB22:    t3 = (unsigned char)0;

LAB23:    if (t3 != 0)
        goto LAB18;

LAB20:
LAB19:    goto LAB2;

LAB5:    xsi_set_current_line(375, ng1);
    t1 = (t0 + 10152U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 21792);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB6:    xsi_set_current_line(369, ng1);
    t32 = (t0 + 21792);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    t35 = (t34 + 56U);
    t36 = *((char **)t35);
    *((unsigned char *)t36) = (unsigned char)3;
    xsi_driver_first_trans_fast(t32);
    goto LAB7;

LAB9:    t24 = (t0 + 5032U);
    t25 = *((char **)t24);
    t26 = (6 - 7);
    t27 = (t26 * -1);
    t28 = (1U * t27);
    t29 = (0 + t28);
    t24 = (t25 + t29);
    t30 = *((unsigned char *)t24);
    t31 = (t30 == (unsigned char)3);
    t8 = t31;
    goto LAB11;

LAB12:    t6 = (t0 + 5192U);
    t17 = *((char **)t6);
    t18 = (7 - 7);
    t19 = (t18 * -1);
    t20 = (1U * t19);
    t21 = (0 + t20);
    t6 = (t17 + t21);
    t22 = *((unsigned char *)t6);
    t23 = (t22 == (unsigned char)3);
    t9 = t23;
    goto LAB14;

LAB15:    t6 = (t0 + 1832U);
    t14 = *((char **)t6);
    t15 = *((unsigned char *)t14);
    t16 = (t15 == (unsigned char)3);
    t10 = t16;
    goto LAB17;

LAB18:    xsi_set_current_line(373, ng1);
    t4 = (t0 + 21792);
    t14 = (t4 + 56U);
    t17 = *((char **)t14);
    t24 = (t17 + 56U);
    t25 = *((char **)t24);
    *((unsigned char *)t25) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB19;

LAB21:    t4 = (t0 + 1832U);
    t6 = *((char **)t4);
    t10 = *((unsigned char *)t6);
    t13 = (t10 == (unsigned char)3);
    if (t13 == 1)
        goto LAB24;

LAB25:    t4 = (t0 + 1992U);
    t7 = *((char **)t4);
    t15 = *((unsigned char *)t7);
    t16 = (t15 == (unsigned char)3);
    t9 = t16;

LAB26:    t3 = t9;
    goto LAB23;

LAB24:    t9 = (unsigned char)1;
    goto LAB26;

}

static void work_a_0643350375_1516540902_p_8(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    int t10;
    int t11;
    unsigned char t12;
    char *t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned char t21;
    unsigned char t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    static char *nl0[] = {&&LAB5, &&LAB5, &&LAB3, &&LAB4, &&LAB5, &&LAB5, &&LAB5, &&LAB5, &&LAB5};

LAB0:    xsi_set_current_line(382, ng1);
    t1 = (t0 + 10472U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 21856);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(383, ng1);
    t1 = (t0 + 10472U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (char *)((nl0) + t3);
    goto **((char **)t1);

LAB2:    t1 = (t0 + 19472);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(385, ng1);
    t4 = (t0 + 1352U);
    t5 = *((char **)t4);
    t4 = (t0 + 33508U);
    t10 = work_p_0170319956_sub_3397525853_170319956(WORK_P_0170319956, t5, t4);
    t6 = ((WORK_P_3602289512) + 2848U);
    t7 = *((char **)t6);
    t11 = *((int *)t7);
    t12 = (t10 == t11);
    if (t12 == 1)
        goto LAB12;

LAB13:    t9 = (unsigned char)0;

LAB14:    if (t9 == 1)
        goto LAB9;

LAB10:    t8 = (unsigned char)0;

LAB11:    if (t8 != 0)
        goto LAB6;

LAB8:
LAB7:    goto LAB2;

LAB4:    xsi_set_current_line(389, ng1);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 33508U);
    t10 = work_p_0170319956_sub_3397525853_170319956(WORK_P_0170319956, t2, t1);
    t4 = ((WORK_P_3602289512) + 2968U);
    t5 = *((char **)t4);
    t11 = *((int *)t5);
    t8 = (t10 == t11);
    if (t8 == 1)
        goto LAB18;

LAB19:    t3 = (unsigned char)0;

LAB20:    if (t3 != 0)
        goto LAB15;

LAB17:
LAB16:    goto LAB2;

LAB5:    xsi_set_current_line(392, ng1);
    t1 = (t0 + 10472U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 21856);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB6:    xsi_set_current_line(386, ng1);
    t23 = (t0 + 21856);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    *((unsigned char *)t27) = (unsigned char)3;
    xsi_driver_first_trans_fast(t23);
    goto LAB7;

LAB9:    t6 = (t0 + 5192U);
    t16 = *((char **)t6);
    t17 = (6 - 7);
    t18 = (t17 * -1);
    t19 = (1U * t18);
    t20 = (0 + t19);
    t6 = (t16 + t20);
    t21 = *((unsigned char *)t6);
    t22 = (t21 == (unsigned char)3);
    t8 = t22;
    goto LAB11;

LAB12:    t6 = (t0 + 1832U);
    t13 = *((char **)t6);
    t14 = *((unsigned char *)t13);
    t15 = (t14 == (unsigned char)3);
    t9 = t15;
    goto LAB14;

LAB15:    xsi_set_current_line(390, ng1);
    t4 = (t0 + 21856);
    t13 = (t4 + 56U);
    t16 = *((char **)t13);
    t23 = (t16 + 56U);
    t24 = *((char **)t23);
    *((unsigned char *)t24) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    goto LAB16;

LAB18:    t4 = (t0 + 1832U);
    t6 = *((char **)t4);
    t12 = *((unsigned char *)t6);
    t14 = (t12 == (unsigned char)3);
    if (t14 == 1)
        goto LAB21;

LAB22:    t4 = (t0 + 1992U);
    t7 = *((char **)t4);
    t15 = *((unsigned char *)t7);
    t21 = (t15 == (unsigned char)3);
    t9 = t21;

LAB23:    t3 = t9;
    goto LAB20;

LAB21:    t9 = (unsigned char)1;
    goto LAB23;

}

static void work_a_0643350375_1516540902_p_9(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    unsigned char t8;
    int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned char t13;
    char *t14;
    char *t15;
    int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned char t20;
    unsigned char t21;
    unsigned char t22;
    char *t23;
    char *t24;
    unsigned char t25;
    unsigned char t26;
    char *t27;
    unsigned char t28;
    unsigned char t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    static char *nl0[] = {&&LAB5, &&LAB5, &&LAB3, &&LAB4, &&LAB5, &&LAB5, &&LAB5, &&LAB5, &&LAB5};

LAB0:    xsi_set_current_line(399, ng1);
    t1 = (t0 + 21920);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(400, ng1);
    t1 = (t0 + 11432U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t1 = (char *)((nl0) + t6);
    goto **((char **)t1);

LAB2:    t1 = (t0 + 19488);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(402, ng1);
    t3 = (t0 + 7912U);
    t4 = *((char **)t3);
    t7 = *((unsigned char *)t4);
    t8 = (t7 != (unsigned char)0);
    if (t8 != 0)
        goto LAB6;

LAB8:
LAB7:    goto LAB2;

LAB4:    xsi_set_current_line(413, ng1);
    t1 = (t0 + 21920);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB5:    xsi_set_current_line(414, ng1);
    t1 = (t0 + 21920);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB6:    xsi_set_current_line(403, ng1);
    t3 = (t0 + 5032U);
    t5 = *((char **)t3);
    t9 = (2 - 7);
    t10 = (t9 * -1);
    t11 = (1U * t10);
    t12 = (0 + t11);
    t3 = (t5 + t12);
    t13 = *((unsigned char *)t3);
    t14 = (t0 + 5032U);
    t15 = *((char **)t14);
    t16 = (3 - 7);
    t17 = (t16 * -1);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t14 = (t15 + t19);
    t20 = *((unsigned char *)t14);
    t21 = (t13 == t20);
    if (t21 != 0)
        goto LAB9;

LAB11:    xsi_set_current_line(408, ng1);
    t1 = (t0 + 8392U);
    t2 = *((char **)t1);
    t7 = *((unsigned char *)t2);
    t8 = (t7 == (unsigned char)2);
    if (t8 == 1)
        goto LAB21;

LAB22:    t6 = (unsigned char)0;

LAB23:    if (t6 != 0)
        goto LAB18;

LAB20:
LAB19:
LAB10:    goto LAB7;

LAB9:    xsi_set_current_line(404, ng1);
    t23 = (t0 + 8392U);
    t24 = *((char **)t23);
    t25 = *((unsigned char *)t24);
    t26 = (t25 == (unsigned char)3);
    if (t26 == 1)
        goto LAB15;

LAB16:    t22 = (unsigned char)0;

LAB17:    if (t22 != 0)
        goto LAB12;

LAB14:
LAB13:    goto LAB10;

LAB12:    xsi_set_current_line(405, ng1);
    t23 = (t0 + 21920);
    t30 = (t23 + 56U);
    t31 = *((char **)t30);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    *((unsigned char *)t33) = (unsigned char)3;
    xsi_driver_first_trans_fast(t23);
    goto LAB13;

LAB15:    t23 = (t0 + 8552U);
    t27 = *((char **)t23);
    t28 = *((unsigned char *)t27);
    t29 = (t28 == (unsigned char)2);
    t22 = t29;
    goto LAB17;

LAB18:    xsi_set_current_line(409, ng1);
    t1 = (t0 + 21920);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t14 = (t5 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB19;

LAB21:    t1 = (t0 + 8552U);
    t3 = *((char **)t1);
    t13 = *((unsigned char *)t3);
    t20 = (t13 == (unsigned char)3);
    t6 = t20;
    goto LAB23;

}

static void work_a_0643350375_1516540902_p_10(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    unsigned char t8;
    unsigned char t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    char *t19;
    unsigned char t20;
    unsigned char t21;
    unsigned char t22;
    unsigned char t23;
    char *t24;
    int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned char t29;
    unsigned char t30;
    char *t31;
    char *t32;
    unsigned char t33;
    unsigned char t34;
    char *t35;
    unsigned char t36;
    unsigned char t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    static char *nl0[] = {&&LAB5, &&LAB5, &&LAB3, &&LAB4, &&LAB5, &&LAB5, &&LAB5, &&LAB5, &&LAB5};

LAB0:    xsi_set_current_line(423, ng1);
    t1 = (t0 + 21984);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(424, ng1);
    t1 = (t0 + 8712U);
    t2 = *((char **)t1);
    t6 = *((unsigned char *)t2);
    t1 = (char *)((nl0) + t6);
    goto **((char **)t1);

LAB2:    t1 = (t0 + 19504);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(426, ng1);
    t3 = (t0 + 5032U);
    t4 = *((char **)t3);
    t10 = (4 - 7);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t3 = (t4 + t13);
    t14 = *((unsigned char *)t3);
    t15 = (t14 == (unsigned char)3);
    if (t15 == 1)
        goto LAB15;

LAB16:    t9 = (unsigned char)0;

LAB17:    if (t9 == 1)
        goto LAB12;

LAB13:    t8 = (unsigned char)0;

LAB14:    if (t8 == 1)
        goto LAB9;

LAB10:    t5 = (t0 + 5032U);
    t24 = *((char **)t5);
    t25 = (4 - 7);
    t26 = (t25 * -1);
    t27 = (1U * t26);
    t28 = (0 + t27);
    t5 = (t24 + t28);
    t29 = *((unsigned char *)t5);
    t30 = (t29 == (unsigned char)2);
    if (t30 == 1)
        goto LAB21;

LAB22:    t23 = (unsigned char)0;

LAB23:    if (t23 == 1)
        goto LAB18;

LAB19:    t22 = (unsigned char)0;

LAB20:    t7 = t22;

LAB11:    if (t7 != 0)
        goto LAB6;

LAB8:
LAB7:    goto LAB2;

LAB4:    xsi_set_current_line(430, ng1);
    t1 = (t0 + 21984);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB5:    xsi_set_current_line(431, ng1);
    t1 = (t0 + 21984);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB6:    xsi_set_current_line(428, ng1);
    t31 = (t0 + 21984);
    t38 = (t31 + 56U);
    t39 = *((char **)t38);
    t40 = (t39 + 56U);
    t41 = *((char **)t40);
    *((unsigned char *)t41) = (unsigned char)3;
    xsi_driver_first_trans_fast(t31);
    goto LAB7;

LAB9:    t7 = (unsigned char)1;
    goto LAB11;

LAB12:    t5 = (t0 + 8072U);
    t19 = *((char **)t5);
    t20 = *((unsigned char *)t19);
    t21 = (t20 == (unsigned char)0);
    t8 = t21;
    goto LAB14;

LAB15:    t5 = (t0 + 7912U);
    t16 = *((char **)t5);
    t17 = *((unsigned char *)t16);
    t18 = (t17 != (unsigned char)0);
    t9 = t18;
    goto LAB17;

LAB18:    t31 = (t0 + 9992U);
    t35 = *((char **)t31);
    t36 = *((unsigned char *)t35);
    t37 = (t36 == (unsigned char)0);
    t22 = t37;
    goto LAB20;

LAB21:    t31 = (t0 + 9832U);
    t32 = *((char **)t31);
    t33 = *((unsigned char *)t32);
    t34 = (t33 != (unsigned char)0);
    t23 = t34;
    goto LAB23;

}

static void work_a_0643350375_1516540902_p_11(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned char t12;
    unsigned char t13;
    unsigned char t14;
    unsigned char t15;
    unsigned char t16;
    char *t17;
    char *t18;
    char *t19;
    unsigned char t20;
    unsigned char t21;
    unsigned char t22;
    char *t23;

LAB0:    xsi_set_current_line(438, ng1);
    t1 = (t0 + 9032U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 22048);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(439, ng1);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t8 = (4 - 7);
    t9 = (t8 * -1);
    t10 = (1U * t9);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t12 = *((unsigned char *)t1);
    t13 = (t12 == (unsigned char)3);
    if (t13 == 1)
        goto LAB5;

LAB6:    t3 = (unsigned char)0;

LAB7:    if (t3 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t8 = (4 - 7);
    t9 = (t8 * -1);
    t10 = (1U * t9);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t13 = *((unsigned char *)t1);
    t14 = (t13 == (unsigned char)2);
    if (t14 == 1)
        goto LAB13;

LAB14:    t12 = (unsigned char)0;

LAB15:    if (t12 == 1)
        goto LAB10;

LAB11:    t3 = (unsigned char)0;

LAB12:    if (t3 != 0)
        goto LAB8;

LAB9:
LAB3:    t1 = (t0 + 19520);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(440, ng1);
    t4 = (t0 + 2312U);
    t6 = *((char **)t4);
    t16 = *((unsigned char *)t6);
    t4 = (t0 + 22048);
    t7 = (t4 + 56U);
    t17 = *((char **)t7);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = t16;
    xsi_driver_first_trans_fast(t4);
    goto LAB3;

LAB5:    t4 = (t0 + 11432U);
    t5 = *((char **)t4);
    t14 = *((unsigned char *)t5);
    t15 = (t14 == (unsigned char)3);
    t3 = t15;
    goto LAB7;

LAB8:    xsi_set_current_line(442, ng1);
    t4 = (t0 + 2472U);
    t7 = *((char **)t4);
    t22 = *((unsigned char *)t7);
    t4 = (t0 + 22048);
    t17 = (t4 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t23 = *((char **)t19);
    *((unsigned char *)t23) = t22;
    xsi_driver_first_trans_fast(t4);
    goto LAB3;

LAB10:    t4 = (t0 + 4872U);
    t6 = *((char **)t4);
    t20 = *((unsigned char *)t6);
    t21 = (t20 == (unsigned char)2);
    t3 = t21;
    goto LAB12;

LAB13:    t4 = (t0 + 9512U);
    t5 = *((char **)t4);
    t15 = *((unsigned char *)t5);
    t16 = (t15 == (unsigned char)3);
    t12 = t16;
    goto LAB15;

}

static void work_a_0643350375_1516540902_p_12(char *t0)
{
    char t38[16];
    char t56[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned char t7;
    unsigned char t8;
    unsigned char t9;
    unsigned char t10;
    unsigned char t11;
    unsigned char t12;
    unsigned char t13;
    unsigned char t14;
    unsigned char t15;
    unsigned char t16;
    unsigned char t17;
    int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned char t22;
    unsigned char t23;
    char *t24;
    unsigned char t25;
    unsigned char t26;
    char *t27;
    unsigned char t28;
    unsigned char t29;
    unsigned char t30;
    char *t31;
    int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned char t36;
    unsigned char t37;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    unsigned char t47;
    unsigned char t48;
    unsigned char t49;
    int t50;
    int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned char t55;
    int t57;
    unsigned int t58;
    char *t59;
    char *t60;
    char *t61;
    char *t62;

LAB0:    xsi_set_current_line(448, ng1);
    t1 = (t0 + 6792U);
    t2 = *((char **)t1);
    t1 = (t0 + 22112);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 8U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(449, ng1);
    t1 = (t0 + 8232U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t9 = (t8 == (unsigned char)3);
    if (t9 == 1)
        goto LAB5;

LAB6:    t7 = (unsigned char)0;

LAB7:    if (t7 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t18 = (4 - 7);
    t19 = (t18 * -1);
    t20 = (1U * t19);
    t21 = (0 + t20);
    t1 = (t2 + t21);
    t8 = *((unsigned char *)t1);
    t9 = (t8 == (unsigned char)3);
    if (t9 == 1)
        goto LAB25;

LAB26:    t7 = (unsigned char)0;

LAB27:    if (t7 != 0)
        goto LAB23;

LAB24:    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t18 = (4 - 7);
    t19 = (t18 * -1);
    t20 = (1U * t19);
    t21 = (0 + t20);
    t1 = (t2 + t21);
    t11 = *((unsigned char *)t1);
    t12 = (t11 == (unsigned char)3);
    if (t12 == 1)
        goto LAB39;

LAB40:    t10 = (unsigned char)0;

LAB41:    if (t10 == 1)
        goto LAB36;

LAB37:    t9 = (unsigned char)0;

LAB38:    if (t9 == 1)
        goto LAB33;

LAB34:    t8 = (unsigned char)0;

LAB35:    if (t8 == 1)
        goto LAB30;

LAB31:    t3 = (t0 + 5032U);
    t24 = *((char **)t3);
    t32 = (4 - 7);
    t33 = (t32 * -1);
    t34 = (1U * t33);
    t35 = (0 + t34);
    t3 = (t24 + t35);
    t28 = *((unsigned char *)t3);
    t29 = (t28 == (unsigned char)2);
    if (t29 == 1)
        goto LAB48;

LAB49:    t26 = (unsigned char)0;

LAB50:    if (t26 == 1)
        goto LAB45;

LAB46:    t25 = (unsigned char)0;

LAB47:    if (t25 == 1)
        goto LAB42;

LAB43:    t23 = (unsigned char)0;

LAB44:    t7 = t23;

LAB32:    if (t7 != 0)
        goto LAB28;

LAB29:
LAB3:    t1 = (t0 + 19536);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(450, ng1);
    t6 = (t0 + 5032U);
    t31 = *((char **)t6);
    t32 = (5 - 7);
    t33 = (t32 * -1);
    t34 = (1U * t33);
    t35 = (0 + t34);
    t6 = (t31 + t35);
    t36 = *((unsigned char *)t6);
    t37 = (t36 == (unsigned char)3);
    if (t37 != 0)
        goto LAB20;

LAB22:    xsi_set_current_line(453, ng1);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t1 = (t0 + 22112);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 8U);
    xsi_driver_first_trans_fast(t1);

LAB21:    goto LAB3;

LAB5:    t1 = (t0 + 7912U);
    t3 = *((char **)t1);
    t12 = *((unsigned char *)t3);
    t13 = (t12 == (unsigned char)0);
    if (t13 == 1)
        goto LAB11;

LAB12:    t11 = (unsigned char)0;

LAB13:    if (t11 == 1)
        goto LAB8;

LAB9:    t10 = (unsigned char)0;

LAB10:    t7 = t10;
    goto LAB7;

LAB8:    t1 = (t0 + 5032U);
    t5 = *((char **)t1);
    t18 = (4 - 7);
    t19 = (t18 * -1);
    t20 = (1U * t19);
    t21 = (0 + t20);
    t1 = (t5 + t21);
    t22 = *((unsigned char *)t1);
    t23 = (t22 == (unsigned char)2);
    if (t23 == 1)
        goto LAB17;

LAB18:    t17 = (unsigned char)0;

LAB19:    if (t17 == 1)
        goto LAB14;

LAB15:    t16 = (unsigned char)0;

LAB16:    t30 = (!(t16));
    t10 = t30;
    goto LAB10;

LAB11:    t1 = (t0 + 9832U);
    t4 = *((char **)t1);
    t14 = *((unsigned char *)t4);
    t15 = (t14 == (unsigned char)0);
    t11 = t15;
    goto LAB13;

LAB14:    t6 = (t0 + 4872U);
    t27 = *((char **)t6);
    t28 = *((unsigned char *)t27);
    t29 = (t28 == (unsigned char)2);
    t16 = t29;
    goto LAB16;

LAB17:    t6 = (t0 + 9512U);
    t24 = *((char **)t6);
    t25 = *((unsigned char *)t24);
    t26 = (t25 == (unsigned char)3);
    t17 = t26;
    goto LAB19;

LAB20:    xsi_set_current_line(451, ng1);
    t39 = (t0 + 1512U);
    t40 = *((char **)t39);
    t39 = (t0 + 33524U);
    t41 = work_a_0643350375_1516540902_sub_3065100407_1516540902(t0, t38, t40, t39);
    t42 = (t0 + 22112);
    t43 = (t42 + 56U);
    t44 = *((char **)t43);
    t45 = (t44 + 56U);
    t46 = *((char **)t45);
    memcpy(t46, t41, 8U);
    xsi_driver_first_trans_fast(t42);
    goto LAB21;

LAB23:    xsi_set_current_line(456, ng1);
    t3 = (t0 + 22112);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t24 = (t6 + 56U);
    t27 = *((char **)t24);
    *((unsigned char *)t27) = (unsigned char)3;
    xsi_driver_first_trans_delta(t3, 0U, 1, 0LL);
    goto LAB3;

LAB25:    t3 = (t0 + 8712U);
    t4 = *((char **)t3);
    t10 = *((unsigned char *)t4);
    t11 = (t10 == (unsigned char)3);
    t7 = t11;
    goto LAB27;

LAB28:    xsi_set_current_line(460, ng1);
    t27 = (t0 + 6792U);
    t41 = *((char **)t27);
    if (7 > 0)
        goto LAB51;

LAB52:    if (-1 == -1)
        goto LAB56;

LAB57:    t50 = 0;

LAB53:    t51 = (t50 - 1);
    t52 = (7 - t51);
    t53 = (t52 * 1U);
    t54 = (0 + t53);
    t27 = (t41 + t54);
    t42 = (t0 + 9032U);
    t43 = *((char **)t42);
    t55 = *((unsigned char *)t43);
    t44 = ((IEEE_P_2592010699) + 4024);
    t45 = (t56 + 0U);
    t46 = (t45 + 0U);
    *((int *)t46) = 6;
    t46 = (t45 + 4U);
    *((int *)t46) = 0;
    t46 = (t45 + 8U);
    *((int *)t46) = -1;
    t57 = (0 - 6);
    t58 = (t57 * -1);
    t58 = (t58 + 1);
    t46 = (t45 + 12U);
    *((unsigned int *)t46) = t58;
    t42 = xsi_base_array_concat(t42, t38, t44, (char)97, t27, t56, (char)99, t55, (char)101);
    t46 = (t0 + 22112);
    t59 = (t46 + 56U);
    t60 = *((char **)t59);
    t61 = (t60 + 56U);
    t62 = *((char **)t61);
    memcpy(t62, t42, 8U);
    xsi_driver_first_trans_fast(t46);
    goto LAB3;

LAB30:    t7 = (unsigned char)1;
    goto LAB32;

LAB33:    t3 = (t0 + 7432U);
    t6 = *((char **)t3);
    t17 = *((unsigned char *)t6);
    t22 = (t17 == (unsigned char)3);
    t8 = t22;
    goto LAB35;

LAB36:    t3 = (t0 + 7592U);
    t5 = *((char **)t3);
    t15 = *((unsigned char *)t5);
    t16 = (t15 == (unsigned char)3);
    t9 = t16;
    goto LAB38;

LAB39:    t3 = (t0 + 7912U);
    t4 = *((char **)t3);
    t13 = *((unsigned char *)t4);
    t14 = (t13 != (unsigned char)0);
    t10 = t14;
    goto LAB41;

LAB42:    t27 = (t0 + 4872U);
    t40 = *((char **)t27);
    t48 = *((unsigned char *)t40);
    t49 = (t48 == (unsigned char)2);
    t23 = t49;
    goto LAB44;

LAB45:    t27 = (t0 + 9672U);
    t39 = *((char **)t27);
    t37 = *((unsigned char *)t39);
    t47 = (t37 == (unsigned char)3);
    t25 = t47;
    goto LAB47;

LAB48:    t27 = (t0 + 9832U);
    t31 = *((char **)t27);
    t30 = *((unsigned char *)t31);
    t36 = (t30 != (unsigned char)0);
    t26 = t36;
    goto LAB50;

LAB51:    if (-1 == 1)
        goto LAB54;

LAB55:    t50 = 7;
    goto LAB53;

LAB54:    t50 = 0;
    goto LAB53;

LAB56:    t50 = 7;
    goto LAB53;

}

static void work_a_0643350375_1516540902_p_13(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    int t8;
    int t9;
    unsigned char t10;
    unsigned char t11;
    unsigned char t12;
    int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned char t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    unsigned char t23;
    unsigned char t24;
    unsigned char t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned char t29;
    unsigned char t30;

LAB0:    xsi_set_current_line(467, ng1);
    t1 = (t0 + 8552U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 22176);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(468, ng1);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 33508U);
    t8 = work_p_0170319956_sub_3397525853_170319956(WORK_P_0170319956, t2, t1);
    t4 = ((WORK_P_3602289512) + 2728U);
    t5 = *((char **)t4);
    t9 = *((int *)t5);
    t10 = (t8 == t9);
    if (t10 == 1)
        goto LAB5;

LAB6:    t3 = (unsigned char)0;

LAB7:    if (t3 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 8232U);
    t2 = *((char **)t1);
    t11 = *((unsigned char *)t2);
    t12 = (t11 == (unsigned char)3);
    if (t12 == 1)
        goto LAB13;

LAB14:    t10 = (unsigned char)0;

LAB15:    if (t10 == 1)
        goto LAB10;

LAB11:    t3 = (unsigned char)0;

LAB12:    if (t3 != 0)
        goto LAB8;

LAB9:    t1 = (t0 + 7912U);
    t2 = *((char **)t1);
    t10 = *((unsigned char *)t2);
    t11 = (t10 != (unsigned char)0);
    if (t11 == 1)
        goto LAB18;

LAB19:    t3 = (unsigned char)0;

LAB20:    if (t3 != 0)
        goto LAB16;

LAB17:    t1 = (t0 + 7912U);
    t2 = *((char **)t1);
    t10 = *((unsigned char *)t2);
    t11 = (t10 != (unsigned char)0);
    if (t11 == 1)
        goto LAB23;

LAB24:    t3 = (unsigned char)0;

LAB25:    if (t3 != 0)
        goto LAB21;

LAB22:
LAB3:    t1 = (t0 + 19552);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(469, ng1);
    t4 = (t0 + 1512U);
    t7 = *((char **)t4);
    t13 = (3 - 7);
    t14 = (t13 * -1);
    t15 = (1U * t14);
    t16 = (0 + t15);
    t4 = (t7 + t16);
    t17 = *((unsigned char *)t4);
    t18 = (t0 + 22176);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    *((unsigned char *)t22) = t17;
    xsi_driver_first_trans_fast(t18);
    goto LAB3;

LAB5:    t4 = (t0 + 1992U);
    t6 = *((char **)t4);
    t11 = *((unsigned char *)t6);
    t12 = (t11 == (unsigned char)3);
    t3 = t12;
    goto LAB7;

LAB8:    xsi_set_current_line(471, ng1);
    t5 = (t0 + 5032U);
    t7 = *((char **)t5);
    t9 = (3 - 7);
    t26 = (t9 * -1);
    t27 = (1U * t26);
    t28 = (0 + t27);
    t5 = (t7 + t28);
    t29 = *((unsigned char *)t5);
    t30 = ieee_p_2592010699_sub_1690584930_2592010699(IEEE_P_2592010699, t29);
    t18 = (t0 + 22176);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    *((unsigned char *)t22) = t30;
    xsi_driver_first_trans_fast(t18);
    goto LAB3;

LAB10:    t5 = (t0 + 7912U);
    t6 = *((char **)t5);
    t24 = *((unsigned char *)t6);
    t25 = (t24 == (unsigned char)0);
    t3 = t25;
    goto LAB12;

LAB13:    t1 = (t0 + 5032U);
    t4 = *((char **)t1);
    t8 = (2 - 7);
    t14 = (t8 * -1);
    t15 = (1U * t14);
    t16 = (0 + t15);
    t1 = (t4 + t16);
    t17 = *((unsigned char *)t1);
    t23 = (t17 == (unsigned char)3);
    t10 = t23;
    goto LAB15;

LAB16:    xsi_set_current_line(473, ng1);
    t1 = (t0 + 5032U);
    t5 = *((char **)t1);
    t8 = (3 - 7);
    t14 = (t8 * -1);
    t15 = (1U * t14);
    t16 = (0 + t15);
    t1 = (t5 + t16);
    t23 = *((unsigned char *)t1);
    t6 = (t0 + 22176);
    t7 = (t6 + 56U);
    t18 = *((char **)t7);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = t23;
    xsi_driver_first_trans_fast(t6);
    goto LAB3;

LAB18:    t1 = (t0 + 8072U);
    t4 = *((char **)t1);
    t12 = *((unsigned char *)t4);
    t17 = (t12 == (unsigned char)0);
    t3 = t17;
    goto LAB20;

LAB21:    xsi_set_current_line(475, ng1);
    t1 = (t0 + 8552U);
    t6 = *((char **)t1);
    t24 = *((unsigned char *)t6);
    t25 = ieee_p_2592010699_sub_1690584930_2592010699(IEEE_P_2592010699, t24);
    t1 = (t0 + 22176);
    t7 = (t1 + 56U);
    t18 = *((char **)t7);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = t25;
    xsi_driver_first_trans_fast(t1);
    goto LAB3;

LAB23:    t1 = (t0 + 7592U);
    t4 = *((char **)t1);
    t12 = *((unsigned char *)t4);
    t1 = (t0 + 7752U);
    t5 = *((char **)t1);
    t17 = *((unsigned char *)t5);
    t23 = (t12 != t17);
    t3 = t23;
    goto LAB25;

}

static void work_a_0643350375_1516540902_p_14(char *t0)
{
    char t29[16];
    char t40[16];
    char t42[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned char t7;
    unsigned char t8;
    unsigned char t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    unsigned char t15;
    int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned char t20;
    unsigned char t21;
    char *t22;
    int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned char t27;
    unsigned char t28;
    char *t30;
    char *t31;
    int t32;
    int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;
    char *t38;
    unsigned char t39;
    char *t41;
    char *t43;
    char *t44;
    int t45;
    unsigned int t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;

LAB0:    xsi_set_current_line(483, ng1);
    t1 = (t0 + 6472U);
    t2 = *((char **)t1);
    t1 = (t0 + 22240);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 8U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(484, ng1);
    t1 = (t0 + 8712U);
    t2 = *((char **)t1);
    t7 = *((unsigned char *)t2);
    t8 = (t7 == (unsigned char)3);
    if (t8 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 19568);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(485, ng1);
    t1 = (t0 + 5032U);
    t3 = *((char **)t1);
    t10 = (4 - 7);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t1 = (t3 + t13);
    t14 = *((unsigned char *)t1);
    t15 = (t14 == (unsigned char)2);
    if (t15 == 1)
        goto LAB8;

LAB9:    t9 = (unsigned char)0;

LAB10:    if (t9 != 0)
        goto LAB5;

LAB7:    xsi_set_current_line(492, ng1);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t10 = (5 - 7);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t1 = (t2 + t13);
    t7 = *((unsigned char *)t1);
    t8 = (t7 == (unsigned char)3);
    if (t8 != 0)
        goto LAB28;

LAB30:    xsi_set_current_line(495, ng1);
    t1 = (t0 + 6792U);
    t2 = *((char **)t1);
    t1 = (t0 + 22240);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 8U);
    xsi_driver_first_trans_fast(t1);

LAB29:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(486, ng1);
    t6 = (t0 + 5032U);
    t22 = *((char **)t6);
    t23 = (5 - 7);
    t24 = (t23 * -1);
    t25 = (1U * t24);
    t26 = (0 + t25);
    t6 = (t22 + t26);
    t27 = *((unsigned char *)t6);
    t28 = (t27 == (unsigned char)3);
    if (t28 != 0)
        goto LAB11;

LAB13:    xsi_set_current_line(489, ng1);
    t1 = (t0 + 6792U);
    t2 = *((char **)t1);
    if (7 > 0)
        goto LAB21;

LAB22:    if (-1 == -1)
        goto LAB26;

LAB27:    t10 = 0;

LAB23:    t16 = (t10 - 1);
    t11 = (7 - t16);
    t12 = (t11 * 1U);
    t13 = (0 + t12);
    t1 = (t2 + t13);
    t3 = (t0 + 9032U);
    t4 = *((char **)t3);
    t7 = *((unsigned char *)t4);
    t5 = ((IEEE_P_2592010699) + 4024);
    t6 = (t40 + 0U);
    t22 = (t6 + 0U);
    *((int *)t22) = 6;
    t22 = (t6 + 4U);
    *((int *)t22) = 0;
    t22 = (t6 + 8U);
    *((int *)t22) = -1;
    t23 = (0 - 6);
    t17 = (t23 * -1);
    t17 = (t17 + 1);
    t22 = (t6 + 12U);
    *((unsigned int *)t22) = t17;
    t3 = xsi_base_array_concat(t3, t29, t5, (char)97, t1, t40, (char)99, t7, (char)101);
    t22 = (t0 + 22240);
    t30 = (t22 + 56U);
    t31 = *((char **)t30);
    t37 = (t31 + 56U);
    t38 = *((char **)t37);
    memcpy(t38, t3, 8U);
    xsi_driver_first_trans_fast(t22);

LAB12:    goto LAB6;

LAB8:    t4 = (t0 + 5032U);
    t5 = *((char **)t4);
    t16 = (2 - 7);
    t17 = (t16 * -1);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t4 = (t5 + t19);
    t20 = *((unsigned char *)t4);
    t21 = (t20 == (unsigned char)3);
    t9 = t21;
    goto LAB10;

LAB11:    xsi_set_current_line(487, ng1);
    t30 = (t0 + 6792U);
    t31 = *((char **)t30);
    if (7 > 0)
        goto LAB14;

LAB15:    if (-1 == -1)
        goto LAB19;

LAB20:    t32 = 0;

LAB16:    t33 = (t32 - 1);
    t34 = (7 - t33);
    t35 = (t34 * 1U);
    t36 = (0 + t35);
    t30 = (t31 + t36);
    t37 = (t0 + 9032U);
    t38 = *((char **)t37);
    t39 = *((unsigned char *)t38);
    t41 = ((IEEE_P_2592010699) + 4024);
    t43 = (t42 + 0U);
    t44 = (t43 + 0U);
    *((int *)t44) = 6;
    t44 = (t43 + 4U);
    *((int *)t44) = 0;
    t44 = (t43 + 8U);
    *((int *)t44) = -1;
    t45 = (0 - 6);
    t46 = (t45 * -1);
    t46 = (t46 + 1);
    t44 = (t43 + 12U);
    *((unsigned int *)t44) = t46;
    t37 = xsi_base_array_concat(t37, t40, t41, (char)97, t30, t42, (char)99, t39, (char)101);
    t44 = work_a_0643350375_1516540902_sub_3065100407_1516540902(t0, t29, t37, t40);
    t47 = (t0 + 22240);
    t48 = (t47 + 56U);
    t49 = *((char **)t48);
    t50 = (t49 + 56U);
    t51 = *((char **)t50);
    memcpy(t51, t44, 8U);
    xsi_driver_first_trans_fast(t47);
    goto LAB12;

LAB14:    if (-1 == 1)
        goto LAB17;

LAB18:    t32 = 7;
    goto LAB16;

LAB17:    t32 = 0;
    goto LAB16;

LAB19:    t32 = 7;
    goto LAB16;

LAB21:    if (-1 == 1)
        goto LAB24;

LAB25:    t10 = 7;
    goto LAB23;

LAB24:    t10 = 0;
    goto LAB23;

LAB26:    t10 = 7;
    goto LAB23;

LAB28:    xsi_set_current_line(493, ng1);
    t3 = (t0 + 6792U);
    t4 = *((char **)t3);
    t3 = (t0 + 33652U);
    t5 = work_a_0643350375_1516540902_sub_3065100407_1516540902(t0, t29, t4, t3);
    t6 = (t0 + 22240);
    t22 = (t6 + 56U);
    t30 = *((char **)t22);
    t31 = (t30 + 56U);
    t37 = *((char **)t31);
    memcpy(t37, t5, 8U);
    xsi_driver_first_trans_fast(t6);
    goto LAB29;

}

static void work_a_0643350375_1516540902_p_15(char *t0)
{
    unsigned char t1;
    unsigned char t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned char t16;
    char *t17;
    char *t18;
    int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned char t23;
    unsigned char t24;
    unsigned char t25;
    unsigned char t26;
    char *t27;
    char *t28;
    unsigned char t29;
    unsigned char t30;
    char *t31;
    unsigned char t32;
    unsigned char t33;
    char *t34;
    int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned char t39;
    char *t40;
    char *t41;
    int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned char t46;
    unsigned char t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;

LAB0:    xsi_set_current_line(506, ng1);
    t4 = (t0 + 9352U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)2);
    if (t7 == 1)
        goto LAB11;

LAB12:    t3 = (unsigned char)0;

LAB13:    if (t3 == 1)
        goto LAB8;

LAB9:    t2 = (unsigned char)0;

LAB10:    if (t2 == 1)
        goto LAB5;

LAB6:    t27 = (t0 + 9352U);
    t28 = *((char **)t27);
    t29 = *((unsigned char *)t28);
    t30 = (t29 == (unsigned char)3);
    if (t30 == 1)
        goto LAB17;

LAB18:    t26 = (unsigned char)0;

LAB19:    if (t26 == 1)
        goto LAB14;

LAB15:    t25 = (unsigned char)0;

LAB16:    t1 = t25;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB20:    t53 = (t0 + 22304);
    t54 = (t53 + 56U);
    t55 = *((char **)t54);
    t56 = (t55 + 56U);
    t57 = *((char **)t56);
    *((unsigned char *)t57) = (unsigned char)2;
    xsi_driver_first_trans_fast(t53);

LAB2:    t58 = (t0 + 19584);
    *((int *)t58) = 1;

LAB1:    return;
LAB3:    t48 = (t0 + 22304);
    t49 = (t48 + 56U);
    t50 = *((char **)t49);
    t51 = (t50 + 56U);
    t52 = *((char **)t51);
    *((unsigned char *)t52) = (unsigned char)3;
    xsi_driver_first_trans_fast(t48);
    goto LAB2;

LAB5:    t1 = (unsigned char)1;
    goto LAB7;

LAB8:    t4 = (t0 + 5032U);
    t11 = *((char **)t4);
    t12 = (3 - 7);
    t13 = (t12 * -1);
    t14 = (1U * t13);
    t15 = (0 + t14);
    t4 = (t11 + t15);
    t16 = *((unsigned char *)t4);
    t17 = (t0 + 5032U);
    t18 = *((char **)t17);
    t19 = (2 - 7);
    t20 = (t19 * -1);
    t21 = (1U * t20);
    t22 = (0 + t21);
    t17 = (t18 + t22);
    t23 = *((unsigned char *)t17);
    t24 = (t16 == t23);
    t2 = t24;
    goto LAB10;

LAB11:    t4 = (t0 + 4712U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t10 = (t9 == (unsigned char)3);
    t3 = t10;
    goto LAB13;

LAB14:    t27 = (t0 + 5032U);
    t34 = *((char **)t27);
    t35 = (3 - 7);
    t36 = (t35 * -1);
    t37 = (1U * t36);
    t38 = (0 + t37);
    t27 = (t34 + t38);
    t39 = *((unsigned char *)t27);
    t40 = (t0 + 5032U);
    t41 = *((char **)t40);
    t42 = (2 - 7);
    t43 = (t42 * -1);
    t44 = (1U * t43);
    t45 = (0 + t44);
    t40 = (t41 + t45);
    t46 = *((unsigned char *)t40);
    t47 = (t39 != t46);
    t25 = t47;
    goto LAB16;

LAB17:    t27 = (t0 + 4712U);
    t31 = *((char **)t27);
    t32 = *((unsigned char *)t31);
    t33 = (t32 == (unsigned char)2);
    t26 = t33;
    goto LAB19;

LAB21:    goto LAB2;

}

static void work_a_0643350375_1516540902_p_16(char *t0)
{
    unsigned char t1;
    unsigned char t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned char t16;
    char *t17;
    char *t18;
    int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned char t23;
    unsigned char t24;
    unsigned char t25;
    unsigned char t26;
    char *t27;
    char *t28;
    unsigned char t29;
    unsigned char t30;
    char *t31;
    unsigned char t32;
    unsigned char t33;
    char *t34;
    int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned char t39;
    char *t40;
    char *t41;
    int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned char t46;
    unsigned char t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;

LAB0:    xsi_set_current_line(509, ng1);
    t4 = (t0 + 9352U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    if (t7 == 1)
        goto LAB11;

LAB12:    t3 = (unsigned char)0;

LAB13:    if (t3 == 1)
        goto LAB8;

LAB9:    t2 = (unsigned char)0;

LAB10:    if (t2 == 1)
        goto LAB5;

LAB6:    t27 = (t0 + 9352U);
    t28 = *((char **)t27);
    t29 = *((unsigned char *)t28);
    t30 = (t29 == (unsigned char)2);
    if (t30 == 1)
        goto LAB17;

LAB18:    t26 = (unsigned char)0;

LAB19:    if (t26 == 1)
        goto LAB14;

LAB15:    t25 = (unsigned char)0;

LAB16:    t1 = t25;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB20:    t53 = (t0 + 22368);
    t54 = (t53 + 56U);
    t55 = *((char **)t54);
    t56 = (t55 + 56U);
    t57 = *((char **)t56);
    *((unsigned char *)t57) = (unsigned char)2;
    xsi_driver_first_trans_fast(t53);

LAB2:    t58 = (t0 + 19600);
    *((int *)t58) = 1;

LAB1:    return;
LAB3:    t48 = (t0 + 22368);
    t49 = (t48 + 56U);
    t50 = *((char **)t49);
    t51 = (t50 + 56U);
    t52 = *((char **)t51);
    *((unsigned char *)t52) = (unsigned char)3;
    xsi_driver_first_trans_fast(t48);
    goto LAB2;

LAB5:    t1 = (unsigned char)1;
    goto LAB7;

LAB8:    t4 = (t0 + 5032U);
    t11 = *((char **)t4);
    t12 = (3 - 7);
    t13 = (t12 * -1);
    t14 = (1U * t13);
    t15 = (0 + t14);
    t4 = (t11 + t15);
    t16 = *((unsigned char *)t4);
    t17 = (t0 + 5032U);
    t18 = *((char **)t17);
    t19 = (2 - 7);
    t20 = (t19 * -1);
    t21 = (1U * t20);
    t22 = (0 + t21);
    t17 = (t18 + t22);
    t23 = *((unsigned char *)t17);
    t24 = (t16 == t23);
    t2 = t24;
    goto LAB10;

LAB11:    t4 = (t0 + 4712U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t10 = (t9 == (unsigned char)2);
    t3 = t10;
    goto LAB13;

LAB14:    t27 = (t0 + 5032U);
    t34 = *((char **)t27);
    t35 = (3 - 7);
    t36 = (t35 * -1);
    t37 = (1U * t36);
    t38 = (0 + t37);
    t27 = (t34 + t38);
    t39 = *((unsigned char *)t27);
    t40 = (t0 + 5032U);
    t41 = *((char **)t40);
    t42 = (2 - 7);
    t43 = (t42 * -1);
    t44 = (1U * t43);
    t45 = (0 + t44);
    t40 = (t41 + t45);
    t46 = *((unsigned char *)t40);
    t47 = (t39 != t46);
    t25 = t47;
    goto LAB16;

LAB17:    t27 = (t0 + 4712U);
    t31 = *((char **)t27);
    t32 = *((unsigned char *)t31);
    t33 = (t32 == (unsigned char)3);
    t26 = t33;
    goto LAB19;

LAB21:    goto LAB2;

}

static void work_a_0643350375_1516540902_p_17(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned char t21;
    unsigned char t22;
    char *t23;
    char *t24;
    unsigned char t25;
    unsigned char t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    static char *nl0[] = {&&LAB6, &&LAB7, &&LAB8, &&LAB9, &&LAB10, &&LAB11, &&LAB12, &&LAB13, &&LAB14, &&LAB15};

LAB0:    xsi_set_current_line(515, ng1);
    t1 = (t0 + 9832U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 22432);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(516, ng1);
    t1 = (t0 + 4872U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t8 = (t3 == (unsigned char)2);
    if (t8 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 19616);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(517, ng1);
    t1 = (t0 + 9832U);
    t4 = *((char **)t1);
    t9 = *((unsigned char *)t4);
    t1 = (char *)((nl0) + t9);
    goto **((char **)t1);

LAB5:    goto LAB3;

LAB6:    xsi_set_current_line(520, ng1);
    t5 = (t0 + 5032U);
    t6 = *((char **)t5);
    t10 = (4 - 7);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t5 = (t6 + t13);
    t14 = *((unsigned char *)t5);
    t15 = (t14 == (unsigned char)2);
    if (t15 != 0)
        goto LAB17;

LAB19:
LAB18:    goto LAB5;

LAB7:    xsi_set_current_line(533, ng1);
    t1 = (t0 + 9672U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t8 = (t3 == (unsigned char)3);
    if (t8 != 0)
        goto LAB29;

LAB31:
LAB30:    goto LAB5;

LAB8:    xsi_set_current_line(538, ng1);
    t1 = (t0 + 9672U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t8 = (t3 == (unsigned char)3);
    if (t8 != 0)
        goto LAB32;

LAB34:
LAB33:    goto LAB5;

LAB9:    xsi_set_current_line(542, ng1);
    t1 = (t0 + 9672U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t8 = (t3 == (unsigned char)3);
    if (t8 != 0)
        goto LAB35;

LAB37:
LAB36:    goto LAB5;

LAB10:    xsi_set_current_line(546, ng1);
    t1 = (t0 + 9672U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t8 = (t3 == (unsigned char)3);
    if (t8 != 0)
        goto LAB38;

LAB40:
LAB39:    goto LAB5;

LAB11:    xsi_set_current_line(550, ng1);
    t1 = (t0 + 9672U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t8 = (t3 == (unsigned char)3);
    if (t8 != 0)
        goto LAB41;

LAB43:
LAB42:    goto LAB5;

LAB12:    xsi_set_current_line(554, ng1);
    t1 = (t0 + 9672U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t8 = (t3 == (unsigned char)3);
    if (t8 != 0)
        goto LAB44;

LAB46:
LAB45:    goto LAB5;

LAB13:    xsi_set_current_line(558, ng1);
    t1 = (t0 + 9672U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t8 = (t3 == (unsigned char)3);
    if (t8 != 0)
        goto LAB47;

LAB49:
LAB48:    goto LAB5;

LAB14:    xsi_set_current_line(563, ng1);
    t1 = (t0 + 9672U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t8 = (t3 == (unsigned char)3);
    if (t8 != 0)
        goto LAB50;

LAB52:
LAB51:    goto LAB5;

LAB15:    xsi_set_current_line(572, ng1);
    t1 = (t0 + 9512U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t8 = (t3 == (unsigned char)3);
    if (t8 != 0)
        goto LAB56;

LAB58:
LAB57:    goto LAB5;

LAB16:    xsi_set_current_line(575, ng1);
    t1 = (t0 + 22432);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    goto LAB5;

LAB17:    xsi_set_current_line(521, ng1);
    t7 = (t0 + 5032U);
    t16 = *((char **)t7);
    t17 = (2 - 7);
    t18 = (t17 * -1);
    t19 = (1U * t18);
    t20 = (0 + t19);
    t7 = (t16 + t20);
    t21 = *((unsigned char *)t7);
    t22 = (t21 == (unsigned char)3);
    if (t22 != 0)
        goto LAB20;

LAB22:    xsi_set_current_line(526, ng1);
    t1 = (t0 + 9512U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t8 = (t3 == (unsigned char)3);
    if (t8 != 0)
        goto LAB26;

LAB28:
LAB27:
LAB21:    goto LAB18;

LAB20:    xsi_set_current_line(522, ng1);
    t23 = (t0 + 9672U);
    t24 = *((char **)t23);
    t25 = *((unsigned char *)t24);
    t26 = (t25 == (unsigned char)3);
    if (t26 != 0)
        goto LAB23;

LAB25:
LAB24:    goto LAB21;

LAB23:    xsi_set_current_line(523, ng1);
    t23 = (t0 + 22432);
    t27 = (t23 + 56U);
    t28 = *((char **)t27);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    *((unsigned char *)t30) = (unsigned char)2;
    xsi_driver_first_trans_fast(t23);
    goto LAB24;

LAB26:    xsi_set_current_line(527, ng1);
    t1 = (t0 + 22432);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)1;
    xsi_driver_first_trans_fast(t1);
    goto LAB27;

LAB29:    xsi_set_current_line(534, ng1);
    t1 = (t0 + 22432);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB30;

LAB32:    xsi_set_current_line(539, ng1);
    t1 = (t0 + 22432);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB33;

LAB35:    xsi_set_current_line(543, ng1);
    t1 = (t0 + 22432);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)4;
    xsi_driver_first_trans_fast(t1);
    goto LAB36;

LAB38:    xsi_set_current_line(547, ng1);
    t1 = (t0 + 22432);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)5;
    xsi_driver_first_trans_fast(t1);
    goto LAB39;

LAB41:    xsi_set_current_line(551, ng1);
    t1 = (t0 + 22432);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)6;
    xsi_driver_first_trans_fast(t1);
    goto LAB42;

LAB44:    xsi_set_current_line(555, ng1);
    t1 = (t0 + 22432);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)7;
    xsi_driver_first_trans_fast(t1);
    goto LAB45;

LAB47:    xsi_set_current_line(559, ng1);
    t1 = (t0 + 22432);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)8;
    xsi_driver_first_trans_fast(t1);
    goto LAB48;

LAB50:    xsi_set_current_line(564, ng1);
    t1 = (t0 + 5032U);
    t4 = *((char **)t1);
    t10 = (2 - 7);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t1 = (t4 + t13);
    t9 = *((unsigned char *)t1);
    t14 = (t9 == (unsigned char)2);
    if (t14 != 0)
        goto LAB53;

LAB55:    xsi_set_current_line(567, ng1);
    t1 = (t0 + 22432);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)9;
    xsi_driver_first_trans_fast(t1);

LAB54:    goto LAB51;

LAB53:    xsi_set_current_line(565, ng1);
    t5 = (t0 + 22432);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t16 = (t7 + 56U);
    t23 = *((char **)t16);
    *((unsigned char *)t23) = (unsigned char)0;
    xsi_driver_first_trans_fast(t5);
    goto LAB54;

LAB56:    xsi_set_current_line(573, ng1);
    t1 = (t0 + 22432);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    goto LAB57;

}

static void work_a_0643350375_1516540902_p_18(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    unsigned char t13;
    unsigned char t14;
    int t15;
    int t16;
    unsigned char t17;
    char *t18;
    unsigned char t19;
    unsigned char t20;
    char *t21;
    int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned char t26;
    unsigned char t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned char t33;
    unsigned char t34;
    static char *nl0[] = {&&LAB5, &&LAB5, &&LAB3, &&LAB4, &&LAB5, &&LAB5, &&LAB5, &&LAB5, &&LAB5};

LAB0:    xsi_set_current_line(583, ng1);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t3 = (4 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 22496);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(584, ng1);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t3 = (4 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (char *)((nl0) + t7);
    goto **((char **)t8);

LAB2:    t1 = (t0 + 19632);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(586, ng1);
    t9 = (t0 + 1352U);
    t10 = *((char **)t9);
    t9 = (t0 + 33508U);
    t15 = work_p_0170319956_sub_3397525853_170319956(WORK_P_0170319956, t10, t9);
    t11 = ((WORK_P_3602289512) + 2728U);
    t12 = *((char **)t11);
    t16 = *((int *)t12);
    t17 = (t15 == t16);
    if (t17 == 1)
        goto LAB12;

LAB13:    t14 = (unsigned char)0;

LAB14:    if (t14 == 1)
        goto LAB9;

LAB10:    t13 = (unsigned char)0;

LAB11:    if (t13 != 0)
        goto LAB6;

LAB8:
LAB7:    goto LAB2;

LAB4:    xsi_set_current_line(590, ng1);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 33508U);
    t3 = work_p_0170319956_sub_3397525853_170319956(WORK_P_0170319956, t2, t1);
    t8 = ((WORK_P_3602289512) + 2728U);
    t9 = *((char **)t8);
    t15 = *((int *)t9);
    t17 = (t3 == t15);
    if (t17 == 1)
        goto LAB24;

LAB25:    t14 = (unsigned char)0;

LAB26:    if (t14 == 1)
        goto LAB21;

LAB22:    t13 = (unsigned char)0;

LAB23:    if (t13 == 1)
        goto LAB18;

LAB19:    t12 = (t0 + 4872U);
    t18 = *((char **)t12);
    t33 = *((unsigned char *)t18);
    t34 = (t33 == (unsigned char)2);
    t7 = t34;

LAB20:    if (t7 != 0)
        goto LAB15;

LAB17:
LAB16:    goto LAB2;

LAB5:    xsi_set_current_line(594, ng1);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t3 = (4 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 22496);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast(t8);
    goto LAB2;

LAB6:    xsi_set_current_line(587, ng1);
    t28 = (t0 + 22496);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    *((unsigned char *)t32) = (unsigned char)3;
    xsi_driver_first_trans_fast(t28);
    goto LAB7;

LAB9:    t11 = (t0 + 1512U);
    t21 = *((char **)t11);
    t22 = (4 - 7);
    t23 = (t22 * -1);
    t24 = (1U * t23);
    t25 = (0 + t24);
    t11 = (t21 + t25);
    t26 = *((unsigned char *)t11);
    t27 = (t26 == (unsigned char)3);
    t13 = t27;
    goto LAB11;

LAB12:    t11 = (t0 + 1992U);
    t18 = *((char **)t11);
    t19 = *((unsigned char *)t18);
    t20 = (t19 == (unsigned char)3);
    t14 = t20;
    goto LAB14;

LAB15:    xsi_set_current_line(592, ng1);
    t12 = (t0 + 22496);
    t21 = (t12 + 56U);
    t28 = *((char **)t21);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    *((unsigned char *)t30) = (unsigned char)2;
    xsi_driver_first_trans_fast(t12);
    goto LAB16;

LAB18:    t7 = (unsigned char)1;
    goto LAB20;

LAB21:    t8 = (t0 + 1512U);
    t11 = *((char **)t8);
    t16 = (4 - 7);
    t4 = (t16 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t8 = (t11 + t6);
    t26 = *((unsigned char *)t8);
    t27 = (t26 == (unsigned char)2);
    t13 = t27;
    goto LAB23;

LAB24:    t8 = (t0 + 1992U);
    t10 = *((char **)t8);
    t19 = *((unsigned char *)t10);
    t20 = (t19 == (unsigned char)3);
    t14 = t20;
    goto LAB26;

}

static void work_a_0643350375_1516540902_p_19(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    unsigned char t13;
    unsigned char t14;
    int t15;
    int t16;
    unsigned char t17;
    char *t18;
    unsigned char t19;
    unsigned char t20;
    unsigned char t21;
    unsigned char t22;
    char *t23;
    int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned char t28;
    unsigned char t29;
    unsigned char t30;
    char *t31;
    char *t32;
    unsigned char t33;
    unsigned char t34;
    unsigned char t35;
    char *t36;
    unsigned char t37;
    unsigned char t38;
    char *t39;
    unsigned char t40;
    unsigned char t41;
    unsigned char t42;
    char *t43;
    int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned char t48;
    unsigned char t49;
    char *t50;
    char *t51;
    unsigned char t52;
    unsigned char t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    unsigned char t58;
    unsigned char t59;
    unsigned char t60;
    unsigned char t61;
    unsigned char t62;
    unsigned char t63;
    int t64;
    unsigned char t65;
    unsigned char t66;
    unsigned char t67;
    unsigned char t68;
    unsigned char t69;
    char *t70;
    char *t71;
    char *t72;
    static char *nl0[] = {&&LAB5, &&LAB5, &&LAB3, &&LAB4, &&LAB5, &&LAB5, &&LAB5, &&LAB5, &&LAB5};

LAB0:    xsi_set_current_line(601, ng1);
    t1 = (t0 + 5192U);
    t2 = *((char **)t1);
    t3 = (6 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 22560);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(602, ng1);
    t1 = (t0 + 5192U);
    t2 = *((char **)t1);
    t3 = (6 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (char *)((nl0) + t7);
    goto **((char **)t8);

LAB2:    t1 = (t0 + 19648);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(604, ng1);
    t9 = (t0 + 1352U);
    t10 = *((char **)t9);
    t9 = (t0 + 33508U);
    t15 = work_p_0170319956_sub_3397525853_170319956(WORK_P_0170319956, t10, t9);
    t11 = ((WORK_P_3602289512) + 2968U);
    t12 = *((char **)t11);
    t16 = *((int *)t12);
    t17 = (t15 == t16);
    if (t17 == 1)
        goto LAB12;

LAB13:    t14 = (unsigned char)0;

LAB14:    if (t14 == 1)
        goto LAB9;

LAB10:    t13 = (unsigned char)0;

LAB11:    if (t13 != 0)
        goto LAB6;

LAB8:
LAB7:    goto LAB2;

LAB4:    xsi_set_current_line(610, ng1);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 33508U);
    t3 = work_p_0170319956_sub_3397525853_170319956(WORK_P_0170319956, t2, t1);
    t8 = ((WORK_P_3602289512) + 2968U);
    t9 = *((char **)t8);
    t15 = *((int *)t9);
    t17 = (t3 == t15);
    if (t17 == 1)
        goto LAB39;

LAB40:    t14 = (unsigned char)0;

LAB41:    if (t14 == 1)
        goto LAB36;

LAB37:    t13 = (unsigned char)0;

LAB38:    if (t13 == 1)
        goto LAB33;

LAB34:    t7 = (unsigned char)0;

LAB35:    if (t7 != 0)
        goto LAB30;

LAB32:
LAB31:    goto LAB2;

LAB5:    xsi_set_current_line(616, ng1);
    t1 = (t0 + 5192U);
    t2 = *((char **)t1);
    t3 = (6 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 22560);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast(t8);
    goto LAB2;

LAB6:    xsi_set_current_line(607, ng1);
    t50 = (t0 + 22560);
    t54 = (t50 + 56U);
    t55 = *((char **)t54);
    t56 = (t55 + 56U);
    t57 = *((char **)t56);
    *((unsigned char *)t57) = (unsigned char)3;
    xsi_driver_first_trans_fast(t50);
    goto LAB7;

LAB9:    t11 = (t0 + 5032U);
    t23 = *((char **)t11);
    t24 = (4 - 7);
    t25 = (t24 * -1);
    t26 = (1U * t25);
    t27 = (0 + t26);
    t11 = (t23 + t27);
    t28 = *((unsigned char *)t11);
    t29 = (t28 == (unsigned char)2);
    if (t29 == 1)
        goto LAB18;

LAB19:    t22 = (unsigned char)0;

LAB20:    if (t22 == 1)
        goto LAB15;

LAB16:    t31 = (t0 + 5032U);
    t43 = *((char **)t31);
    t44 = (4 - 7);
    t45 = (t44 * -1);
    t46 = (1U * t45);
    t47 = (0 + t46);
    t31 = (t43 + t47);
    t48 = *((unsigned char *)t31);
    t49 = (t48 == (unsigned char)3);
    if (t49 == 1)
        goto LAB27;

LAB28:    t42 = (unsigned char)0;

LAB29:    t21 = t42;

LAB17:    t13 = t21;
    goto LAB11;

LAB12:    t11 = (t0 + 1992U);
    t18 = *((char **)t11);
    t19 = *((unsigned char *)t18);
    t20 = (t19 == (unsigned char)3);
    t14 = t20;
    goto LAB14;

LAB15:    t21 = (unsigned char)1;
    goto LAB17;

LAB18:    t31 = (t0 + 9832U);
    t32 = *((char **)t31);
    t33 = *((unsigned char *)t32);
    t34 = (t33 != (unsigned char)0);
    if (t34 == 1)
        goto LAB21;

LAB22:    t31 = (t0 + 9512U);
    t36 = *((char **)t31);
    t37 = *((unsigned char *)t36);
    t38 = (t37 == (unsigned char)3);
    if (t38 == 1)
        goto LAB24;

LAB25:    t35 = (unsigned char)0;

LAB26:    t30 = t35;

LAB23:    t22 = t30;
    goto LAB20;

LAB21:    t30 = (unsigned char)1;
    goto LAB23;

LAB24:    t31 = (t0 + 4872U);
    t39 = *((char **)t31);
    t40 = *((unsigned char *)t39);
    t41 = (t40 == (unsigned char)2);
    t35 = t41;
    goto LAB26;

LAB27:    t50 = (t0 + 7912U);
    t51 = *((char **)t50);
    t52 = *((unsigned char *)t51);
    t53 = (t52 != (unsigned char)0);
    t42 = t53;
    goto LAB29;

LAB30:    xsi_set_current_line(614, ng1);
    t55 = (t0 + 22560);
    t57 = (t55 + 56U);
    t70 = *((char **)t57);
    t71 = (t70 + 56U);
    t72 = *((char **)t71);
    *((unsigned char *)t72) = (unsigned char)2;
    xsi_driver_first_trans_fast(t55);
    goto LAB31;

LAB33:    t8 = (t0 + 1352U);
    t18 = *((char **)t8);
    t8 = (t0 + 33508U);
    t16 = work_p_0170319956_sub_3397525853_170319956(WORK_P_0170319956, t18, t8);
    t23 = ((WORK_P_3602289512) + 2968U);
    t31 = *((char **)t23);
    t24 = *((int *)t31);
    t35 = (t16 == t24);
    if (t35 == 1)
        goto LAB48;

LAB49:    t34 = (unsigned char)0;

LAB50:    if (t34 == 1)
        goto LAB45;

LAB46:    t33 = (unsigned char)0;

LAB47:    t69 = (!(t33));
    t7 = t69;
    goto LAB35;

LAB36:    t8 = (t0 + 10472U);
    t12 = *((char **)t8);
    t29 = *((unsigned char *)t12);
    t30 = (t29 == (unsigned char)3);
    t13 = t30;
    goto LAB38;

LAB39:    t8 = (t0 + 1992U);
    t10 = *((char **)t8);
    t20 = *((unsigned char *)t10);
    t21 = (t20 == (unsigned char)3);
    if (t21 == 1)
        goto LAB42;

LAB43:    t8 = (t0 + 1832U);
    t11 = *((char **)t8);
    t22 = *((unsigned char *)t11);
    t28 = (t22 == (unsigned char)3);
    t19 = t28;

LAB44:    t14 = t19;
    goto LAB41;

LAB42:    t19 = (unsigned char)1;
    goto LAB44;

LAB45:    t23 = (t0 + 5032U);
    t36 = *((char **)t23);
    t44 = (4 - 7);
    t4 = (t44 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t23 = (t36 + t6);
    t42 = *((unsigned char *)t23);
    t48 = (t42 == (unsigned char)2);
    if (t48 == 1)
        goto LAB54;

LAB55:    t41 = (unsigned char)0;

LAB56:    if (t41 == 1)
        goto LAB51;

LAB52:    t39 = (t0 + 5032U);
    t54 = *((char **)t39);
    t64 = (4 - 7);
    t25 = (t64 * -1);
    t26 = (1U * t25);
    t27 = (0 + t26);
    t39 = (t54 + t27);
    t65 = *((unsigned char *)t39);
    t66 = (t65 == (unsigned char)3);
    if (t66 == 1)
        goto LAB63;

LAB64:    t63 = (unsigned char)0;

LAB65:    t40 = t63;

LAB53:    t33 = t40;
    goto LAB47;

LAB48:    t23 = (t0 + 1992U);
    t32 = *((char **)t23);
    t37 = *((unsigned char *)t32);
    t38 = (t37 == (unsigned char)3);
    t34 = t38;
    goto LAB50;

LAB51:    t40 = (unsigned char)1;
    goto LAB53;

LAB54:    t39 = (t0 + 9832U);
    t43 = *((char **)t39);
    t52 = *((unsigned char *)t43);
    t53 = (t52 != (unsigned char)0);
    if (t53 == 1)
        goto LAB57;

LAB58:    t39 = (t0 + 9512U);
    t50 = *((char **)t39);
    t59 = *((unsigned char *)t50);
    t60 = (t59 == (unsigned char)3);
    if (t60 == 1)
        goto LAB60;

LAB61:    t58 = (unsigned char)0;

LAB62:    t49 = t58;

LAB59:    t41 = t49;
    goto LAB56;

LAB57:    t49 = (unsigned char)1;
    goto LAB59;

LAB60:    t39 = (t0 + 4872U);
    t51 = *((char **)t39);
    t61 = *((unsigned char *)t51);
    t62 = (t61 == (unsigned char)2);
    t58 = t62;
    goto LAB62;

LAB63:    t55 = (t0 + 7912U);
    t56 = *((char **)t55);
    t67 = *((unsigned char *)t56);
    t68 = (t67 != (unsigned char)0);
    t63 = t68;
    goto LAB65;

}

static void work_a_0643350375_1516540902_p_20(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    unsigned char t13;
    unsigned char t14;
    unsigned char t15;
    int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned char t20;
    unsigned char t21;
    unsigned char t22;
    unsigned char t23;
    char *t24;
    unsigned char t25;
    unsigned char t26;
    unsigned char t27;
    unsigned char t28;
    char *t29;
    int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned char t34;
    unsigned char t35;
    char *t36;
    char *t37;
    unsigned char t38;
    unsigned char t39;
    char *t40;
    unsigned char t41;
    unsigned char t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    static char *nl0[] = {&&LAB5, &&LAB5, &&LAB3, &&LAB4, &&LAB5, &&LAB5, &&LAB5, &&LAB5, &&LAB5};

LAB0:    xsi_set_current_line(623, ng1);
    t1 = (t0 + 5192U);
    t2 = *((char **)t1);
    t3 = (7 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 22624);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(624, ng1);
    t1 = (t0 + 5192U);
    t2 = *((char **)t1);
    t3 = (7 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (char *)((nl0) + t7);
    goto **((char **)t8);

LAB2:    t1 = (t0 + 19664);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(626, ng1);
    t9 = (t0 + 5032U);
    t10 = *((char **)t9);
    t16 = (4 - 7);
    t17 = (t16 * -1);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t9 = (t10 + t19);
    t20 = *((unsigned char *)t9);
    t21 = (t20 == (unsigned char)2);
    if (t21 == 1)
        goto LAB15;

LAB16:    t15 = (unsigned char)0;

LAB17:    if (t15 == 1)
        goto LAB12;

LAB13:    t14 = (unsigned char)0;

LAB14:    if (t14 == 1)
        goto LAB9;

LAB10:    t11 = (t0 + 5032U);
    t29 = *((char **)t11);
    t30 = (4 - 7);
    t31 = (t30 * -1);
    t32 = (1U * t31);
    t33 = (0 + t32);
    t11 = (t29 + t33);
    t34 = *((unsigned char *)t11);
    t35 = (t34 == (unsigned char)3);
    if (t35 == 1)
        goto LAB21;

LAB22:    t28 = (unsigned char)0;

LAB23:    if (t28 == 1)
        goto LAB18;

LAB19:    t27 = (unsigned char)0;

LAB20:    t13 = t27;

LAB11:    if (t13 != 0)
        goto LAB6;

LAB8:
LAB7:    goto LAB2;

LAB4:    xsi_set_current_line(631, ng1);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 33508U);
    t3 = work_p_0170319956_sub_3397525853_170319956(WORK_P_0170319956, t2, t1);
    t8 = ((WORK_P_3602289512) + 2968U);
    t9 = *((char **)t8);
    t16 = *((int *)t9);
    t15 = (t3 == t16);
    if (t15 == 1)
        goto LAB33;

LAB34:    t14 = (unsigned char)0;

LAB35:    if (t14 == 1)
        goto LAB30;

LAB31:    t13 = (unsigned char)0;

LAB32:    if (t13 == 1)
        goto LAB27;

LAB28:    t8 = (t0 + 3912U);
    t24 = *((char **)t8);
    t28 = *((unsigned char *)t24);
    t34 = (t28 == (unsigned char)3);
    t7 = t34;

LAB29:    if (t7 != 0)
        goto LAB24;

LAB26:
LAB25:    goto LAB2;

LAB5:    xsi_set_current_line(634, ng1);
    t1 = (t0 + 5192U);
    t2 = *((char **)t1);
    t3 = (7 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 22624);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast(t8);
    goto LAB2;

LAB6:    xsi_set_current_line(628, ng1);
    t36 = (t0 + 22624);
    t43 = (t36 + 56U);
    t44 = *((char **)t43);
    t45 = (t44 + 56U);
    t46 = *((char **)t45);
    *((unsigned char *)t46) = (unsigned char)3;
    xsi_driver_first_trans_fast(t36);
    goto LAB7;

LAB9:    t13 = (unsigned char)1;
    goto LAB11;

LAB12:    t11 = (t0 + 9992U);
    t24 = *((char **)t11);
    t25 = *((unsigned char *)t24);
    t26 = (t25 == (unsigned char)0);
    t14 = t26;
    goto LAB14;

LAB15:    t11 = (t0 + 9832U);
    t12 = *((char **)t11);
    t22 = *((unsigned char *)t12);
    t23 = (t22 != (unsigned char)0);
    t15 = t23;
    goto LAB17;

LAB18:    t36 = (t0 + 8072U);
    t40 = *((char **)t36);
    t41 = *((unsigned char *)t40);
    t42 = (t41 == (unsigned char)0);
    t27 = t42;
    goto LAB20;

LAB21:    t36 = (t0 + 7912U);
    t37 = *((char **)t36);
    t38 = *((unsigned char *)t37);
    t39 = (t38 != (unsigned char)0);
    t28 = t39;
    goto LAB23;

LAB24:    xsi_set_current_line(632, ng1);
    t8 = (t0 + 22624);
    t29 = (t8 + 56U);
    t36 = *((char **)t29);
    t37 = (t36 + 56U);
    t40 = *((char **)t37);
    *((unsigned char *)t40) = (unsigned char)2;
    xsi_driver_first_trans_fast(t8);
    goto LAB25;

LAB27:    t7 = (unsigned char)1;
    goto LAB29;

LAB30:    t8 = (t0 + 10152U);
    t12 = *((char **)t8);
    t26 = *((unsigned char *)t12);
    t27 = (t26 == (unsigned char)3);
    t13 = t27;
    goto LAB32;

LAB33:    t8 = (t0 + 1992U);
    t10 = *((char **)t8);
    t21 = *((unsigned char *)t10);
    t22 = (t21 == (unsigned char)3);
    if (t22 == 1)
        goto LAB36;

LAB37:    t8 = (t0 + 1832U);
    t11 = *((char **)t8);
    t23 = *((unsigned char *)t11);
    t25 = (t23 == (unsigned char)3);
    t20 = t25;

LAB38:    t14 = t20;
    goto LAB35;

LAB36:    t20 = (unsigned char)1;
    goto LAB38;

}

static void work_a_0643350375_1516540902_p_21(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(640, ng1);

LAB3:    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t3 = (4 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 22688);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast_port(t8);

LAB2:    t13 = (t0 + 19680);
    *((int *)t13) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0643350375_1516540902_p_22(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(641, ng1);

LAB3:    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t3 = (6 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 22752);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast_port(t8);

LAB2:    t13 = (t0 + 19696);
    *((int *)t13) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0643350375_1516540902_p_23(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;

LAB0:    xsi_set_current_line(644, ng1);

LAB3:    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t3 = (7 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 5192U);
    t9 = *((char **)t8);
    t10 = (7 - 7);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t8 = (t9 + t13);
    t14 = *((unsigned char *)t8);
    t15 = ieee_p_2592010699_sub_1605435078_2592010699(IEEE_P_2592010699, t7, t14);
    t16 = (t0 + 22816);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = t15;
    xsi_driver_first_trans_fast_port(t16);

LAB2:    t21 = (t0 + 19712);
    *((int *)t21) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0643350375_1516540902_p_24(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    char *t4;
    char *t5;
    int t6;
    char *t7;
    int t8;
    char *t9;
    int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned char t16;

LAB0:    xsi_set_current_line(648, ng1);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 33508U);
    t3 = work_p_0170319956_sub_3397525853_170319956(WORK_P_0170319956, t2, t1);
    t4 = ((WORK_P_3602289512) + 2968U);
    t5 = *((char **)t4);
    t6 = *((int *)t5);
    if (t3 == t6)
        goto LAB3;

LAB7:    t4 = ((WORK_P_3602289512) + 2848U);
    t7 = *((char **)t4);
    t8 = *((int *)t7);
    if (t3 == t8)
        goto LAB4;

LAB8:    t4 = ((WORK_P_3602289512) + 2728U);
    t9 = *((char **)t4);
    t10 = *((int *)t9);
    if (t3 == t10)
        goto LAB5;

LAB9:
LAB6:    xsi_set_current_line(652, ng1);
    t1 = xsi_get_transient_memory(8U);
    memset(t1, 0, 8U);
    t2 = t1;
    memset(t2, (unsigned char)2, 8U);
    t4 = (t0 + 22880);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    t9 = (t7 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t1, 8U);
    xsi_driver_first_trans_fast_port(t4);
    xsi_set_current_line(652, ng1);
    t1 = (t0 + 22944);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t1 = (t0 + 19728);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(649, ng1);
    t4 = (t0 + 6472U);
    t11 = *((char **)t4);
    t4 = (t0 + 22880);
    t12 = (t4 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t11, 8U);
    xsi_driver_first_trans_fast_port(t4);
    xsi_set_current_line(649, ng1);
    t1 = (t0 + 1832U);
    t2 = *((char **)t1);
    t16 = *((unsigned char *)t2);
    t1 = (t0 + 22944);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t7 = (t5 + 56U);
    t9 = *((char **)t7);
    *((unsigned char *)t9) = t16;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB4:    xsi_set_current_line(650, ng1);
    t1 = (t0 + 5192U);
    t2 = *((char **)t1);
    t1 = (t0 + 22880);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t7 = (t5 + 56U);
    t9 = *((char **)t7);
    memcpy(t9, t2, 8U);
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(650, ng1);
    t1 = (t0 + 1832U);
    t2 = *((char **)t1);
    t16 = *((unsigned char *)t2);
    t1 = (t0 + 22944);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t7 = (t5 + 56U);
    t9 = *((char **)t7);
    *((unsigned char *)t9) = t16;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB5:    xsi_set_current_line(651, ng1);
    t1 = (t0 + 5032U);
    t2 = *((char **)t1);
    t1 = (t0 + 22880);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t7 = (t5 + 56U);
    t9 = *((char **)t7);
    memcpy(t9, t2, 8U);
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(651, ng1);
    t1 = (t0 + 1832U);
    t2 = *((char **)t1);
    t16 = *((unsigned char *)t2);
    t1 = (t0 + 22944);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t7 = (t5 + 56U);
    t9 = *((char **)t7);
    *((unsigned char *)t9) = t16;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB10:;
}

static void work_a_0643350375_1516540902_p_25(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;

LAB0:    xsi_set_current_line(657, ng1);

LAB3:    t1 = (t0 + 23008);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0643350375_1516540902_p_26(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;

LAB0:    xsi_set_current_line(658, ng1);

LAB3:    t1 = (t0 + 23072);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_0643350375_1516540902_init()
{
	static char *pe[] = {(void *)work_a_0643350375_1516540902_p_0,(void *)work_a_0643350375_1516540902_p_1,(void *)work_a_0643350375_1516540902_p_2,(void *)work_a_0643350375_1516540902_p_3,(void *)work_a_0643350375_1516540902_p_4,(void *)work_a_0643350375_1516540902_p_5,(void *)work_a_0643350375_1516540902_p_6,(void *)work_a_0643350375_1516540902_p_7,(void *)work_a_0643350375_1516540902_p_8,(void *)work_a_0643350375_1516540902_p_9,(void *)work_a_0643350375_1516540902_p_10,(void *)work_a_0643350375_1516540902_p_11,(void *)work_a_0643350375_1516540902_p_12,(void *)work_a_0643350375_1516540902_p_13,(void *)work_a_0643350375_1516540902_p_14,(void *)work_a_0643350375_1516540902_p_15,(void *)work_a_0643350375_1516540902_p_16,(void *)work_a_0643350375_1516540902_p_17,(void *)work_a_0643350375_1516540902_p_18,(void *)work_a_0643350375_1516540902_p_19,(void *)work_a_0643350375_1516540902_p_20,(void *)work_a_0643350375_1516540902_p_21,(void *)work_a_0643350375_1516540902_p_22,(void *)work_a_0643350375_1516540902_p_23,(void *)work_a_0643350375_1516540902_p_24,(void *)work_a_0643350375_1516540902_p_25,(void *)work_a_0643350375_1516540902_p_26};
	static char *se[] = {(void *)work_a_0643350375_1516540902_sub_3065100407_1516540902};
	xsi_register_didat("work_a_0643350375_1516540902", "isim/AVR8_tb_isim_beh.exe.sim/work/a_0643350375_1516540902.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
